# InsightLab AI Setup Steps

## Required Software

Install these first:

- Node.js 18 or newer
- Python 3.10 or newer
- MongoDB Community Server

## 1. Start MongoDB

Make sure MongoDB is running locally on:

```bash
mongodb://127.0.0.1:27017
```

## 2. Start Django REST Framework

```bash
cd "insightlab ai/ml_service"
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 8000
```

Health check:

```text
http://localhost:8000/api/health/
```

## 3. Start Node + Express API

```bash
cd "insightlab ai/server"
copy .env.example .env
npm install
npm run dev
```

Health check:

```text
http://localhost:5000/api/health
```

## 4. Start React Frontend

```bash
cd "insightlab ai/frontend"
copy .env.example .env
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## Workflow Included

The project includes:

- Signup and login
- JWT authentication
- User dashboard
- Dynamic project creation
- CSV/Excel upload
- MongoDB project records
- Django REST dataset profiling
- EDA summary endpoint
- Machine learning training endpoint
- Prediction endpoint
- Report generation endpoint
- React workspace tabs for dataset, cleaning, EDA, features, models, predictions, reports, and settings

