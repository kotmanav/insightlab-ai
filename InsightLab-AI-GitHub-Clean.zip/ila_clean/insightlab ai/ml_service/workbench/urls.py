from django.urls import path
from . import views

urlpatterns = [
    path("health/",               views.health),
    path("datasets/profile/",     views.profile_dataset),
    path("eda/summary/",          views.eda_summary),
    path("datasets/clean/",       views.clean_dataset),
    path("visualize/",            views.generate_visualization),
    path("models/train/",         views.train_models),
    path("models/feature-importance/", views.feature_importance),
    path("predictions/run/",      views.run_prediction),
    path("reports/generate/",     views.generate_report),
]
