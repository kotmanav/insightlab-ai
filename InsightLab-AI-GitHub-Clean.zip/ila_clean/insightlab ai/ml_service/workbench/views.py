from pathlib import Path
import base64
import hashlib
import io
import json
import traceback

import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # non-interactive backend for server
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import seaborn as sns
from rest_framework.decorators import api_view
from rest_framework.response import Response

from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression, Ridge
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.svm import SVC, SVR
from sklearn.metrics import accuracy_score, f1_score, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, LabelEncoder, StandardScaler, PolynomialFeatures
from sklearn.compose import ColumnTransformer


# ─── Model storage directory ──────────────────────────────────────────────────
MODELS_DIR = Path(__file__).resolve().parent.parent / "saved_models"
MODELS_DIR.mkdir(exist_ok=True)


# ─── Shared palette / style ────────────────────────────────────────────────────
DARK_BG   = "#0d1117"
CARD_BG   = "#161b22"
BORDER    = "#30363d"
TEXT      = "#e6edf3"
TEXT_2    = "#8b949e"
ACCENT    = "#2f81f7"
GREEN     = "#3fb950"
PURPLE    = "#a371f7"
ORANGE    = "#f78166"
YELLOW    = "#e3b341"
RED       = "#f85149"

PALETTE   = [ACCENT, PURPLE, GREEN, ORANGE, YELLOW, RED,
             "#58a6ff", "#79c0ff", "#d2a8ff", "#ffb77a"]


def apply_dark_style():
  plt.style.use("dark_background")
  plt.rcParams.update({
      "figure.facecolor": DARK_BG,
      "axes.facecolor": CARD_BG,
      "axes.edgecolor": BORDER,
      "axes.labelcolor": TEXT_2,
      "xtick.color": TEXT_2,
      "ytick.color": TEXT_2,
      "grid.color": BORDER,
      "grid.alpha": 0.4,
      "font.family": "sans-serif",
      "font.size": 9,
  })


def fig_to_b64(fig):
  buf = io.BytesIO()
  fig.savefig(buf, format="png", bbox_inches="tight", dpi=130, facecolor=fig.get_facecolor())
  plt.close(fig)
  buf.seek(0)
  return "data:image/png;base64," + base64.b64encode(buf.read()).decode("utf-8")


def load_dataset(file_path):
  p = Path(file_path)
  if not p.exists():
    raise FileNotFoundError(f"Dataset file not found at path: '{file_path}'")
  if p.suffix.lower() == ".csv":
    return pd.read_csv(p)
  elif p.suffix.lower() in [".xlsx", ".xls"]:
    return pd.read_excel(p)
  else:
    raise ValueError(f"Unsupported file format: '{p.suffix}'")


def dataframe_profile(df):
  dtypes = {col: str(dtype) for col, dtype in df.dtypes.items()}
  missing = {col: int(count) for col, count in df.isnull().sum().items()}
  sample_rows = df.head(8).replace({np.nan: None}).to_dict(orient="records")
  return {
      "rows": int(len(df)),
      "columns": int(len(df.columns)),
      "columnTypes": dtypes,
      "columnNames": list(df.columns),
      "missingValues": missing,
      "preview": sample_rows,
  }


def _model_key(file_path, target):
  key_str = f"{file_path}::{target}"
  return hashlib.md5(key_str.encode("utf-8")).hexdigest()


def _model_path(file_path, target):
  return MODELS_DIR / f"model_{_model_key(file_path, target)}.joblib"


def _meta_path(file_path, target):
  return MODELS_DIR / f"meta_{_model_key(file_path, target)}.json"


# ─── API Endpoints ─────────────────────────────────────────────────────────────

@api_view(["GET"])
def health(request):
  return Response({"status": "ok", "service": "InsightLab ML Engine"})


@api_view(["POST"])
def profile_dataset(request):
  try:
    df = load_dataset(request.data.get("file_path", ""))
    return Response(dataframe_profile(df))
  except Exception as exc:
    return Response({"message": str(exc)}, status=400)


@api_view(["POST"])
def clean_dataset(request):
  """Apply requested data cleaning operations and save back to original file."""
  try:
    file_path = request.data.get("file_path", "")
    target_column = request.data.get("column", "")
    fill_value = request.data.get("fill_value")
    raw_ops = request.data.get("operations") or request.data.get("operation") or []
    if isinstance(raw_ops, str):
      operations = [raw_ops]
    else:
      operations = list(raw_ops)

    df = load_dataset(file_path)

    applied_summary = []

    for op in operations:
      # Column-specific cleaning operations
      if target_column and target_column in df.columns:
        if op == "drop_column_nulls":
          before = len(df)
          df = df.dropna(subset=[target_column])
          applied_summary.append(f"Dropped {before - len(df)} rows with missing values in column '{target_column}'.")

        elif op == "fill_column_median":
          if pd.api.types.is_numeric_dtype(df[target_column]):
            med_val = df[target_column].median()
            df[target_column] = df[target_column].fillna(med_val)
            applied_summary.append(f"Filled missing values in column '{target_column}' with median ({med_val}).")
          else:
            applied_summary.append(f"Column '{target_column}' is non-numeric; median imputation skipped.")

        elif op == "fill_column_mean":
          if pd.api.types.is_numeric_dtype(df[target_column]):
            mean_val = df[target_column].mean()
            df[target_column] = df[target_column].fillna(mean_val)
            applied_summary.append(f"Filled missing values in column '{target_column}' with mean ({mean_val:.2f}).")
          else:
            applied_summary.append(f"Column '{target_column}' is non-numeric; mean imputation skipped.")

        elif op == "fill_column_mode":
          mode_val = df[target_column].mode()
          if not mode_val.empty:
            df[target_column] = df[target_column].fillna(mode_val[0])
            applied_summary.append(f"Filled missing values in column '{target_column}' with mode ('{mode_val[0]}').")

        elif op == "fill_column_custom":
          if fill_value is not None:
            df[target_column] = df[target_column].fillna(fill_value)
            applied_summary.append(f"Filled missing values in column '{target_column}' with custom value '{fill_value}'.")

        elif op == "drop_column":
          df = df.drop(columns=[target_column])
          applied_summary.append(f"Dropped column '{target_column}' completely from dataset.")

      # General dataset cleaning operations
      if op == "drop_nulls":
        before = len(df)
        df = df.dropna()
        applied_summary.append(f"Dropped {before - len(df)} rows with missing values across dataset.")

      elif op == "fill_median":
        num_cols = df.select_dtypes(include=np.number).columns
        df[num_cols] = df[num_cols].fillna(df[num_cols].median())
        applied_summary.append(f"Filled numeric missing values with column medians ({len(num_cols)} columns).")

      elif op == "fill_mode":
        cat_cols = df.select_dtypes(include="object").columns
        for c in cat_cols:
          mode_val = df[c].mode()
          if not mode_val.empty:
            df[c] = df[c].fillna(mode_val[0])
        applied_summary.append(f"Filled categorical missing values with modes ({len(cat_cols)} columns).")

      elif op == "drop_duplicates":
        before = len(df)
        df = df.drop_duplicates()
        applied_summary.append(f"Removed {before - len(df)} duplicate rows.")

      elif op == "drop_constants":
        const_cols = [c for c in df.columns if df[c].nunique() <= 1]
        df = df.drop(columns=const_cols)
        applied_summary.append(f"Dropped {len(const_cols)} constant columns: {const_cols}.")

      elif op == "normalize":
        num_cols = df.select_dtypes(include=np.number).columns
        for c in num_cols:
          min_val, max_val = df[c].min(), df[c].max()
          if max_val > min_val:
            df[c] = (df[c] - min_val) / (max_val - min_val)
        applied_summary.append(f"Min-max normalized {len(num_cols)} numeric columns.")

    p = Path(file_path)
    if p.suffix.lower() == ".csv":
      df.to_csv(p, index=False)
    else:
      df.to_excel(p, index=False)

    return Response({
        "message": "Dataset cleaned successfully",
        "applied": applied_summary,
        "new_profile": dataframe_profile(df),
    })

  except Exception as exc:
    return Response({"message": str(exc)}, status=400)


@api_view(["POST"])
def eda_summary(request):
  try:
    file_path = request.data.get("file_path", "")
    df = load_dataset(file_path)
    num_df = df.select_dtypes(include=np.number)
    cat_df = df.select_dtypes(include=["object", "bool"])

    num_stats = num_df.describe().T.round(3).to_dict(orient="index") if not num_df.empty else {}
    cat_stats = {col: df[col].value_counts().head(5).to_dict() for col in cat_df.columns}

    missing_series = df.isnull().sum()
    missing_dict = {col: int(count) for col, count in missing_series.items()}
    missing_pct = (missing_series / len(df) * 100).round(2).to_dict() if len(df) else {}

    corr_dict = num_df.corr().round(3).to_dict() if not num_df.empty else {}

    # Build insights
    insights = []
    insights.append(f"Dataset contains {len(df):,} total records across {len(df.columns)} features.")
    insights.append(f"Feature types: {len(num_df.columns)} Numerical, {len(cat_df.columns)} Categorical.")
    
    total_missing = sum(missing_dict.values())
    if total_missing > 0:
      most_missing_col = max(missing_dict, key=missing_dict.get)
      most_missing_cnt = missing_dict[most_missing_col]
      insights.append(f"Total missing values: {total_missing:,} cells across dataset. Most affected feature: '{most_missing_col}' ({most_missing_cnt} missing).")
    else:
      insights.append("Zero missing values detected — dataset is completely filled.")

    if not num_df.empty and len(num_df.columns) >= 2:
      try:
        # Find highest correlated numeric pair (excluding self-correlation)
        corr_df = num_df.corr().abs()
        corr_arr = corr_df.to_numpy(copy=True)
        np.fill_diagonal(corr_arr, 0)
        corr_matrix = pd.DataFrame(corr_arr, index=corr_df.index, columns=corr_df.columns)
        if not corr_matrix.empty and corr_matrix.max().max() > 0:
          max_pair = corr_matrix.unstack().idxmax()
          val = num_df.corr().loc[max_pair[0], max_pair[1]]
          insights.append(f"Strongest numerical correlation: '{max_pair[0]}' & '{max_pair[1]}' (r = {val:.2f}).")
      except Exception as err:
        print("[EDA Correlation Pair Calc Warning]", err)

    # Formatted statistics dictionary for frontend table mapping { count, mean, std, min, 50%, max }
    stats_formatted = {
        "count": {col: num_stats[col].get("count") for col in num_stats},
        "mean":  {col: num_stats[col].get("mean") for col in num_stats},
        "std":   {col: num_stats[col].get("std") for col in num_stats},
        "min":   {col: num_stats[col].get("min") for col in num_stats},
        "50%":   {col: num_stats[col].get("50%") for col in num_stats},
        "max":   {col: num_stats[col].get("max") for col in num_stats},
    }

    return Response({
        "rows": len(df),
        "columns": len(df.columns),
        "profile": {
            "rows": len(df),
            "columns": len(df.columns),
            "missingValues": missing_dict,
            "missingPercent": missing_pct,
            "columnNames": list(df.columns),
            "columnTypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
        },
        "insights": insights,
        "statistics": stats_formatted,
        "numericStats": num_stats,
        "categoricalStats": cat_stats,
        "missingValues": missing_dict,
        "missingPercent": missing_pct,
        "correlationMatrix": corr_dict,
    })

  except Exception as exc:
    tb = traceback.format_exc()
    print("[EDA Summary Error]", tb)
    return Response({"message": str(exc)}, status=400)


@api_view(["POST"])
def generate_visualization(request):
  try:
    apply_dark_style()
    df = load_dataset(request.data.get("file_path", ""))
    chart_type = request.data.get("chart_type", "histogram")
    column = request.data.get("column")
    column_y = request.data.get("column_y")
    hue = request.data.get("hue")
    bins = int(request.data.get("bins", 30))
    top_n = int(request.data.get("top_n", 10))

    num_cols = df.select_dtypes(include=np.number).columns.tolist()
    cat_cols = df.select_dtypes(include=["object", "bool"]).columns.tolist()

    img_b64 = None

    if chart_type == "histogram":
      col = column if column in num_cols else (num_cols[0] if num_cols else None)
      fig, ax = plt.subplots(figsize=(9, 5))
      if col:
        sns.histplot(data=df, x=col, bins=bins, kde=True, ax=ax, color=ACCENT, edgecolor=DARK_BG)
        ax.set_title(f"Histogram of {col}")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "kde":
      col = column if column in num_cols else (num_cols[0] if num_cols else None)
      fig, ax = plt.subplots(figsize=(9, 5))
      if col:
        sns.kdeplot(data=df, x=col, hue=hue if hue in df.columns else None, ax=ax, fill=True, palette=PALETTE)
        ax.set_title(f"KDE Density Plot of {col}")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "boxplot":
      fig, ax = plt.subplots(figsize=(9, 5))
      cols = [column] if column in num_cols else num_cols[:6]
      if cols:
        sns.boxplot(data=df[cols], palette=PALETTE[:len(cols)], ax=ax)
        ax.set_title("Boxplot — Numeric Feature Outliers")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "violinplot":
      fig, ax = plt.subplots(figsize=(9, 5))
      cols = [column] if column in num_cols else num_cols[:5]
      if cols:
        sns.violinplot(data=df[cols], palette=PALETTE[:len(cols)], ax=ax)
        ax.set_title("Violin Distribution Plot")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "scatter":
      cx = column if column in num_cols else (num_cols[0] if num_cols else None)
      cy = column_y if column_y in num_cols else (num_cols[1] if len(num_cols) > 1 else cx)
      fig, ax = plt.subplots(figsize=(9, 5))
      if cx and cy:
        sns.scatterplot(data=df, x=cx, y=cy, hue=hue if hue in df.columns else None, palette=PALETTE, alpha=0.7, ax=ax)
        ax.set_title(f"Scatter Plot — {cx} vs {cy}")
      img_b64 = fig_to_b64(fig)

    elif chart_type in ["geo_heatmap", "spatial_heatmap"] or (
        chart_type == "heatmap"
        and any("long" in c.lower() for c in df.columns)
        and any("lat" in c.lower() for c in df.columns)
    ):
      fig, ax = plt.subplots(figsize=(9.5, 7.5), facecolor="white")
      ax.set_facecolor("#fcf4e4")  # Light tan map background matching Figure 2-1

      # 1. Longitude Feature (X Axis)
      long_col = column if (column and column in df.columns) else next((c for c in df.columns if "long" in c.lower()), None)
      # 2. Latitude Feature (Y Axis)
      lat_col = column_y if (column_y and column_y in df.columns) else next((c for c in df.columns if "lat" in c.lower()), None)

      if not long_col or not lat_col:
        num_list = df.select_dtypes(include=np.number).columns.tolist()
        if len(num_list) >= 2:
          long_col = long_col or num_list[0]
          lat_col = lat_col or num_list[1]

      if long_col and lat_col:
        # 3. Color Feature (Colorbar / Target Metric)
        color_col = request.data.get("color_col", "")
        hue_col = request.data.get("hue", "")
        target_col = None
        if color_col and color_col in df.columns:
          target_col = color_col
        elif hue_col and hue_col in df.columns and pd.api.types.is_numeric_dtype(df[hue_col]):
          target_col = hue_col
        else:
          for candidate in ["median_house_value", "price", "sale_price", "saleprice", "target", "value"]:
            matching = next((c for c in df.columns if candidate in c.lower()), None)
            if matching:
              target_col = matching
              break

        if not target_col:
          other_nums = [c for c in df.select_dtypes(include=np.number).columns if c not in [long_col, lat_col]]
          target_col = other_nums[0] if other_nums else long_col

        # 4. Point Size Feature (Population)
        size_col = request.data.get("size_col", "")
        pop_col = size_col if (size_col and size_col in df.columns) else next((c for c in df.columns if "pop" in c.lower()), None)

        if pop_col and pd.api.types.is_numeric_dtype(df[pop_col]):
          max_p = df[pop_col].max()
          pop_sizes = (df[pop_col] / (max_p if max_p > 0 else 1)) * 300 + 10
        else:
          pop_sizes = 25

        color_values = df[target_col] if pd.api.types.is_numeric_dtype(df[target_col]) else LabelEncoder().fit_transform(df[target_col].astype(str))

        scatter = ax.scatter(
            df[long_col],
            df[lat_col],
            alpha=0.4,
            s=pop_sizes,
            c=color_values,
            cmap=plt.get_cmap("jet"),
            edgecolors="none",
        )

        for spine in ax.spines.values():
          spine.set_color("black")
          spine.set_linewidth(1.0)
        ax.tick_params(colors="black", labelsize=10)

        cbar = fig.colorbar(scatter, ax=ax)
        cbar_lbl = f"Median house value (USD)" if ("price" in target_col.lower() or "value" in target_col.lower()) else target_col
        cbar.set_label(cbar_lbl, color="black", fontsize=10)
        cbar.ax.yaxis.set_tick_params(color="black")
        plt.setp(plt.getp(cbar.ax.axes, 'yticklabels'), color="black")

        pop_lbl = pop_col.capitalize() if pop_col else "Population"
        pop_legend = plt.Line2D([0], [0], marker="o", color="w", label=pop_lbl, markerfacecolor="#d92525", markersize=9)
        ax.legend(handles=[pop_legend], loc="upper right", frameon=True, facecolor="white", edgecolor="black", fontsize=10)

        ax.set_xlabel(long_col.capitalize(), fontsize=11, color="black")
        ax.set_ylabel(lat_col.capitalize(), fontsize=11, color="black")
        ax.set_title(f"Figure 2-1. California housing prices", fontsize=12, pad=12, color="black")
      else:
        ax.text(0.5, 0.5, "Requires Latitude and Longitude columns for Geographical Heatmap", ha="center", va="center", color="black", fontsize=11)
        ax.set_title("Geographical Heatmap", fontsize=11, pad=12, color="black")

      img_b64 = fig_to_b64(fig)

    elif chart_type == "heatmap":
      fig, ax = plt.subplots(figsize=(10, 8))
      num_df = df.select_dtypes(include=np.number)
      if num_df.empty or len(num_df.columns) < 2:
        num_df = pd.DataFrame()
        for col in df.columns:
          if pd.api.types.is_numeric_dtype(df[col]):
            num_df[col] = df[col].fillna(df[col].median())
          else:
            num_df[col] = LabelEncoder().fit_transform(df[col].fillna("Missing").astype(str))

      if not num_df.empty and len(num_df.columns) >= 2:
        corr = num_df.corr().round(2).fillna(0)
        show_annot = len(corr.columns) <= 12
        sns.heatmap(
            corr,
            annot=show_annot,
            fmt=".2f",
            cmap="coolwarm",
            vmin=-1,
            vmax=1,
            ax=ax,
            cbar=True,
            linewidths=0.5,
            linecolor=BORDER,
        )
        ax.set_title("Feature Correlation Heatmap", fontsize=11, pad=12)
        plt.xticks(rotation=45, ha="right", fontsize=8)
        plt.yticks(rotation=0, fontsize=8)
      else:
        ax.text(0.5, 0.5, "Requires at least 2 features for Correlation Heatmap", ha="center", va="center", color=TEXT_2, fontsize=11)
        ax.set_title("Feature Correlation Heatmap", fontsize=11, pad=12)
      img_b64 = fig_to_b64(fig)

    elif chart_type == "missing_heatmap":
      fig, ax = plt.subplots(figsize=(10, 6))
      missing_df = df.isnull()
      if missing_df.any().any():
        sns.heatmap(
            missing_df,
            cbar=False,
            cmap="viridis",
            yticklabels=False,
            ax=ax,
        )
        ax.set_title("Missing Values Heatmap (Yellow = Missing)", fontsize=11, pad=12)
        plt.xticks(rotation=45, ha="right", fontsize=8)
      else:
        ax.text(0.5, 0.5, "No Missing Values Found in Dataset", ha="center", va="center", color=GREEN, fontsize=12)
        ax.set_title("Missing Values Heatmap", fontsize=11, pad=12)
      img_b64 = fig_to_b64(fig)

    elif chart_type == "bar":
      col = column if column in df.columns else (cat_cols[0] if cat_cols else None)
      num_col = column_y if column_y in num_cols else (num_cols[0] if num_cols else None)
      fig, ax = plt.subplots(figsize=(9, 5))
      if col and num_col:
        grouped = df.groupby(col)[num_col].mean().sort_values(ascending=False).head(top_n)
        sns.barplot(x=grouped.index.astype(str), y=grouped.values, palette=PALETTE[:len(grouped)], ax=ax)
        ax.set_title(f"Bar Chart — Average {num_col} by {col} (Top {top_n})")
        ax.set_ylabel(f"Mean {num_col}")
        plt.xticks(rotation=35, ha="right")
      elif col:
        counts = df[col].value_counts().head(top_n)
        sns.barplot(x=counts.index.astype(str), y=counts.values, palette=PALETTE[:len(counts)], ax=ax)
        ax.set_title(f"Top {top_n} Bar Chart — {col}")
        plt.xticks(rotation=35, ha="right")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "pie":
      col = column if column in df.columns else (cat_cols[0] if cat_cols else None)
      fig, ax = plt.subplots(figsize=(7, 7))
      if col:
        counts = df[col].value_counts().head(top_n)
        ax.pie(counts.values, labels=counts.index.astype(str), colors=PALETTE[:len(counts)], autopct="%1.1f%%", startangle=140)
        ax.set_title(f"Distribution of {col}")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "donut":
      col = column if column in df.columns else (cat_cols[0] if cat_cols else None)
      fig, ax = plt.subplots(figsize=(7, 7))
      if col:
        counts = df[col].value_counts().head(top_n)
        ax.pie(counts.values, labels=counts.index.astype(str), colors=PALETTE[:len(counts)], autopct="%1.1f%%", startangle=140, pctdistance=0.75)
        centre_circle = plt.Circle((0, 0), 0.50, fc=DARK_BG)
        ax.add_artist(centre_circle)
        ax.set_title(f"Donut Chart — {col}")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "line":
      fig, ax = plt.subplots(figsize=(10, 5))
      cols_to_plot = [column] if column in num_cols else num_cols[:4]
      for i, c in enumerate(cols_to_plot):
        ax.plot(df[c].values, label=c, color=PALETTE[i % len(PALETTE)], linewidth=1.5, alpha=0.85)
      ax.set_xlabel("Row Index")
      ax.set_ylabel("Value")
      ax.set_title("Line Trend Chart")
      ax.legend()
      img_b64 = fig_to_b64(fig)

    elif chart_type == "area":
      fig, ax = plt.subplots(figsize=(10, 5))
      cols_to_plot = [column] if column in num_cols else num_cols[:4]
      for i, c in enumerate(cols_to_plot):
        y_vals = df[c].values
        ax.fill_between(range(len(y_vals)), y_vals, alpha=0.35, color=PALETTE[i % len(PALETTE)])
        ax.plot(y_vals, label=c, color=PALETTE[i % len(PALETTE)], linewidth=1.5)
      ax.set_xlabel("Row Index")
      ax.set_ylabel("Value")
      ax.set_title("Area Trend Chart")
      ax.legend()
      img_b64 = fig_to_b64(fig)

    elif chart_type == "step":
      fig, ax = plt.subplots(figsize=(10, 5))
      cols_to_plot = [column] if column in num_cols else num_cols[:4]
      for i, c in enumerate(cols_to_plot):
        ax.step(range(len(df[c])), df[c].values, label=c, where="mid", color=PALETTE[i % len(PALETTE)], linewidth=1.8)
      ax.set_xlabel("Row Index")
      ax.set_ylabel("Value")
      ax.set_title("Step Chart Trend")
      ax.legend()
      img_b64 = fig_to_b64(fig)

    elif chart_type == "ecdf":
      col = column if column in num_cols else (num_cols[0] if num_cols else None)
      fig, ax = plt.subplots(figsize=(9, 5))
      if col:
        sns.ecdfplot(data=df, x=col, ax=ax, color=ACCENT, linewidth=2)
        ax.set_title(f"Empirical Cumulative Distribution (ECDF) — {col}")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "barh":
      col = column if column in df.columns else (cat_cols[0] if cat_cols else None)
      num_col = column_y if column_y in num_cols else (num_cols[0] if num_cols else None)
      fig, ax = plt.subplots(figsize=(9, 5))
      if col and num_col:
        grouped = df.groupby(col)[num_col].mean().sort_values(ascending=True).tail(top_n)
        sns.barplot(y=grouped.index.astype(str), x=grouped.values, palette=PALETTE[:len(grouped)], ax=ax)
        ax.set_title(f"Horizontal Bar Chart — Average {num_col} by {col} (Top {top_n})")
        ax.set_xlabel(f"Mean {num_col}")
        ax.set_ylabel(col)
      elif col:
        counts = df[col].value_counts().head(top_n).sort_values(ascending=True)
        sns.barplot(y=counts.index.astype(str), x=counts.values, palette=PALETTE[:len(counts)], ax=ax)
        ax.set_title(f"Horizontal Bar Chart — {col} (Top {top_n})")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "countplot":
      col = column if column in df.columns else (cat_cols[0] if cat_cols else None)
      fig, ax = plt.subplots(figsize=(9, 5))
      if col:
        counts = df[col].value_counts().head(top_n)
        sns.countplot(data=df, x=col, order=counts.index, palette=PALETTE, ax=ax)
        ax.set_title(f"Count Plot — Category Frequency ({col})")
        plt.xticks(rotation=35, ha="right")
      img_b64 = fig_to_b64(fig)

    elif chart_type == "stacked_bar":
      col1 = column if column in df.columns else (cat_cols[0] if cat_cols else df.columns[0])
      col2 = column_y if (column_y in df.columns and column_y != col1) else (cat_cols[1] if len(cat_cols) > 1 else None)
      fig, ax = plt.subplots(figsize=(9, 5))
      if col1 and col2:
        ct = pd.crosstab(df[col1], df[col2]).head(top_n)
        ct.plot(kind="bar", stacked=True, ax=ax, colormap="viridis")
        ax.set_title(f"Stacked Bar Chart — {col1} vs {col2}")
        plt.xticks(rotation=35, ha="right")
      elif col1 and num_cols:
        num_c = num_cols[0]
        df_temp = df[[col1, num_c]].dropna().copy()
        try:
          df_temp["Level"] = pd.qcut(df_temp[num_c], q=3, labels=["Low", "Medium", "High"], duplicates="drop")
          ct = pd.crosstab(df_temp[col1], df_temp["Level"]).head(top_n)
          ct.plot(kind="bar", stacked=True, ax=ax, colormap="viridis")
          ax.set_title(f"Stacked Bar Chart — {col1} by {num_c} Range")
        except Exception:
          counts = df[col1].value_counts().head(top_n)
          ax.bar(counts.index.astype(str), counts.values, color=ACCENT)
          ax.set_title(f"Stacked Bar Chart — {col1}")
        plt.xticks(rotation=35, ha="right")
      else:
        col = col1
        counts = df[col].value_counts().head(top_n)
        ax.bar(counts.index.astype(str), counts.values, color=ACCENT)
        ax.set_title(f"Stacked Bar Chart — {col}")
        plt.xticks(rotation=35, ha="right")
      img_b64 = fig_to_b64(fig)

    else:
      fig, ax = plt.subplots(figsize=(9, 5))
      if num_cols:
        sns.histplot(data=df, x=num_cols[0], bins=bins, ax=ax, color=ACCENT)
        ax.set_title(f"Histogram of {num_cols[0]}")
      img_b64 = fig_to_b64(fig)

    return Response({
        "chart_type": chart_type,
        "image": img_b64,
        "column": column,
    })

  except Exception as exc:
    return Response({"message": str(exc)}, status=400)


# ─── Model Training Helpers & Classification Models ───────────────────────────
def build_preprocessor(x_train):
  """Build a ColumnTransformer fitted on training data only with scaling for distance models."""
  numeric_features = x_train.select_dtypes(include=np.number).columns.tolist()
  categorical_features = [c for c in x_train.columns if c not in numeric_features]
  return ColumnTransformer(transformers=[
      (
          "numeric",
          Pipeline(steps=[
              ("imputer", SimpleImputer(strategy="median")),
              ("scaler", StandardScaler()),
          ]),
          numeric_features,
      ),
      (
          "categorical",
          Pipeline(steps=[
              ("imputer", SimpleImputer(strategy="most_frequent")),
              ("encoder", OneHotEncoder(handle_unknown="ignore")),
          ]),
          categorical_features,
      ),
  ])


@api_view(["POST"])
def train_models(request):
  try:
    file_path = request.data.get("file_path", "")
    df = load_dataset(file_path)
    target = request.data.get("target_column")
    requested_task_type = request.data.get("task_type", "auto")
    task_type = requested_task_type

    if target not in df.columns:
      return Response({"message": "Target column is missing or invalid"}, status=400)

    df = df.dropna(subset=[target])
    x, y = df.drop(columns=[target]), df[target]

    if task_type == "auto":
      task_type = "regression" if pd.api.types.is_numeric_dtype(y) else "classification"

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
    preprocessor = build_preprocessor(x_train)

    if requested_task_type == "auto":
      if task_type == "regression":
        candidates = {
            "Linear Regression": LinearRegression(),
            "Polynomial Regression": Pipeline([
                ("poly", PolynomialFeatures(degree=2, include_bias=False)),
                ("linear", LinearRegression()),
            ]),
            "K-Nearest Neighbors (KNN)": KNeighborsRegressor(n_neighbors=5),
            "Decision Tree Classifier": DecisionTreeRegressor(random_state=42),
            "Random Forest Classifier": RandomForestRegressor(n_estimators=100, random_state=42),
            "Support Vector Machine (SVR)": SVR(kernel="rbf"),
        }
      else:
        candidates = {
            "Logistic Regression": LogisticRegression(max_iter=1000),
            "K-Nearest Neighbors (KNN)": KNeighborsClassifier(n_neighbors=5),
            "Decision Tree Classifier": DecisionTreeClassifier(random_state=42),
            "Random Forest Classifier": RandomForestClassifier(n_estimators=100, random_state=42),
            "Support Vector Machine (SVM)": SVC(kernel="rbf", probability=True, random_state=42),
            "Gradient Boosting Classifier": GradientBoostingClassifier(n_estimators=100, random_state=42),
        }
    elif requested_task_type == "regression":
      candidates = {
          "Linear Regression": LinearRegression(),
          "Polynomial Regression": Pipeline([
              ("poly", PolynomialFeatures(degree=2, include_bias=False)),
              ("linear", LinearRegression()),
          ]),
      }
    else:  # classification
      candidates = {
          "K-Nearest Neighbors (KNN)": KNeighborsClassifier(n_neighbors=5),
          "Decision Tree Classifier": DecisionTreeClassifier(random_state=42),
          "Random Forest Classifier": RandomForestClassifier(n_estimators=100, random_state=42),
          "Support Vector Machine (SVM)": SVC(kernel="rbf", probability=True, random_state=42),
      }

    results = []
    best_score = -float("inf")
    best_pipeline = None
    best_name = None

    for name, model in candidates.items():
      pipeline = Pipeline([("preprocessor", preprocessor), ("model", model)])
      pipeline.fit(x_train, y_train)
      preds = pipeline.predict(x_test)

      if task_type == "regression":
        score = round(float(r2_score(y_test, preds)), 4)
        rmse = round(float(np.sqrt(mean_squared_error(y_test, preds))), 4)
        results.append({
            "modelName": name,
            "taskType": task_type,
            "metric": "R2",
            "score": score,
            "rmse": rmse,
        })
      else:
        score = round(float(accuracy_score(y_test, preds)), 4)
        f1 = round(float(f1_score(y_test, preds, average="weighted")), 4)
        results.append({
            "modelName": name,
            "taskType": task_type,
            "metric": "Accuracy",
            "score": score,
            "f1": f1,
        })

      if score > best_score:
        best_score = score
        best_pipeline = pipeline
        best_name = name

    # Save best model to disk
    if best_pipeline is not None:
      model_file = _model_path(file_path, target)
      joblib.dump(best_pipeline, model_file)

      meta = {
          "task_type": task_type,
          "target": target,
          "best_model": best_name,
          "best_score": best_score,
          "feature_names": list(x.columns),
          "results": results,
      }
      _meta_path(file_path, target).write_text(json.dumps(meta, indent=2))

    return Response({"taskType": task_type, "results": results, "bestModel": best_name})

  except Exception as exc:
    tb = traceback.format_exc()
    print("[Train Error]\n", tb)
    return Response({"message": str(exc)}, status=400)


# ─── Feature Importance & NxN Relation Matrix ──────────────────────────────────
@api_view(["POST"])
def feature_importance(request):
  try:
    file_path = request.data.get("file_path", "")
    target = request.data.get("target_column", "")
    df = load_dataset(file_path)

    encoded_df = pd.DataFrame()
    for col in df.columns:
      if pd.api.types.is_numeric_dtype(df[col]):
        encoded_df[col] = df[col].fillna(df[col].median() if not df[col].dropna().empty else 0)
      else:
        le = LabelEncoder()
        encoded_df[col] = le.fit_transform(df[col].fillna("Missing").astype(str))

    full_corr_df = encoded_df.corr().round(2).fillna(0)
    corr_matrix = full_corr_df.to_dict()
    all_features = list(full_corr_df.columns)

    top_pairs = []
    cols = list(full_corr_df.columns)
    for i in range(len(cols)):
      for j in range(i + 1, len(cols)):
        c1, c2 = cols[i], cols[j]
        val = float(full_corr_df.loc[c1, c2])
        top_pairs.append({"feature1": c1, "feature2": c2, "correlation": val, "abs_corr": abs(val)})

    top_pairs = sorted(top_pairs, key=lambda x: x["abs_corr"], reverse=True)[:20]

    num_df = df.select_dtypes(include=np.number)
    if target not in df.columns:
      target = num_df.columns[-1] if not num_df.empty else df.columns[-1]

    df_clean = df.dropna(subset=[target])
    x, y = df_clean.drop(columns=[target]), df_clean[target]

    meta_file = _meta_path(file_path, target)
    model_file = _model_path(file_path, target)

    if model_file.exists():
      pipeline = joblib.load(model_file)
      estimator = pipeline.named_steps["model"]
      if hasattr(estimator, "feature_importances_"):
        importances = estimator.feature_importances_
        try:
          preprocessor = pipeline.named_steps["preprocessor"]
          transformed_names = preprocessor.get_feature_names_out()
          fi_list = [{
              "feature": name.split("__")[-1],
              "importance": round(float(imp), 6),
          } for name, imp in zip(transformed_names, importances)]
        except Exception:
          fi_list = [{
              "feature": f"feature_{i}",
              "importance": round(float(imp), 6),
          } for i, imp in enumerate(importances)]

        fi_list = sorted(fi_list, key=lambda d: d["importance"], reverse=True)[:20]
        return Response({
            "source": "saved_model",
            "target_used": target,
            "all_features": all_features,
            "feature_importance": fi_list,
            "correlations": corr_matrix,
            "top_pairs": top_pairs,
        })

    # Fallback RF
    task_type = "regression" if pd.api.types.is_numeric_dtype(y) else "classification"
    x_train, x_test, y_train, _ = train_test_split(x, y, test_size=0.2, random_state=42)
    preprocessor = build_preprocessor(x_train)
    rf = (
        RandomForestRegressor(n_estimators=50, random_state=42)
        if task_type == "regression"
        else RandomForestClassifier(n_estimators=50, random_state=42)
    )
    pipeline = Pipeline([("preprocessor", preprocessor), ("model", rf)])
    pipeline.fit(x_train, y_train)

    try:
      transformed_names = pipeline.named_steps["preprocessor"].get_feature_names_out()
      fi_list = [{
          "feature": name.split("__")[-1],
          "importance": round(float(imp), 6),
      } for name, imp in zip(transformed_names, rf.feature_importances_)]
    except Exception:
      fi_list = [
          {"feature": f"feature_{i}", "importance": round(float(imp), 6)}
          for i, imp in enumerate(rf.feature_importances_)
      ]

    fi_list = sorted(fi_list, key=lambda d: d["importance"], reverse=True)[:20]
    return Response({
        "source": "computed",
        "target_used": target,
        "all_features": all_features,
        "feature_importance": fi_list,
        "correlations": corr_matrix,
        "top_pairs": top_pairs,
    })

  except Exception as exc:
    return Response({"message": str(exc)}, status=400)


# ─── Predictions Engine ───────────────────────────────────────────────────────
@api_view(["POST"])
def run_prediction(request):
  try:
    file_path = request.data.get("file_path", "")
    target = request.data.get("target_column", "")
    rows = request.data.get("rows", [])

    if not rows:
      return Response({"message": "No rows provided for prediction"}, status=400)

    model_file = _model_path(file_path, target)

    if not model_file.exists():
      return Response({
          "message": "No trained model found for this dataset and target. Please train models first.",
          "hint": "Go to the Models tab and click 'Train All Models'.",
      }, status=404)

    pipeline = joblib.load(model_file)

    input_df = pd.DataFrame(rows)

    try:
      df_original = load_dataset(file_path)
      expected_cols = [c for c in df_original.columns if c != target]

      if target in input_df.columns:
        input_df = input_df.drop(columns=[target])

      for col in expected_cols:
        if col not in input_df.columns:
          input_df[col] = np.nan

      input_df = input_df[expected_cols]
      input_df = input_df.replace(r"^\s*$", np.nan, regex=True)

      for col in expected_cols:
        if pd.api.types.is_numeric_dtype(df_original[col]):
          input_df[col] = pd.to_numeric(input_df[col], errors="coerce")
    except Exception:
      pass

    preds = pipeline.predict(input_df)

    return Response({
        "message": "Predictions generated successfully",
        "rowsReceived": len(rows),
        "predictions": [{
            "row": i + 1,
            "prediction": (
                round(float(p), 4)
                if isinstance(p, (np.floating, float, np.integer, int))
                else str(p)
            ),
        } for i, p in enumerate(preds)],
    })

  except Exception as exc:
    tb = traceback.format_exc()
    print("[Prediction Error]\n", tb)
    return Response({"message": str(exc)}, status=400)


# ─── Report Generation ────────────────────────────────────────────────────────
@api_view(["POST"])
def generate_report(request):
  try:
    file_path = request.data.get("file_path", "")
    target = request.data.get("target_column", "")
    project_name = request.data.get("project_name", "InsightLab Project")

    df = None
    if file_path:
      try:
        df = load_dataset(file_path)
      except Exception as load_err:
        print("[generate_report load warning]", load_err)

    if df is None:
      # Build synthetic demo dataframe if dataset path is unreadable
      df = pd.DataFrame({
          "Sample_Feature": range(1, 101),
          "Target": [i * 2.5 for i in range(1, 101)],
      })

    num_df = df.select_dtypes(include=np.number)
    cat_df = df.select_dtypes(include=["object", "bool"])

    meta_file = _meta_path(file_path, target) if "_meta_path" in globals() else (MODELS_DIR / f"{hashlib.md5(f'{file_path}_{target}'.encode()).hexdigest()}_meta.json")
    best_model_name = "Not trained yet"
    best_score = "N/A"
    models_list = []

    if meta_file.exists():
      try:
        mdata = json.loads(meta_file.read_text())
        best_model_name = mdata.get("best_model", "Unknown")
        best_score = str(mdata.get("best_score", "N/A"))
        models_list = mdata.get("models", [])
      except Exception:
        pass

    missing_total = int(df.isnull().sum().sum())
    missing_pct = round((missing_total / (len(df) * len(df.columns))) * 100, 2) if len(df) and len(df.columns) else 0
    duplicate_rows = int(df.duplicated().sum())

    # Build automated EDA insights
    insights = []
    insights.append(f"Dataset contains {len(df):,} rows and {len(df.columns)} columns ({len(num_df.columns)} numeric, {len(cat_df.columns)} categorical).")
    if missing_total > 0:
      insights.append(f"Detected {missing_total:,} missing values ({missing_pct}% of total cells across dataset).")
    else:
      insights.append("Dataset is completely clean with 0 missing values across all features.")
    if duplicate_rows > 0:
      insights.append(f"Identified {duplicate_rows:,} duplicate row records requiring cleaning.")
    else:
      insights.append("Zero duplicate rows detected in dataset.")
    if target and target in df.columns:
      insights.append(f"Target variable selected: '{target}' ({str(df[target].dtype)} dtype).")

    # Build recommendations
    recommendations = []
    if missing_total > 0:
      recommendations.append("Apply missing value imputation (Median for numeric, Mode for categorical) in Data Cleaning tab.")
    if duplicate_rows > 0:
      recommendations.append("Drop duplicate rows to prevent overfitting during model training.")
    if num_df.shape[1] > 0:
      recommendations.append("Normalize numeric variables with Min-Max or Standard Scaling to improve distance-based model convergence.")
    if best_model_name != "Not trained yet":
      recommendations.append(f"Deploy the top-performing '{best_model_name}' (Score: {best_score}) for real-time inference predictions.")

    return Response({
        "title": f"{project_name} — Executive Machine Learning Report",
        "status": "generated",
        "generated_at": pd.Timestamp.now().isoformat(),
        "summary": {
            "rows": len(df),
            "columns": len(df.columns),
            "targetColumn": target or "Not Selected",
            "bestModel": best_model_name,
            "bestScore": best_score,
            "missingCells": missing_total,
            "duplicateRows": duplicate_rows,
        },
        "dataset": {
            "rows": len(df),
            "columns": len(df.columns),
            "total_missing": missing_total,
            "missing_pct": missing_pct,
            "duplicate_rows": duplicate_rows,
            "numeric_count": len(num_df.columns),
            "categorical_count": len(cat_df.columns),
        },
        "eda": {
            "insights": insights,
        },
        "models": {
            "best_model": best_model_name,
            "best_score": best_score,
            "models": models_list,
        },
        "recommendations": recommendations,
        "sections": [
            {
                "id": 1,
                "title": "Dataset Diagnostics & Health",
                "content": f"Dataset containing {len(df):,} records across {len(df.columns)} features. Total missing cell count: {missing_total:,} ({missing_pct}%). Duplicate records: {duplicate_rows:,}."
            },
            {
                "id": 2,
                "title": "Exploratory Data Analysis",
                "content": f"Numeric features: {len(num_df.columns)}, Categorical features: {len(cat_df.columns)}. Target column specified: '{target or 'None'}'. Feature distributions and correlation matrices analyzed."
            },
            {
                "id": 3,
                "title": "Model Benchmarking & Selection",
                "content": f"Optimal performing algorithm: '{best_model_name}' with test set evaluation score of {best_score}."
            },
            {
                "id": 4,
                "title": "Deployment & Inference Status",
                "content": "Model pipeline serialized to disk via Joblib. Instant single-row and batch inference enabled via REST predictions API."
            }
        ],
    })

  except Exception as exc:
    tb = traceback.format_exc()
    print("[Report Error]", tb)
    return Response({"message": str(exc)}, status=400)
