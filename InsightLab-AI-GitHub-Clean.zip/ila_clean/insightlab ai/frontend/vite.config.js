import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],

  build: {
    // Increase warning threshold to 800KB while we work on splitting
    chunkSizeWarningLimit: 800,

    rollupOptions: {
      output: {
        // Manual chunk splitting — keeps vendor libs separate from app code
        manualChunks: {
          // React core
          "vendor-react": ["react", "react-dom"],

          // Recharts (large charting library)
          "vendor-recharts": ["recharts"],

          // Lucide icons
          "vendor-lucide": ["lucide-react"],

          // App view components (lazy-loadable in future)
          "views": [
            "./src/components/AuthScreen",
            "./src/components/Sidebar",
            "./src/components/DatasetView",
            "./src/components/CleaningView",
            "./src/components/EdaView",
            "./src/components/FeaturesView",
            "./src/components/ModelView",
            "./src/components/PredictionsView",
            "./src/components/VisualizationView",
            "./src/components/ReportView",
            "./src/components/SettingsView",
          ],
        },
      },
    },
  },

  server: {
    host: "0.0.0.0",
    port: 5173,
  },
});
