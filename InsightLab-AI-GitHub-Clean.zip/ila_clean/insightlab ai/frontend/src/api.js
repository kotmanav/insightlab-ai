const NODE_API = import.meta.env.VITE_NODE_API_URL || "http://localhost:5000/api";
const ML_API   = import.meta.env.VITE_ML_API_URL   || "http://localhost:8000/api";

function authHeaders() {
  const token = localStorage.getItem("insightlab_token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed");
  return data;
}

export const api = {
  // ── Auth ──────────────────────────────────────────────
  async login(payload) {
    return request(`${NODE_API}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  },

  async signup(payload) {
    return request(`${NODE_API}/auth/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  },

  async verifyOtp(payload) {
    return request(`${NODE_API}/auth/verify-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  },

  async resendOtp(payload) {
    return request(`${NODE_API}/auth/resend-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  },

  async forgotPassword(payload) {
    return request(`${NODE_API}/auth/forgot-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  },

  async resetPassword(payload) {
    return request(`${NODE_API}/auth/reset-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  },

  // ── Projects ──────────────────────────────────────────
  async listProjects() {
    return request(`${NODE_API}/projects`, {
      headers: { ...authHeaders() },
    });
  },

  async createProject(formData) {
    return request(`${NODE_API}/projects`, {
      method: "POST",
      headers: { ...authHeaders() },
      body: formData,
    });
  },

  async updateProject(id, data) {
    return request(`${NODE_API}/projects/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(data),
    });
  },

  async deleteProject(id) {
    return request(`${NODE_API}/projects/${id}`, {
      method: "DELETE",
      headers: { ...authHeaders() },
    });
  },

  // Save ML experiment results to MongoDB
  async saveExperiments(id, results, taskType) {
    return request(`${NODE_API}/projects/${id}/experiments`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify({ results, taskType }),
    });
  },

  // Live Dataset AI Chat Assistant
  async chatWithAi(id, message, history = [], apiKey = "") {
    return request(`${NODE_API}/projects/${id}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify({ message, history, apiKey }),
    });
  },

  // ── ML — EDA ──────────────────────────────────────────
  async runEda(project) {
    return request(`${ML_API}/eda/summary/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file_path: project.dataset?.path }),
    });
  },

  // ── ML — Cleaning ─────────────────────────────────────
  async cleanDataset(project, operation, column = null, fillValue = null) {
    const ops = Array.isArray(operation) ? operation : [operation];
    return request(`${ML_API}/datasets/clean/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        file_path:  project.dataset?.path,
        operations: ops,
        operation:  ops[0],
        column:     column || undefined,
        fill_value: fillValue !== null ? fillValue : undefined,
      }),
    });
  },

  // ── ML — Models ───────────────────────────────────────
  async trainModels(project, taskType) {
    return request(`${ML_API}/models/train/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        file_path:     project.dataset?.path,
        target_column: project.targetColumn,
        task_type:     taskType,
      }),
    });
  },

  async getFeatureImportance(project) {
    return request(`${ML_API}/models/feature-importance/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        file_path:     project.dataset?.path,
        target_column: project.targetColumn,
      }),
    });
  },

  // ── ML — Predictions ─────────────────────────────────
  async runPrediction(project, rows) {
    return request(`${ML_API}/predictions/run/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        file_path:     project.dataset?.path,
        target_column: project.targetColumn,
        rows,
      }),
    });
  },

  // ── ML — Visualization ───────────────────────────────
  async visualize(project, chartType, options = {}) {
    return request(`${ML_API}/visualize/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        file_path:  project.dataset?.path,
        chart_type: chartType,
        column:     options.column     || "",
        column_y:   options.column_y   || "",
        hue:        options.hue        || "",
        color_col:  options.color_col  || "",
        size_col:   options.size_col   || "",
        bins:       options.bins       || 30,
        top_n:      options.top_n      || 10,
      }),
    });
  },

  // ── ML — Reports ─────────────────────────────────────
  // FIX: send file_path + target_column so Django can generate real content
  async generateReport(project) {
    return request(`${ML_API}/reports/generate/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        project_name:  project.projectName,
        file_path:     project.dataset?.path,
        target_column: project.targetColumn,
      }),
    });
  },

  async sendReportEmail(email, report, projectName) {
    return request(`${NODE_API}/projects/send-report-email`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify({ email, report, projectName }),
    });
  },
};
