import { Settings, Trash2 } from "lucide-react";
import React, { useState, useEffect } from "react";
import { api } from "../api";

export default function SettingsView({ project, onUpdate, onDelete }) {
  const [saving, setSaving]   = useState(false);
  const [saved, setSaved]     = useState(false);
  const [saveErr, setSaveErr] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [form, setForm] = useState({
    projectName:  project?.projectName  || "",
    description:  project?.description  || "",
    targetColumn: project?.targetColumn || "",
  });

  useEffect(() => {
    setForm({
      projectName:  project?.projectName  || "",
      description:  project?.description  || "",
      targetColumn: project?.targetColumn || "",
    });
  }, [project]);

  const columnNames = project?.dataset?.metadata?.columnNames || [];

  async function save(e) {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    setSaveErr("");
    try {
      const updated = await api.updateProject(project._id, form);
      onUpdate(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (err) {
      setSaveErr(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!window.confirm(`Delete project "${project.projectName}"? This cannot be undone.`)) return;
    setDeleting(true);
    try {
      await api.deleteProject(project._id);
      onDelete(project._id);
    } catch (err) {
      alert("Delete failed: " + err.message);
    } finally {
      setDeleting(false);
    }
  }

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  return (
    <div className="settings-grid fade-in">
      {/* Project Settings */}
      <div className="settings-section">
        <div className="settings-section-header">Project Settings</div>
        <div className="settings-body">
          <form onSubmit={save} style={{ display: "grid", gap: 14 }}>
            <label>
              Project Name
              <input value={form.projectName} onChange={set("projectName")} required />
            </label>

            <label>
              Description
              <textarea value={form.description} onChange={set("description")} rows={3} />
            </label>

            <label>
              Target Column (Prediction Goal)
              {columnNames.length > 0 ? (
                <select value={form.targetColumn} onChange={set("targetColumn")}>
                  <option value="">-- Select Target Column --</option>
                  {columnNames.map((col) => (
                    <option key={col} value={col}>
                      {col}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  value={form.targetColumn}
                  onChange={set("targetColumn")}
                  placeholder="e.g. Price or SalePrice"
                />
              )}
            </label>

            {saveErr && <p className="error-msg">{saveErr}</p>}

            <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 4 }}>
              <button className="btn-primary" type="submit" disabled={saving} style={{ maxWidth: 160 }}>
                {saving ? <span className="spinner" style={{ width: 14, height: 14 }} /> : null}
                {saving ? "Saving…" : "Save Changes"}
              </button>
              {saved && <span style={{ color: "var(--green)", fontSize: "0.85rem", fontWeight: 600 }}>✓ Saved</span>}
            </div>
          </form>
        </div>
      </div>

      {/* Project Info */}
      <div className="settings-section">
        <div className="settings-section-header">Project Info</div>
        <div className="settings-body">
          {[
            { label: "Project ID",    val: project?._id },
            { label: "Status",        val: project?.status },
            { label: "Dataset File",  val: project?.dataset?.originalName || "No dataset" },
            { label: "Dataset Size",  val: project?.dataset?.size ? `${(project.dataset.size / 1024).toFixed(1)} KB` : "—" },
            { label: "Rows",          val: project?.dataset?.metadata?.rows?.toLocaleString() ?? "—" },
            { label: "Columns",       val: project?.dataset?.metadata?.columns ?? "—" },
            { label: "Experiments",   val: project?.experiments?.length ?? 0 },
          ].map(({ label, val }) => (
            <div className="settings-row" key={label}>
              <div>
                <div className="settings-row-label">{label}</div>
              </div>
              <span style={{ fontSize: "0.82rem", color: "var(--text-2)", textAlign: "right", maxWidth: 220, wordBreak: "break-all" }}>
                {val ?? "—"}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="settings-section">
        <div className="settings-section-header" style={{ color: "var(--red)" }}>Danger Zone</div>
        <div className="settings-body">
          <div className="settings-row">
            <div>
              <div className="settings-row-label">Delete Project</div>
              <div className="settings-row-sub">Permanently deletes the project, dataset file, and all results.</div>
            </div>
            <button className="btn btn-danger" onClick={handleDelete} disabled={deleting}>
              {deleting ? <span className="spinner dark" style={{ width: 14, height: 14 }} /> : <Trash2 size={14} />}
              {deleting ? "Deleting…" : "Delete"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
