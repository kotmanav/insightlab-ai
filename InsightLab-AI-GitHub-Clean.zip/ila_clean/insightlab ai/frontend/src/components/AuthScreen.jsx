import { Zap, KeyRound, Mail, ArrowLeft, RefreshCw, CheckCircle2 } from "lucide-react";
import React, { useState } from "react";
import { api } from "../api";

export default function AuthScreen({ onAuthed }) {
  const [mode, setMode] = useState("login"); // 'login' | 'signup' | 'forgot' | 'reset_password'
  const [form, setForm] = useState({ name: "", email: "", password: "", newPassword: "" });
  const [otp, setOtp]   = useState("");
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [targetEmail, setTargetEmail]       = useState("");
  const [infoMsg, setInfoMsg]               = useState("");
  const [error, setError]                   = useState("");
  const [busy, setBusy]                     = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setInfoMsg("");
    setBusy(true);
    try {
      if (mode === "login") {
        try {
          const data = await api.login(form);
          localStorage.setItem("insightlab_token", data.token);
          localStorage.setItem("insightlab_user", JSON.stringify(data.user));
          onAuthed(data.user);
        } catch (err) {
          if (err.message?.includes("OTP") || err.message?.includes("verified")) {
            setTargetEmail(form.email);
            setIsVerifyingOtp(true);
            setInfoMsg("Verification OTP code sent to your email.");
          } else {
            throw err;
          }
        }
      } else if (mode === "signup") {
        const data = await api.signup(form);
        if (data.requireOtp) {
          setTargetEmail(data.email || form.email);
          setIsVerifyingOtp(true);
          setInfoMsg(data.message || "OTP sent to your email address.");
        } else {
          localStorage.setItem("insightlab_token", data.token);
          localStorage.setItem("insightlab_user", JSON.stringify(data.user));
          onAuthed(data.user);
        }
      } else if (mode === "forgot") {
        const data = await api.forgotPassword({ email: form.email });
        setTargetEmail(form.email);
        setMode("reset_password");
        setInfoMsg(data.message || "Password reset OTP sent to your email.");
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleResetPassword(e) {
    e.preventDefault();
    setError("");
    setInfoMsg("");
    setBusy(true);
    try {
      const data = await api.resetPassword({
        email: targetEmail,
        otp,
        newPassword: form.newPassword,
      });
      setInfoMsg(data.message || "Password reset successfully!");

      const loginData = await api.login({ email: targetEmail, password: form.newPassword });
      localStorage.setItem("insightlab_token", loginData.token);
      localStorage.setItem("insightlab_user", JSON.stringify(loginData.user));
      onAuthed(loginData.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleVerifyOtp(e) {
    e.preventDefault();
    setError("");
    setInfoMsg("");
    setBusy(true);
    try {
      const data = await api.verifyOtp({ email: targetEmail, otp });
      localStorage.setItem("insightlab_token", data.token);
      localStorage.setItem("insightlab_user", JSON.stringify(data.user));
      onAuthed(data.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleResendOtp() {
    setError("");
    setInfoMsg("");
    setBusy(true);
    try {
      const res = mode === "reset_password"
        ? await api.forgotPassword({ email: targetEmail })
        : await api.resendOtp({ email: targetEmail });
      setInfoMsg(res.message || "New OTP sent to your email address.");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  return (
    <main className="auth-shell">
      <div className="auth-panel">
        <div className="auth-brand">
          <div className="logo-badge">
            <Zap size={13} />
            AI-Powered Data Science Workbench
          </div>
          <h1>InsightLab AI</h1>
          <p>
            Upload datasets, run automated EDA, train multiple ML models, compare results,
            make predictions, and generate professional reports — all from one workspace.
          </p>
          <div className="auth-features">
            {[
              "Automated exploratory data analysis",
              "Multi-model training & comparison",
              "Feature importance & engineering",
              "One-click report generation",
            ].map((f) => (
              <div className="auth-feature-item" key={f}>
                <span className="dot" />
                {f}
              </div>
            ))}
          </div>
        </div>

        <div className="auth-card">
          {!isVerifyingOtp && mode !== "reset_password" ? (
            <>
              <div className="segmented" style={{ marginBottom: 18 }}>
                <button
                  type="button"
                  className={mode === "login" ? "active" : ""}
                  onClick={() => { setMode("login"); setError(""); setInfoMsg(""); }}
                >
                  Login
                </button>
                <button
                  type="button"
                  className={mode === "signup" ? "active" : ""}
                  onClick={() => { setMode("signup"); setError(""); setInfoMsg(""); }}
                >
                  Sign Up
                </button>
              </div>

              {infoMsg && (
                <div style={{ marginBottom: 12, padding: "8px 12px", background: "var(--green-bg)", border: "1px solid rgba(63,185,80,0.3)", borderRadius: "var(--radius)", fontSize: "0.82rem", color: "var(--green)", textAlign: "center" }}>
                  <CheckCircle2 size={14} style={{ inlineSize: "auto", margin: "-2px 4px 0 0" }} />
                  {infoMsg}
                </div>
              )}

              <form onSubmit={submit} className="form-group" autoComplete="off">
                {mode === "signup" && (
                  <label>
                    Full Name
                    <input
                      placeholder="Jay Patel"
                      value={form.name}
                      onChange={set("name")}
                      autoComplete="off"
                      required
                    />
                  </label>
                )}
                <label>
                  Email Address
                  <input
                    type="email"
                    placeholder="you@example.com"
                    value={form.email}
                    onChange={set("email")}
                    autoComplete="off"
                    required
                  />
                </label>
                {mode !== "forgot" && (
                  <label>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span>Password</span>
                      {mode === "login" && (
                        <button
                          type="button"
                          style={{ background: "none", border: "none", color: "var(--accent)", fontSize: "0.78rem", cursor: "pointer", padding: 0 }}
                          onClick={() => { setMode("forgot"); setError(""); setInfoMsg(""); }}
                        >
                          Forgot Password?
                        </button>
                      )}
                    </div>
                    <input
                      type="password"
                      placeholder="••••••••"
                      value={form.password}
                      onChange={set("password")}
                      autoComplete="new-password"
                      required
                      minLength={6}
                    />
                  </label>
                )}
                {error && <p className="error-msg">{error}</p>}
                <button className="btn-primary" type="submit" disabled={busy} style={{ marginTop: 4 }}>
                  {busy ? <span className="spinner" /> : null}
                  {busy
                    ? "Please wait…"
                    : mode === "login"
                    ? "Login"
                    : mode === "forgot"
                    ? "Send Reset OTP Code"
                    : "Create Account & Send OTP"}
                </button>
                {mode === "forgot" && (
                  <button
                    type="button"
                    className="btn btn-secondary"
                    style={{ marginTop: 8 }}
                    onClick={() => { setMode("login"); setError(""); setInfoMsg(""); }}
                  >
                    <ArrowLeft size={14} /> Back to Sign In
                  </button>
                )}
              </form>
            </>
          ) : mode === "reset_password" ? (
            <div className="form-group fade-in">
              <button
                type="button"
                className="btn btn-secondary"
                style={{ alignSelf: "flex-start", minHeight: 30, padding: "4px 10px", fontSize: "0.78rem" }}
                onClick={() => { setMode("login"); setError(""); setInfoMsg(""); }}
              >
                <ArrowLeft size={14} /> Back to Sign In
              </button>
              <div style={{ textAlign: "center", margin: "12px 0 8px" }}>
                <div className="brand-icon" style={{ width: 44, height: 44, margin: "0 auto 10px", background: "var(--accent-glow)", color: "var(--accent)" }}>
                  <KeyRound size={22} />
                </div>
                <h3 style={{ fontSize: "1.15rem", fontWeight: 800 }}>Reset Your Password</h3>
                <p style={{ fontSize: "0.82rem", color: "var(--text-2)", marginTop: 4 }}>
                  We sent a 6-digit reset code to<br />
                  <strong style={{ color: "var(--text)" }}>{targetEmail}</strong>
                </p>
              </div>

              {infoMsg && (() => {
                const otpMatch = infoMsg.match(/\b(\d{6})\b/);
                if (otpMatch) {
                  return (
                    <div style={{ padding: "14px 16px", background: "rgba(255,180,0,0.12)", border: "2px solid rgba(255,180,0,0.6)", borderRadius: "var(--radius)", textAlign: "center" }}>
                      <p style={{ fontSize: "0.78rem", color: "var(--text-2)", margin: "0 0 6px" }}>
                        ⚠️ Email delivery unavailable. Use this reset code:
                      </p>
                      <div style={{ fontSize: "2.2rem", fontWeight: 900, letterSpacing: "10px", color: "#FFB400", fontFamily: "monospace", margin: "4px 0" }}>
                        {otpMatch[1]}
                      </div>
                      <p style={{ fontSize: "0.72rem", color: "var(--text-2)", margin: "4px 0 0" }}>
                        Enter this code below along with your new password
                      </p>
                    </div>
                  );
                }
                return (
                  <div style={{ padding: "8px 12px", background: "var(--green-bg)", border: "1px solid rgba(63,185,80,0.3)", borderRadius: "var(--radius)", fontSize: "0.82rem", color: "var(--green)", textAlign: "center" }}>
                    <CheckCircle2 size={14} style={{ inlineSize: "auto", margin: "-2px 4px 0 0" }} />
                    {infoMsg}
                  </div>
                );
              })()}

              <form onSubmit={handleResetPassword} className="form-group" style={{ marginTop: 8 }}>
                <label>
                  6-Digit Reset Code
                  <input
                    type="text"
                    maxLength={6}
                    placeholder="123456"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    style={{ textAlign: "center", fontSize: "1.2rem", letterSpacing: "6px", fontWeight: "800" }}
                    required
                    autoFocus
                  />
                </label>
                <label>
                  New Password
                  <input
                    type="password"
                    placeholder="At least 6 characters"
                    value={form.newPassword}
                    onChange={set("newPassword")}
                    required
                    minLength={6}
                  />
                </label>
                {error && <p className="error-msg">{error}</p>}
                <button className="btn-primary" type="submit" disabled={busy || otp.length < 6 || form.newPassword.length < 6} style={{ minHeight: 42 }}>
                  {busy ? <span className="spinner" /> : null}
                  {busy ? "Resetting Password…" : "Reset Password & Sign In"}
                </button>
                <button type="button" className="btn btn-secondary" onClick={handleResendOtp} disabled={busy} style={{ fontSize: "0.8rem" }}>
                  <RefreshCw size={13} /> Resend Reset Code
                </button>
              </form>
            </div>
          ) : (
            <div className="form-group fade-in">
              <button
                type="button"
                className="btn btn-secondary"
                style={{ alignSelf: "flex-start", minHeight: 30, padding: "4px 10px", fontSize: "0.78rem" }}
                onClick={() => setIsVerifyingOtp(false)}
              >
                <ArrowLeft size={14} /> Back
              </button>

              <div style={{ textAlign: "center", margin: "12px 0 8px" }}>
                <div className="brand-icon" style={{ width: 44, height: 44, margin: "0 auto 10px", background: "var(--accent-glow)", color: "var(--accent)" }}>
                  <KeyRound size={22} />
                </div>
                <h3 style={{ fontSize: "1.15rem", fontWeight: 800 }}>Enter Verification OTP</h3>
                <p style={{ fontSize: "0.82rem", color: "var(--text-2)", marginTop: 4 }}>
                  We sent a 6-digit verification code to<br />
                  <strong style={{ color: "var(--text)" }}>{targetEmail}</strong>
                </p>
              </div>

              {infoMsg && (() => {
                const otpMatch = infoMsg.match(/\b(\d{6})\b/);
                if (otpMatch) {
                  return (
                    <div style={{ padding: "14px 16px", background: "rgba(255,180,0,0.12)", border: "2px solid rgba(255,180,0,0.6)", borderRadius: "var(--radius)", textAlign: "center" }}>
                      <p style={{ fontSize: "0.78rem", color: "var(--text-2)", margin: "0 0 6px" }}>
                        ⚠️ Email delivery unavailable. Use this code:
                      </p>
                      <div style={{ fontSize: "2.2rem", fontWeight: 900, letterSpacing: "10px", color: "#FFB400", fontFamily: "monospace", margin: "4px 0" }}>
                        {otpMatch[1]}
                      </div>
                      <p style={{ fontSize: "0.72rem", color: "var(--text-2)", margin: "4px 0 0" }}>
                        Enter this 6-digit code in the box below
                      </p>
                    </div>
                  );
                }
                return (
                  <div style={{ padding: "8px 12px", background: "var(--green-bg)", border: "1px solid rgba(63,185,80,0.3)", borderRadius: "var(--radius)", fontSize: "0.82rem", color: "var(--green)", textAlign: "center" }}>
                    <CheckCircle2 size={14} style={{ inlineSize: "auto", margin: "-2px 4px 0 0" }} />
                    {infoMsg}
                  </div>
                );
              })()}

              <form onSubmit={handleVerifyOtp} className="form-group" style={{ marginTop: 8 }}>
                <label>
                  6-Digit OTP Code
                  <input
                    type="text"
                    maxLength={6}
                    placeholder="123456"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    style={{ textAlign: "center", fontSize: "1.2rem", letterSpacing: "6px", fontWeight: "800" }}
                    required
                    autoFocus
                  />
                </label>

                {error && <p className="error-msg">{error}</p>}

                <button className="btn-primary" type="submit" disabled={busy || otp.length < 6} style={{ minHeight: 42 }}>
                  {busy ? <span className="spinner" /> : null}
                  {busy ? "Verifying OTP…" : "Verify & Activate Account"}
                </button>

                <button type="button" className="btn btn-secondary" onClick={handleResendOtp} disabled={busy} style={{ fontSize: "0.8rem" }}>
                  <RefreshCw size={13} /> Resend OTP Code
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
