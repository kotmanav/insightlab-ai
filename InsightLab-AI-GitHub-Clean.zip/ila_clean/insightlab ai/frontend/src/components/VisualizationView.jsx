import { Image, ZoomIn, ZoomOut, RotateCcw, Maximize2 } from "lucide-react";
import React, { useState } from "react";
import { api } from "../api";

const CHART_TYPES = [
  { id: "histogram",     label: "Histogram",           group: "Distribution", needsNum: true },
  { id: "kde",           label: "KDE Density",          group: "Distribution", needsNum: true },
  { id: "dist_grid",     label: "Distribution Grid",    group: "Distribution", needsNum: true },
  { id: "ecdf",          label: "ECDF",                 group: "Distribution", needsNum: true },
  { id: "boxplot",       label: "Box Plot",             group: "Distribution", needsNum: true },
  { id: "violinplot",    label: "Violin Plot",          group: "Distribution", needsNum: true },
  { id: "scatter",       label: "Scatter Plot",         group: "Relationship", needsNum: true },
  { id: "geo_heatmap",   label: "Geographical Heatmap", group: "Relationship", needsNum: true },
  { id: "heatmap",       label: "Correlation Heatmap",  group: "Relationship", needsNum: true },
  { id: "pairplot",      label: "Pair Plot",            group: "Relationship", needsNum: true },
  { id: "line",          label: "Line Chart",           group: "Trend",        needsNum: true },
  { id: "area",          label: "Area Chart",           group: "Trend",        needsNum: true },
  { id: "step",          label: "Step Chart",           group: "Trend",        needsNum: true },
  { id: "bar",           label: "Bar Chart",            group: "Categorical",  needsNum: false },
  { id: "barh",          label: "Horizontal Bar",       group: "Categorical",  needsNum: false },
  { id: "countplot",     label: "Count Plot",           group: "Categorical",  needsNum: false },
  { id: "pie",           label: "Pie Chart",            group: "Categorical",  needsNum: false },
  { id: "donut",         label: "Donut Chart",          group: "Categorical",  needsNum: false },
  { id: "stacked_bar",   label: "Stacked Bar",          group: "Categorical",  needsNum: false },
  { id: "missing_heatmap", label: "Missing Values Heatmap", group: "Quality", needsNum: false },
];

const CHART_GROUPS = [...new Set(CHART_TYPES.map((c) => c.group))];

export default function VisualizationView({ project }) {
  const meta        = project?.dataset?.metadata;
  const columnTypes = meta?.columnTypes || {};
  const allCols     = Object.keys(columnTypes);
  const numCols     = allCols.filter((c) => { const t = columnTypes[c] || ""; return t.includes("int") || t.includes("float"); });
  const catCols     = allCols.filter((c) => { const t = columnTypes[c] || ""; return t.includes("object") || t.includes("bool"); });

  const [activeGroup, setActiveGroup] = useState("Distribution");
  const [chartType, setChartType]     = useState("histogram");
  const [column, setColumn]           = useState(numCols[0] || "");
  const [columnY, setColumnY]         = useState(numCols[1] || "");
  const [hue, setHue]                 = useState(catCols[0] || "");
  const [colorCol, setColorCol]       = useState(project?.targetColumn || numCols[2] || "");
  const [sizeCol, setSizeCol]         = useState("");
  const [bins, setBins]               = useState(30);
  const [topN, setTopN]               = useState(10);
  const [image, setImage]             = useState(null);
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState("");
  const [gallery, setGallery]         = useState([]);
  const [chartScale, setChartScale]   = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);

  if (!project?.dataset) {
    return (
      <div className="empty-state">
        <div className="icon"><Image size={22} /></div>
        <strong>No dataset available</strong>
        <p>Upload a dataset to generate matplotlib visualizations.</p>
      </div>
    );
  }

  const groupCharts = CHART_TYPES.filter((c) => c.group === activeGroup);

  async function generate() {
    setLoading(true);
    setError("");
    setImage(null);
    try {
      const data = await api.visualize(project, chartType, {
        column,
        column_y: columnY,
        hue,
        color_col: colorCol,
        size_col: sizeCol,
        bins,
        top_n: topN,
      });
      setImage(data.image);
      setGallery((prev) => [
        { id: Date.now(), chartType, label: CHART_TYPES.find(c => c.id === chartType)?.label || chartType, src: data.image },
        ...prev.slice(0, 11),
      ]);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  const currentChartDef  = CHART_TYPES.find((c) => c.id === chartType);
  const showGeoFields     = ["geo_heatmap", "spatial_heatmap"].includes(chartType);
  const showScatterFields = ["scatter", "bubble"].includes(chartType);
  const showCatCol        = ["bar", "barh", "pie", "donut", "countplot", "stacked_bar"].includes(chartType);

  return (
    <div className="analysis-section fade-in">
      {/* Controls */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">Chart Configuration</span>
          <span className="tag tag-purple">{CHART_TYPES.length} chart types</span>
        </div>

        {/* Group tabs */}
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
          {CHART_GROUPS.map((g) => (
            <button
              key={g}
              onClick={() => { setActiveGroup(g); setChartType(CHART_TYPES.find(c => c.group === g)?.id || ""); }}
              className={`btn ${activeGroup === g ? "btn-primary" : "btn-secondary"}`}
              style={{ fontSize: "0.78rem", minHeight: 30, padding: "5px 12px" }}
            >
              {g}
            </button>
          ))}
        </div>

        {/* Chart type selector */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 6, marginBottom: 16 }}>
          {groupCharts.map((c) => (
            <button
              key={c.id}
              onClick={() => setChartType(c.id)}
              style={{
                padding: "8px 10px",
                borderRadius: 8,
                border: `1px solid ${chartType === c.id ? "var(--accent)" : "var(--border)"}`,
                background: chartType === c.id ? "var(--accent-glow)" : "var(--bg-3)",
                color: chartType === c.id ? "var(--accent)" : "var(--text-2)",
                fontSize: "0.8rem",
                fontWeight: 600,
                textAlign: "left",
                cursor: "pointer",
                transition: "var(--transition)",
              }}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Column pickers */}
        <div className="pred-inputs-grid" style={{ marginBottom: 14 }}>
          {showGeoFields ? (
            <>
              <label>
                Longitude Feature (X Axis)
                <select value={column} onChange={(e) => setColumn(e.target.value)}>
                  <option value="">-- Auto-detect (longitude) --</option>
                  {allCols.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </label>
              <label>
                Latitude Feature (Y Axis)
                <select value={columnY} onChange={(e) => setColumnY(e.target.value)}>
                  <option value="">-- Auto-detect (latitude) --</option>
                  {allCols.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </label>
              <label>
                Color Feature (Colorbar / Target)
                <select value={colorCol} onChange={(e) => setColorCol(e.target.value)}>
                  <option value="">-- Target Column --</option>
                  {numCols.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </label>
              <label>
                Point Size Feature (Population)
                <select value={sizeCol} onChange={(e) => setSizeCol(e.target.value)}>
                  <option value="">-- Auto-detect (population) --</option>
                  {numCols.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </label>
            </>
          ) : (
            <>
              <label>
                {showCatCol ? "Category Column" : "Primary Column (X)"}
                <select value={column} onChange={(e) => setColumn(e.target.value)}>
                  <option value="">(auto)</option>
                  {allCols.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </label>
              {(showScatterFields || ["bar", "barh", "stacked_bar"].includes(chartType)) && (
                <label>
                  {["bar", "barh"].includes(chartType) ? "Numeric Value (Y Axis)" : "Y Column"}
                  <select value={columnY} onChange={(e) => setColumnY(e.target.value)}>
                    <option value="">(auto / mean)</option>
                    {numCols.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </label>
              )}

              {["histogram", "kde", "dist_grid"].includes(chartType) && (
                <label>
                  Bins
                  <input type="number" value={bins} onChange={(e) => setBins(Number(e.target.value))} min={5} max={100} />
                </label>
              )}
              {showCatCol && (
                <label>
                  Top N categories
                  <input type="number" value={topN} onChange={(e) => setTopN(Number(e.target.value))} min={2} max={30} />
                </label>
              )}
            </>
          )}
        </div>

        <div className="toolbar">
          <button className="btn-primary" onClick={generate} disabled={loading}>
            {loading ? <span className="spinner" style={{ width: 15, height: 15 }} /> : <Image size={16} />}
            {loading ? "Generating…" : "Generate Chart"}
          </button>
          {error && <p className="error-msg">{error}</p>}
        </div>
      </div>

      {/* Current chart */}
      {loading && (
        <div className="loading-panel">
          <span className="spinner dark" />
          Rendering {currentChartDef?.label || chartType} with matplotlib…
        </div>
      )}

      {image && (
        <div className="chart-wrap fade-in">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, flexWrap: "wrap", gap: 8 }}>
            <div className="chart-title" style={{ display: "flex", alignItems: "center", gap: 10 }}>
              {currentChartDef?.label || chartType}
              <span className="tag tag-blue" style={{ fontSize: "0.72rem" }}>
                Size: {chartScale}%
              </span>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              {/* Zoom Out / Decrease Size */}
              <button
                className="btn btn-secondary"
                onClick={() => setChartScale((s) => Math.max(50, s - 15))}
                title="Decrease Chart Size"
                style={{ fontSize: "0.78rem", minHeight: 30, padding: "4px 10px" }}
              >
                <ZoomOut size={14} /> Decrease
              </button>

              {/* Reset Size */}
              <button
                className="btn btn-secondary"
                onClick={() => setChartScale(100)}
                title="Reset Size to 100%"
                style={{ fontSize: "0.78rem", minHeight: 30, padding: "4px 10px" }}
              >
                <RotateCcw size={13} /> Reset
              </button>

              {/* Zoom In / Increase Size */}
              <button
                className="btn btn-secondary"
                onClick={() => setChartScale((s) => Math.min(220, s + 15))}
                title="Increase Chart Size"
                style={{ fontSize: "0.78rem", minHeight: 30, padding: "4px 10px" }}
              >
                <ZoomIn size={14} /> Increase
              </button>

              {/* Fullscreen view */}
              <button
                className="btn btn-secondary"
                onClick={() => setIsFullscreen(true)}
                title="View Fullscreen"
                style={{ fontSize: "0.78rem", minHeight: 30, padding: "4px 10px" }}
              >
                <Maximize2 size={14} /> Fullscreen
              </button>

              {/* Download PNG */}
              <a
                href={image}
                download={`${chartType}_${Date.now()}.png`}
                className="btn btn-primary"
                style={{ fontSize: "0.78rem", minHeight: 30, padding: "5px 12px", textDecoration: "none" }}
              >
                ⬇ Download PNG
              </a>
            </div>
          </div>

          <div style={{ width: "100%", overflowX: "auto", padding: "8px 0", textAlign: "center" }}>
            <img
              src={image}
              alt={chartType}
              style={{
                width: `${chartScale}%`,
                maxWidth: "none",
                borderRadius: 8,
                display: "inline-block",
                transition: "width 0.2s ease-in-out",
                boxShadow: "0 4px 20px rgba(0,0,0,0.3)",
              }}
            />
          </div>
        </div>
      )}

      {/* Fullscreen Lightbox Modal */}
      {isFullscreen && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 9999,
            background: "rgba(13, 17, 23, 0.95)",
            backdropFilter: "blur(8px)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: 24,
          }}
          onClick={() => setIsFullscreen(false)}
        >
          <div style={{ position: "absolute", top: 16, right: 24, display: "flex", gap: 10 }} onClick={(e) => e.stopPropagation()}>
            <button className="btn btn-secondary" onClick={() => setIsFullscreen(false)}>
              ✕ Close
            </button>
          </div>
          <img
            src={image}
            alt={chartType}
            style={{ maxHeight: "88vh", maxWidth: "95vw", objectFit: "contain", borderRadius: 10, boxShadow: "0 10px 40px rgba(0,0,0,0.8)" }}
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      {/* Gallery */}
      {gallery.length > 0 && (
        <div className="card">
          <div className="card-header">
            <span className="card-title">Chart Gallery</span>
            <span className="tag tag-blue">{gallery.length} charts</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 12 }}>
            {gallery.map(({ id, label, src }) => (
              <div
                key={id}
                style={{ background: "var(--bg-3)", border: "1px solid var(--border)", borderRadius: 10, overflow: "hidden", cursor: "pointer", transition: "var(--transition)" }}
                onClick={() => setImage(src)}
              >
                <img src={src} alt={label} style={{ width: "100%", display: "block" }} />
                <div style={{ padding: "8px 10px", fontSize: "0.78rem", fontWeight: 600, color: "var(--text-2)" }}>
                  {label}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!image && !loading && gallery.length === 0 && (
        <div className="empty-state">
          <div className="icon"><Image size={22} /></div>
          <strong>No chart generated yet</strong>
          <p>Select a chart type, configure columns, and click "Generate Chart".</p>
        </div>
      )}
    </div>
  );
}
