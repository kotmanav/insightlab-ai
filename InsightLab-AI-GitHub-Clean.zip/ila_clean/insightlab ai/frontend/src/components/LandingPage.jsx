import {
  ArrowRight, BarChart3, Bot, Brain, CheckCircle2,
  Database, FileText, FolderKanban, Layers, Lock,
  Sparkles, UserCheck, Wand2, X, Zap, ShieldCheck, Home, Sun, Moon,
  KeyRound, ArrowLeft, RefreshCw
} from "lucide-react";
import React, { useState, useEffect } from "react";
import { api } from "../api";

export default function LandingPage({ onAuthed, theme, onToggleTheme }) {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [mode, setMode]                   = useState("signup");
  const [form, setForm]                   = useState({ name: "", email: "", password: "", newPassword: "" });
  const [otp, setOtp]                     = useState("");
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [targetEmail, setTargetEmail]       = useState("");
  const [infoMsg, setInfoMsg]               = useState("");
  const [error, setError]                 = useState("");
  const [busy, setBusy]                   = useState(false);
  const [activeTab, setActiveTab]         = useState("eda");
  const [isScrolled, setIsScrolled]       = useState(false);

  // Scroll listener to update navbar styling when scrolling down
  useEffect(() => {
    function handleScroll() {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    }

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Sync URL hash state on mount and browser back/forward buttons
  useEffect(() => {
    function handleHashChange() {
      const hash = window.location.hash;
      if (hash === "#login" || hash === "#signin") {
        setMode("login");
        setShowAuthModal(true);
      } else if (hash === "#signup" || hash === "#register" || hash === "#get-started") {
        setMode("signup");
        setShowAuthModal(true);
      }
    }

    handleHashChange();
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  function openAuth(initialMode = "signup") {
    setForm({ name: "", email: "", password: "", newPassword: "" });
    setMode(initialMode);
    setError("");
    setInfoMsg("");
    setIsVerifyingOtp(false);
    setShowAuthModal(true);
    const newHash = initialMode === "login" ? "#login" : "#signup";
    window.history.pushState(null, "", newHash);
  }

  function closeAuthModal() {
    setForm({ name: "", email: "", password: "", newPassword: "" });
    setShowAuthModal(false);
    setIsVerifyingOtp(false);
    window.history.pushState(null, "", "#");
  }

  function navigateSection(sectionId) {
    const el = document.getElementById(sectionId);
    if (el) el.scrollIntoView({ behavior: "smooth" });
    window.history.pushState(null, "", `#${sectionId}`);
  }

  async function submit(e) {
    e.preventDefault();
    setError("");
    setInfoMsg("");
    setBusy(true);
    try {
      if (mode === "login") {
        try {
          const data = await api.login(form);
          localStorage.setItem("insightlab_token", data.token);
          localStorage.setItem("insightlab_user", JSON.stringify(data.user));
          onAuthed(data.user);
        } catch (err) {
          if (err.message?.includes("OTP") || err.message?.includes("verified")) {
            setTargetEmail(form.email);
            setIsVerifyingOtp(true);
            setInfoMsg("Verification OTP code sent to your email.");
          } else {
            throw err;
          }
        }
      } else if (mode === "signup") {
        const data = await api.signup(form);
        if (data.requireOtp) {
          setTargetEmail(data.email || form.email);
          setIsVerifyingOtp(true);
          setInfoMsg(data.message || "OTP sent to your email address.");
        } else {
          localStorage.setItem("insightlab_token", data.token);
          localStorage.setItem("insightlab_user", JSON.stringify(data.user));
          onAuthed(data.user);
        }
      } else if (mode === "forgot") {
        const data = await api.forgotPassword({ email: form.email });
        setTargetEmail(form.email);
        setMode("reset_password");
        setInfoMsg(data.message || "Password reset OTP sent to your email.");
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleResetPassword(e) {
    e.preventDefault();
    setError("");
    setInfoMsg("");
    setBusy(true);
    try {
      const data = await api.resetPassword({
        email: targetEmail,
        otp,
        newPassword: form.newPassword,
      });
      setInfoMsg(data.message || "Password reset successfully!");

      const loginData = await api.login({ email: targetEmail, password: form.newPassword });
      localStorage.setItem("insightlab_token", loginData.token);
      localStorage.setItem("insightlab_user", JSON.stringify(loginData.user));
      onAuthed(loginData.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleVerifyOtp(e) {
    e.preventDefault();
    setError("");
    setInfoMsg("");
    setBusy(true);
    try {
      const data = await api.verifyOtp({ email: targetEmail, otp });
      localStorage.setItem("insightlab_token", data.token);
      localStorage.setItem("insightlab_user", JSON.stringify(data.user));
      onAuthed(data.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleResendOtp() {
    setError("");
    setInfoMsg("");
    setBusy(true);
    try {
      const res = mode === "reset_password"
        ? await api.forgotPassword({ email: targetEmail })
        : await api.resendOtp({ email: targetEmail });
      setInfoMsg(res.message || "New OTP sent to your email address.");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  return (
    <div className="landing-wrapper" id="top">
      {/* Sticky Fixed Navbar */}
      <nav className={`landing-nav ${isScrolled ? "scrolled" : ""}`}>
        <div className="nav-brand" onClick={() => navigateSection("top")} style={{ cursor: "pointer" }}>
          <div className="brand-icon">
            <FolderKanban size={18} />
          </div>
          <span className="brand-name">InsightLab AI</span>
        </div>

        {/* Center Nav Links */}
        <div className="nav-links">
          <button className="nav-link-btn" onClick={() => navigateSection("top")}>
            <Home size={14} /> Home
          </button>
          <button className="nav-link-btn" onClick={() => navigateSection("features")}>
            Features
          </button>
          <button className="nav-link-btn" onClick={() => navigateSection("how-it-works")}>
            Pipeline Workflow
          </button>
          <button className="nav-link-btn" onClick={() => navigateSection("showcase")}>
            Workbench Preview
          </button>
        </div>

        {/* Action Buttons */}
        <div className="nav-actions">
          <button
            className="btn btn-secondary"
            onClick={onToggleTheme}
            style={{ padding: "8px 12px" }}
            title={theme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
          </button>
          <button className="btn btn-secondary" onClick={() => openAuth("login")}>
            Sign In
          </button>
          <button className="btn-primary" onClick={() => openAuth("signup")}>
            Get Started <ArrowRight size={15} />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="landing-hero" style={{ paddingTop: 130 }}>
        <div className="hero-badge-container">
          <span className="badge-glow">
            <Zap size={14} /> AI-Powered Intelligent Data Science Workbench
          </span>
        </div>

        <h1 className="landing-hero-title">
          Turn Raw Datasets into <br />
          <span className="gradient-text">Predictive Machine Learning Models</span>
        </h1>

        <p className="landing-hero-sub">
          Automate exploratory data analysis, clean missing values, benchmark regression & classification models,
          generate publication-grade visualizations, and deploy real-time predictions in seconds.
        </p>

        <div className="landing-hero-cta">
          <button className="btn-primary btn-lg" onClick={() => openAuth("signup")}>
            Get Started Now <ArrowRight size={18} />
          </button>
          <button className="btn btn-secondary btn-lg" onClick={() => openAuth("login")}>
            <Lock size={16} /> Sign In to Existing Account
          </button>
        </div>

        <div className="landing-trust-pills">
          <span><CheckCircle2 size={14} color="var(--green)" /> Zero Setup Needed</span>
          <span><CheckCircle2 size={14} color="var(--green)" /> Multi-Model Training</span>
          <span><CheckCircle2 size={14} color="var(--green)" /> Instant Joblib Inference</span>
          <span><CheckCircle2 size={14} color="var(--green)" /> Matplotlib Visualization</span>
        </div>
      </section>

      {/* Interactive Workbench Preview */}
      <section className="landing-showcase" id="showcase">
        <div className="showcase-header">
          <span className="sub-tag">LIVE INTERACTIVE WORKBENCH</span>
          <h2>Experience the Power of InsightLab AI</h2>
          <p>Explore the built-in modules designed for end-to-end data science tasks</p>
        </div>

        <div className="showcase-window">
          <div className="window-header">
            <div className="window-dots">
              <span className="dot red" />
              <span className="dot yellow" />
              <span className="dot green" />
            </div>
            <div className="window-title">InsightLab AI Workbench — House_Prices_Dataset.csv</div>
          </div>

          <div className="showcase-tabs">
            {[
              { id: "eda", label: "Automated EDA", icon: BarChart3 },
              { id: "clean", label: "Data Cleaning", icon: Wand2 },
              { id: "models", label: "Model Trainer", icon: Brain },
              { id: "predict", label: "Live Predictions", icon: Bot },
              { id: "report", label: "Executive Reports", icon: FileText },
            ].map((t) => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  className={`showcase-tab ${activeTab === t.id ? "active" : ""}`}
                  onClick={() => {
                    setActiveTab(t.id);
                    window.history.pushState(null, "", `#showcase-${t.id}`);
                  }}
                >
                  <Icon size={14} />
                  {t.label}
                </button>
              );
            })}
          </div>

          <div className="showcase-content">
            {activeTab === "eda" && (
              <div className="showcase-panel fade-in">
                <div className="mock-grid-4">
                  <div className="mock-stat"><span className="lbl">Total Rows</span><span className="val">14,600</span></div>
                  <div className="mock-stat"><span className="lbl">Columns</span><span className="val">81</span></div>
                  <div className="mock-stat"><span className="lbl">Missing Cells</span><span className="val" style={{ color: "var(--yellow)" }}>6.2%</span></div>
                  <div className="mock-stat"><span className="lbl">Target Column</span><span className="val" style={{ color: "var(--accent)" }}>SalePrice</span></div>
                </div>
                <div className="mock-chart-box">
                  <div className="mock-chart-header">Feature Correlation Heatmap & Distribution Insights</div>
                  <div className="mock-bars">
                    <div className="bar-col" style={{ height: "75%" }}><span className="bar-lbl">GrLivArea</span></div>
                    <div className="bar-col" style={{ height: "60%" }}><span className="bar-lbl">OverallQual</span></div>
                    <div className="bar-col" style={{ height: "45%" }}><span className="bar-lbl">GarageCars</span></div>
                    <div className="bar-col" style={{ height: "40%" }}><span className="bar-lbl">TotalBsmtSF</span></div>
                    <div className="bar-col" style={{ height: "35%" }}><span className="bar-lbl">FullBath</span></div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "clean" && (
              <div className="showcase-panel fade-in">
                <div className="mock-clean-list">
                  <div className="mock-op">
                    <div><strong>Drop Missing Rows</strong><p>Removes rows with missing values</p></div>
                    <span className="tag tag-green">Applied</span>
                  </div>
                  <div className="mock-op">
                    <div><strong>Median Imputation</strong><p>Fills numeric NaN values with column median</p></div>
                    <span className="tag tag-green">Applied</span>
                  </div>
                  <div className="mock-op">
                    <div><strong>Min-Max Normalization</strong><p>Scales all features to range [0, 1]</p></div>
                    <span className="tag tag-blue">Ready to apply</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "models" && (
              <div className="showcase-panel fade-in">
                <div className="mock-models-grid">
                  <div className="mock-mcard best">
                    <span className="best-tag">★ Best Model</span>
                    <h4>Random Forest Regressor</h4>
                    <div className="m-score">R² Score: <strong>0.8942</strong></div>
                    <div className="m-rmse">RMSE: <strong>21,450.12</strong></div>
                  </div>
                  <div className="mock-mcard">
                    <h4>Gradient Boosting Regressor</h4>
                    <div className="m-score">R² Score: <strong>0.8810</strong></div>
                    <div className="m-rmse">RMSE: <strong>23,110.85</strong></div>
                  </div>
                  <div className="mock-mcard">
                    <h4>Ridge Regression</h4>
                    <div className="m-score">R² Score: <strong>0.8120</strong></div>
                    <div className="m-rmse">RMSE: <strong>29,840.00</strong></div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "predict" && (
              <div className="showcase-panel fade-in">
                <div className="mock-pred-box">
                  <div className="pred-heading">Live Inference Model output for target "SalePrice"</div>
                  <div className="pred-big-val">$324,500.00</div>
                  <span className="tag tag-green">Confidence Score: 94.8%</span>
                </div>
              </div>
            )}

            {activeTab === "report" && (
              <div className="showcase-panel fade-in">
                <div className="mock-report-card">
                  <h3>House Price Prediction — Executive Analysis Report</h3>
                  <p>Generated automatically on dataset analysis completion.</p>
                  <div className="report-chip-list">
                    <span className="chip">📊 Dataset Health: Clean</span>
                    <span className="chip">🤖 Best Model: Random Forest</span>
                    <span className="chip">💡 Top Driver: GrLivArea (32.4%)</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="landing-features" id="features">
        <div className="showcase-header">
          <span className="sub-tag">COMPLETE TOOLKIT</span>
          <h2>Everything You Need for ML Workflows</h2>
          <p>Built for data scientists, engineers, analysts, and students</p>
        </div>

        <div className="features-grid">
          {[
            { title: "Automated Data Profiling", desc: "Instant calculation of column data types, missing values, duplicates, and statistical distribution.", icon: Database, color: "var(--accent)" },
            { title: "Smart Data Cleaning", desc: "Apply single-click cleaning transformations — median/mode imputation, outlier filtering, and normalization.", icon: Wand2, color: "var(--orange)" },
            { title: "Multi-Model Machine Learning", desc: "Train KNN, Decision Tree, Random Forest, SVM, Gradient Boosting, and Linear models automatically.", icon: Brain, color: "var(--purple)" },
            { title: "Persisted Model Pipeline", desc: "Models are serialized via Joblib and stored on disk, allowing fast instant predictions without retraining.", icon: Bot, color: "var(--green)" },
            { title: "Matplotlib Visualizations", desc: "Generate over 19 chart types including heatmaps, violin plots, box plots, ECDFs, line and area charts.", icon: Layers, color: "var(--yellow)" },
            { title: "Executive Report Generator", desc: "Compile complete project statistics, EDA highlights, benchmark results, and AI recommendations into printable reports.", icon: FileText, color: "var(--accent)" },
          ].map((f, i) => {
            const Icon = f.icon;
            return (
              <div className="feature-card-landing" key={i}>
                <div className="f-icon" style={{ background: "var(--bg-3)", color: f.color }}>
                  <Icon size={22} />
                </div>
                <h3>{f.title}</h3>
                <p>{f.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* How It Works Timeline */}
      <section className="landing-steps" id="how-it-works">
        <div className="showcase-header">
          <span className="sub-tag">SIMPLE 4-STEP PROCESS</span>
          <h2>How InsightLab AI Works</h2>
        </div>

        <div className="steps-grid">
          {[
            { num: "01", title: "Upload Dataset", desc: "Upload any CSV or Excel file containing your structured training data." },
            { num: "02", title: "Clean & Explore", desc: "Run automated EDA and apply missing value imputations or scaling." },
            { num: "03", title: "Train Models", desc: "Select your target column and benchmark multiple machine learning algorithms." },
            { num: "04", title: "Predict & Report", desc: "Run real predictions using saved model pipelines and generate professional reports." },
          ].map((s, i) => (
            <div className="step-card" key={i}>
              <div className="step-num">{s.num}</div>
              <h4>{s.title}</h4>
              <p>{s.desc}</p>
            </div>
          ))}
        </div>

        <div style={{ textAlign: "center", marginTop: 40 }}>
          <button className="btn-primary btn-lg" onClick={() => openAuth("signup")}>
            Get Started Now <ArrowRight size={18} />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="landing-footer">
        <div className="footer-content">
          <div className="footer-brand">
            <div className="brand-icon">
              <FolderKanban size={18} />
            </div>
            <span>InsightLab AI</span>
          </div>
          <p>© 2026 InsightLab AI — Intelligent Data Science Workbench. All rights reserved.</p>
        </div>
      </footer>

      {/* Auth Modal (Appears when Get Started or Sign In is clicked) */}
      {showAuthModal && (
        <div className="modal-backdrop fade-in" onClick={closeAuthModal}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={closeAuthModal}>
              <X size={18} />
            </button>

            <div className="auth-card-modal">
              {!isVerifyingOtp && mode !== "reset_password" ? (
                <>
                  <div className="modal-auth-header">
                    <h2>
                      {mode === "login"
                        ? "Welcome Back"
                        : mode === "forgot"
                        ? "Reset Password"
                        : "Create Account"}
                    </h2>
                    <p>
                      {mode === "login"
                        ? "Sign in to access your projects and models"
                        : mode === "forgot"
                        ? "Enter your registered email to receive a password reset code"
                        : "Get started with your free data science workbench"}
                    </p>
                  </div>

                  {mode !== "forgot" && (
                    <div className="segmented" style={{ marginBottom: 20 }}>
                      <button
                        type="button"
                        className={mode === "login" ? "active" : ""}
                        onClick={() => {
                          setMode("login");
                          setError("");
                          setInfoMsg("");
                          window.history.pushState(null, "", "#login");
                        }}
                      >
                        Sign In
                      </button>
                      <button
                        type="button"
                        className={mode === "signup" ? "active" : ""}
                        onClick={() => {
                          setMode("signup");
                          setError("");
                          setInfoMsg("");
                          window.history.pushState(null, "", "#signup");
                        }}
                      >
                        Create Account
                      </button>
                    </div>
                  )}

                  {infoMsg && (
                    <div style={{ marginBottom: 12, padding: "8px 12px", background: "var(--green-bg)", border: "1px solid rgba(63,185,80,0.3)", borderRadius: "var(--radius)", fontSize: "0.82rem", color: "var(--green)", textAlign: "center" }}>
                      <CheckCircle2 size={14} style={{ inlineSize: "auto", margin: "-2px 4px 0 0" }} />
                      {infoMsg}
                    </div>
                  )}

                  <form onSubmit={submit} className="form-group" autoComplete="off">
                    {mode === "signup" && (
                      <label>
                        Full Name
                        <input
                          placeholder="Jay Patel"
                          value={form.name}
                          onChange={set("name")}
                          autoComplete="off"
                          required
                        />
                      </label>
                    )}
                    <label>
                      Email Address
                      <input
                        type="email"
                        placeholder="you@example.com"
                        value={form.email}
                        onChange={set("email")}
                        autoComplete="off"
                        required
                      />
                    </label>

                    {mode !== "forgot" && (
                      <label>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                          <span>Password</span>
                          {mode === "login" && (
                            <button
                              type="button"
                              style={{ background: "none", border: "none", color: "var(--accent)", fontSize: "0.78rem", cursor: "pointer", padding: 0, fontWeight: 600 }}
                              onClick={() => { setMode("forgot"); setError(""); setInfoMsg(""); }}
                            >
                              Forgot Password?
                            </button>
                          )}
                        </div>
                        <input
                          type="password"
                          placeholder="••••••••"
                          value={form.password}
                          onChange={set("password")}
                          autoComplete="new-password"
                          required
                          minLength={6}
                        />
                      </label>
                    )}

                    {error && <p className="error-msg">{error}</p>}
                    <button className="btn-primary" type="submit" disabled={busy} style={{ marginTop: 8 }}>
                      {busy ? <span className="spinner" /> : null}
                      {busy
                        ? "Processing…"
                        : mode === "login"
                        ? "Sign In"
                        : mode === "forgot"
                        ? "Send Reset Code"
                        : "Create Account & Send OTP"}
                    </button>

                    {mode === "forgot" && (
                      <button
                        type="button"
                        className="btn btn-secondary"
                        style={{ marginTop: 8 }}
                        onClick={() => { setMode("login"); setError(""); setInfoMsg(""); }}
                      >
                        <ArrowLeft size={14} /> Back to Sign In
                      </button>
                    )}
                  </form>
                </>
              ) : mode === "reset_password" ? (
                /* Reset Password View in Modal */
                <div className="form-group fade-in">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    style={{ alignSelf: "flex-start", minHeight: 30, padding: "4px 10px", fontSize: "0.78rem" }}
                    onClick={() => { setMode("login"); setError(""); setInfoMsg(""); }}
                  >
                    <ArrowLeft size={14} /> Back to Sign In
                  </button>

                  <div style={{ textAlign: "center", margin: "12px 0 8px" }}>
                    <div className="brand-icon" style={{ width: 44, height: 44, margin: "0 auto 10px", background: "var(--accent-glow)", color: "var(--accent)" }}>
                      <KeyRound size={22} />
                    </div>
                    <h3 style={{ fontSize: "1.15rem", fontWeight: 800 }}>Reset Your Password</h3>
                    <p style={{ fontSize: "0.82rem", color: "var(--text-2)", marginTop: 4 }}>
                      We sent a 6-digit reset code to<br />
                      <strong style={{ color: "var(--text)" }}>{targetEmail}</strong>
                    </p>
                  </div>

                  {infoMsg && (() => {
                    const otpMatch = infoMsg.match(/\b(\d{6})\b/);
                    if (otpMatch) {
                      return (
                        <div style={{ padding: "14px 16px", background: "rgba(255,180,0,0.12)", border: "2px solid rgba(255,180,0,0.6)", borderRadius: "var(--radius)", textAlign: "center" }}>
                          <p style={{ fontSize: "0.78rem", color: "var(--text-2)", margin: "0 0 6px" }}>
                            ⚠️ Email delivery unavailable. Use this code:
                          </p>
                          <div style={{ fontSize: "2.2rem", fontWeight: 900, letterSpacing: "10px", color: "#FFB400", fontFamily: "monospace", margin: "4px 0" }}>
                            {otpMatch[1]}
                          </div>
                          <p style={{ fontSize: "0.72rem", color: "var(--text-2)", margin: "4px 0 0" }}>
                            Enter this code below along with your new password
                          </p>
                        </div>
                      );
                    }
                    return (
                      <div style={{ padding: "8px 12px", background: "var(--green-bg)", border: "1px solid rgba(63,185,80,0.3)", borderRadius: "var(--radius)", fontSize: "0.82rem", color: "var(--green)", textAlign: "center" }}>
                        <CheckCircle2 size={14} style={{ inlineSize: "auto", margin: "-2px 4px 0 0" }} />
                        {infoMsg}
                      </div>
                    );
                  })()}

                  <form onSubmit={handleResetPassword} className="form-group" style={{ marginTop: 8 }}>
                    <label>
                      6-Digit Reset Code
                      <input
                        type="text"
                        maxLength={6}
                        placeholder="123456"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        style={{ textAlign: "center", fontSize: "1.2rem", letterSpacing: "6px", fontWeight: "800" }}
                        required
                        autoFocus
                      />
                    </label>

                    <label>
                      New Password
                      <input
                        type="password"
                        placeholder="At least 6 characters"
                        value={form.newPassword}
                        onChange={set("newPassword")}
                        required
                        minLength={6}
                      />
                    </label>

                    {error && <p className="error-msg">{error}</p>}

                    <button className="btn-primary" type="submit" disabled={busy || otp.length < 6 || form.newPassword.length < 6} style={{ minHeight: 42 }}>
                      {busy ? <span className="spinner" /> : null}
                      {busy ? "Resetting Password…" : "Reset Password & Sign In"}
                    </button>

                    <button type="button" className="btn btn-secondary" onClick={handleResendOtp} disabled={busy} style={{ fontSize: "0.8rem" }}>
                      <RefreshCw size={13} /> Resend Reset Code
                    </button>
                  </form>
                </div>
              ) : (
                <div className="form-group fade-in">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    style={{ alignSelf: "flex-start", minHeight: 30, padding: "4px 10px", fontSize: "0.78rem" }}
                    onClick={() => setIsVerifyingOtp(false)}
                  >
                    <ArrowLeft size={14} /> Back to Sign Up
                  </button>

                  <div style={{ textAlign: "center", margin: "12px 0 8px" }}>
                    <div className="brand-icon" style={{ width: 44, height: 44, margin: "0 auto 10px", background: "var(--accent-glow)", color: "var(--accent)" }}>
                      <KeyRound size={22} />
                    </div>
                    <h3 style={{ fontSize: "1.15rem", fontWeight: 800 }}>Enter Verification OTP</h3>
                    <p style={{ fontSize: "0.82rem", color: "var(--text-2)", marginTop: 4 }}>
                      We sent a 6-digit verification code to<br />
                      <strong style={{ color: "var(--text)" }}>{targetEmail}</strong>
                    </p>
                  </div>

                  {infoMsg && (() => {
                    const otpMatch = infoMsg.match(/\b(\d{6})\b/);
                    if (otpMatch) {
                      return (
                        <div style={{ padding: "14px 16px", background: "rgba(255,180,0,0.12)", border: "2px solid rgba(255,180,0,0.6)", borderRadius: "var(--radius)", textAlign: "center" }}>
                          <p style={{ fontSize: "0.78rem", color: "var(--text-2)", margin: "0 0 6px" }}>
                            ⚠️ Email delivery unavailable. Use this code:
                          </p>
                          <div style={{ fontSize: "2.2rem", fontWeight: 900, letterSpacing: "10px", color: "#FFB400", fontFamily: "monospace", margin: "4px 0" }}>
                            {otpMatch[1]}
                          </div>
                          <p style={{ fontSize: "0.72rem", color: "var(--text-2)", margin: "4px 0 0" }}>
                            Enter this 6-digit code in the box below
                          </p>
                        </div>
                      );
                    }
                    return (
                      <div style={{ padding: "8px 12px", background: "var(--green-bg)", border: "1px solid rgba(63,185,80,0.3)", borderRadius: "var(--radius)", fontSize: "0.82rem", color: "var(--green)", textAlign: "center" }}>
                        <CheckCircle2 size={14} style={{ inlineSize: "auto", margin: "-2px 4px 0 0" }} />
                        {infoMsg}
                      </div>
                    );
                  })()}

                  <form onSubmit={handleVerifyOtp} className="form-group" style={{ marginTop: 8 }}>
                    <label>
                      6-Digit OTP Code
                      <input
                        type="text"
                        maxLength={6}
                        placeholder="123456"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        style={{ textAlign: "center", fontSize: "1.2rem", letterSpacing: "6px", fontWeight: "800" }}
                        required
                        autoFocus
                      />
                    </label>

                    {error && <p className="error-msg">{error}</p>}

                    <button className="btn-primary" type="submit" disabled={busy || otp.length < 6} style={{ minHeight: 42 }}>
                      {busy ? <span className="spinner" /> : null}
                      {busy ? "Verifying OTP…" : "Verify & Activate Account"}
                    </button>

                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 6 }}>
                      <button
                        type="button"
                        className="btn btn-secondary"
                        style={{ fontSize: "0.78rem", padding: "6px 12px" }}
                        onClick={handleResendOtp}
                        disabled={busy}
                      >
                        <RefreshCw size={13} /> Resend OTP
                      </button>

                      <button
                        type="button"
                        className="logout-btn"
                        style={{ fontSize: "0.78rem", width: "auto", padding: "0 8px" }}
                        onClick={() => setIsVerifyingOtp(false)}
                      >
                        Change Email
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
