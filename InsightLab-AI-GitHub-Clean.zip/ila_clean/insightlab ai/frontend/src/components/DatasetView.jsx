import { Table2 } from "lucide-react";
import React from "react";

export default function DatasetView({ project }) {
  const meta = project?.dataset?.metadata;

  if (!project?.dataset) {
    return (
      <div className="empty-state">
        <div className="icon"><Table2 size={22} /></div>
        <strong>No dataset uploaded</strong>
        <p>Create a new project and upload a CSV or Excel file to get started.</p>
      </div>
    );
  }

  const columnData = Object.entries(meta?.columnTypes || {}).map(([col, type]) => ({
    col,
    type,
    missing: meta?.missingValues?.[col] ?? 0,
  }));

  const preview = meta?.preview || [];
  const previewCols = preview.length ? Object.keys(preview[0]) : [];

  return (
    <div className="analysis-section fade-in">
      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-label">Rows</div>
          <div className="metric-value">{meta?.rows?.toLocaleString() ?? "—"}</div>
          <div className="metric-sub">Total records</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Columns</div>
          <div className="metric-value">{meta?.columns ?? "—"}</div>
          <div className="metric-sub">Total features</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Target</div>
          <div className="metric-value" style={{ fontSize: "1rem" }}>{project.targetColumn || "—"}</div>
          <div className="metric-sub">Prediction column</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">File</div>
          <div className="metric-value" style={{ fontSize: "0.85rem" }}>{project.dataset.originalName}</div>
          <div className="metric-sub">{(project.dataset.size / 1024).toFixed(1)} KB</div>
        </div>
      </div>

      {/* Column Overview */}
      <div className="table-card">
        <div className="table-card-header">Column Overview</div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Column</th>
                <th>Type</th>
                <th>Missing Values</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {columnData.map(({ col, type, missing }) => (
                <tr key={col}>
                  <td style={{ fontWeight: 600 }}>{col}</td>
                  <td>
                    <span className={`tag ${type.includes("int") || type.includes("float") ? "tag-blue" : type.includes("object") ? "tag-purple" : "tag-orange"}`}>
                      {type}
                    </span>
                  </td>
                  <td>{missing}</td>
                  <td>
                    <span className={`tag ${missing === 0 ? "tag-green" : "tag-yellow"}`}>
                      {missing === 0 ? "Complete" : "Has missing"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Data Preview */}
      {preview.length > 0 && (
        <div className="table-card">
          <div className="table-card-header">Data Preview (first 8 rows)</div>
          <div className="table-wrap">
            <table className="preview-table">
              <thead>
                <tr>
                  {previewCols.map((c) => <th key={c}>{c}</th>)}
                </tr>
              </thead>
              <tbody>
                {preview.map((row, i) => (
                  <tr key={i}>
                    {previewCols.map((c) => (
                      <td key={c}>
                        {row[c] === null || row[c] === undefined
                          ? <span style={{ color: "var(--text-3)" }}>null</span>
                          : String(row[c])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
