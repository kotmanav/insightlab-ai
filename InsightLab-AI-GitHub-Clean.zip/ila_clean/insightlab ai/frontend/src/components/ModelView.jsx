import { Brain, RefreshCw } from "lucide-react";
import React, { useState } from "react";
import {
  Bar, BarChart, CartesianGrid, Cell,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { api } from "../api";

export default function ModelView({ project, onExperimentsSaved }) {
  const [taskType, setTaskType] = useState("auto");
  const [results, setResults]   = useState([]);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [taskUsed, setTaskUsed] = useState("");

  async function train() {
    setLoading(true);
    setError("");
    try {
      const data = await api.trainModels(project, taskType);
      setResults(data.results || []);
      setTaskUsed(data.taskType || taskType);

      // FIX #14 — Persist experiment results to MongoDB
      try {
        await api.saveExperiments(project._id, data.results, data.taskType);
        if (onExperimentsSaved) onExperimentsSaved(data.results);
      } catch {
        // Non-critical: results shown in UI even if persistence fails
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (!project?.dataset) {
    return (
      <div className="empty-state">
        <div className="icon"><Brain size={22} /></div>
        <strong>No dataset available</strong>
        <p>Upload a dataset and set a target column to train ML models.</p>
      </div>
    );
  }

  const bestIdx = results.reduce((best, r, i) => {
    return r.score > (results[best]?.score || -Infinity) ? i : best;
  }, 0);

  return (
    <div className="analysis-section fade-in">
      <div className="toolbar">
        <select value={taskType} onChange={(e) => setTaskType(e.target.value)}>
          <option value="auto">Auto Detect Task</option>
          <option value="regression">Regression</option>
          <option value="classification">Classification</option>
        </select>
        <button className="btn-primary" onClick={train} disabled={loading || !project.targetColumn}>
          {loading ? <span className="spinner" style={{ width: 15, height: 15 }} /> : <Brain size={16} />}
          {loading ? "Training Models…" : "Train All Models"}
        </button>
        {results.length > 0 && !loading && (
          <button className="btn btn-secondary" onClick={train}>
            <RefreshCw size={14} /> Retrain
          </button>
        )}
        {!project.targetColumn && (
          <span style={{ color: "var(--yellow)", fontSize: "0.82rem" }}>⚠ Set a target column first</span>
        )}
        {error && <p className="error-msg">{error}</p>}
      </div>

      {loading && (
        <div className="loading-panel">
          <span className="spinner dark" />
          Training models — this may take a moment…
        </div>
      )}

      {results.length > 0 && (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: "0.82rem", color: "var(--text-2)" }}>
              Task type: <strong style={{ color: "var(--accent)" }}>{taskUsed}</strong>
            </span>
            <span style={{ fontSize: "0.82rem", color: "var(--text-2)" }}>
              · {results.length} models trained · Results saved to project ✓
            </span>
          </div>
          <div className="results-grid">
            {results.map((r, i) => (
              <div className="result-card" key={r.modelName}>
                <div className="result-model-name">
                  {r.modelName}
                  {i === bestIdx && <span className="best-badge">★ Best</span>}
                </div>
                <div className="result-scores">
                  <div className="result-score-row">
                    <span className="result-score-label">{r.metric}</span>
                    <span className={`result-score-val ${r.score > 0.7 ? "good" : ""}`}>{r.score}</span>
                  </div>
                  {r.rmse !== undefined && (
                    <div className="result-score-row">
                      <span className="result-score-label">RMSE</span>
                      <span className="result-score-val">{r.rmse}</span>
                    </div>
                  )}
                  {r.f1 !== undefined && (
                    <div className="result-score-row">
                      <span className="result-score-label">F1 Score</span>
                      <span className={`result-score-val ${r.f1 > 0.7 ? "good" : ""}`}>{r.f1}</span>
                    </div>
                  )}
                  <div className="progress-bar-wrap">
                    <div className="progress-bar" style={{ width: `${Math.min(Math.abs(r.score) * 100, 100)}%` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Chart */}
          <div className="chart-wrap">
            <div className="chart-title">Model Comparison — {results[0]?.metric}</div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={results} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="modelName" tick={{ fontSize: 11, fill: "#8b949e" }} />
                <YAxis domain={[0, 1]} tick={{ fontSize: 11, fill: "#8b949e" }} />
                <Tooltip contentStyle={{ background: "#161b22", border: "1px solid #30363d", borderRadius: 8, color: "#e6edf3" }} />
                <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                  {results.map((_, i) => (
                    <Cell key={i} fill={i === bestIdx ? "#3fb950" : "#2f81f7"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </>
      )}

      {results.length === 0 && !loading && (
        <div className="empty-state">
          <div className="icon"><Brain size={22} /></div>
          <strong>No models trained yet</strong>
          <p>Select a task type and click "Train All Models" to benchmark multiple ML algorithms (e.g. Random Forest, SVM, KNN) on your dataset.</p>
        </div>
      )}
    </div>
  );
}
