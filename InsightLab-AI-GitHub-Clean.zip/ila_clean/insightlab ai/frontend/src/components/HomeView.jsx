import {
  BarChart3, Bot, Brain, Database, FileText, FolderKanban,
  Plus, Sparkles, Wand2, ArrowRight, Activity, CheckCircle2,
  Cpu, Layers, TrendingUp, Layers3
} from "lucide-react";
import React from "react";

export default function HomeView({ projects, onSelectProject, onNewProjectClick, user }) {
  const totalProjects = projects.length;
  const totalExperiments = projects.reduce((acc, p) => acc + (p.experiments?.length || 0), 0);
  const totalRowsProcessed = projects.reduce((acc, p) => acc + (p.dataset?.metadata?.rows || 0), 0);

  const featureCards = [
    {
      title: "Automated Data Cleaning",
      desc: "Remove missing values, handle outliers, drop duplicates, and normalize numerical features with one-click pipelines.",
      icon: Wand2,
      color: "var(--orange)",
      bg: "var(--orange-bg)",
    },
    {
      title: "Exploratory Analysis (EDA)",
      desc: "Instant descriptive statistics, skewness detection, missing value distribution charts, and correlation matrices.",
      icon: BarChart3,
      color: "var(--accent)",
      bg: "var(--accent-glow)",
    },
    {
      title: "Multi-Model Machine Learning",
      desc: "Train KNN, Decision Tree, Random Forest, SVM, Gradient Boosting, and Linear models simultaneously and benchmark performance metrics.",
      icon: Brain,
      color: "var(--purple)",
      bg: "var(--purple-bg)",
    },
    {
      title: "Real-Time Inference Engine",
      desc: "Run live single-row or batch predictions using joblib-persisted model pipelines directly from your dashboard.",
      icon: Bot,
      color: "var(--green)",
      bg: "var(--green-bg)",
    },
    {
      title: "Publication-Grade Charts",
      desc: "Generate 20+ Matplotlib & Seaborn visualizations — heatmaps, violin plots, box plots, ECDFs, pair plots and more.",
      icon: Layers3,
      color: "var(--yellow)",
      bg: "var(--yellow-bg)",
    },
    {
      title: "Executive Report Generator",
      desc: "Synthesize dataset health, EDA insights, model scores, and AI recommendations into comprehensive exportable reports.",
      icon: FileText,
      color: "var(--accent)",
      bg: "var(--accent-glow)",
    },
  ];

  return (
    <div className="home-dashboard fade-in">
      {/* Hero Welcome Banner */}
      <div className="home-hero-card">
        <div className="home-hero-content">
          <div className="hero-badge">
            <Sparkles size={14} />
            AI Data Science Workbench
          </div>
          <h1 className="hero-title">
            Welcome back, <span className="highlight-text">{user?.name || "Researcher"}</span>
          </h1>
          <p className="hero-sub">
            Build, benchmark, analyze, and deploy machine learning pipelines on your datasets with zero setup.
          </p>

          <div className="hero-cta-group">
            <button className="btn-primary" onClick={onNewProjectClick}>
              <Plus size={16} />
              Create New Project
            </button>
          </div>
        </div>

        {/* System Stats Widget */}
        <div className="hero-stats-grid">
          <div className="hero-stat-box">
            <div className="stat-icon-wrap blue"><FolderKanban size={18} /></div>
            <div>
              <div className="stat-num">{totalProjects}</div>
              <div className="stat-lbl">Active Projects</div>
            </div>
          </div>
          <div className="hero-stat-box green">
            <div className="stat-icon-wrap green"><Brain size={18} /></div>
            <div>
              <div className="stat-num">{totalExperiments}</div>
              <div className="stat-lbl">Models Trained</div>
            </div>
          </div>
          <div className="hero-stat-box purple">
            <div className="stat-icon-wrap purple"><Database size={18} /></div>
            <div>
              <div className="stat-num">{totalRowsProcessed ? totalRowsProcessed.toLocaleString() : "0"}</div>
              <div className="stat-lbl">Rows Processed</div>
            </div>
          </div>
          <div className="hero-stat-box orange">
            <div className="stat-icon-wrap orange"><Cpu size={18} /></div>
            <div>
              <div className="stat-num" style={{ color: "var(--green)" }}>Online</div>
              <div className="stat-lbl">ML Engine Status</div>
            </div>
          </div>
        </div>
      </div>

      {/* Projects Grid Section */}
      <div className="home-section-header">
        <div>
          <h2>Your Workbench Projects</h2>
          <p>Select a project to launch the interactive workspace</p>
        </div>
      </div>

      {projects.length === 0 ? (
        <div className="home-empty-projects">
          <div className="empty-project-icon">
            <Database size={32} />
          </div>
          <h3>No projects yet</h3>
          <p>Upload a dataset or create your first project using the form on the sidebar to get started.</p>
          <button className="btn-primary" onClick={onNewProjectClick} style={{ marginTop: 12 }}>
            <Plus size={16} /> Create Your First Project
          </button>
        </div>
      ) : (
        <div className="projects-grid">
          {projects.map((p) => {
            const meta = p.dataset?.metadata;
            const rowCount = meta?.rows;
            const colCount = meta?.columns;
            const hasTarget = !!p.targetColumn;
            const expCount = p.experiments?.length || 0;

            return (
              <div key={p._id} className="project-card-interactive" onClick={() => onSelectProject(p._id)}>
                <div className="pcard-header">
                  <div className="pcard-title-wrap">
                    <span className="pcard-dot" />
                    <h3 className="pcard-title">{p.projectName}</h3>
                  </div>
                  <span className="status-badge" style={{ fontSize: "0.7rem", padding: "3px 8px" }}>
                    {p.status}
                  </span>
                </div>

                <p className="pcard-desc">{p.description || "No description provided."}</p>

                <div className="pcard-metrics">
                  <div className="pmetric">
                    <span className="pm-lbl">Rows</span>
                    <span className="pm-val">{rowCount ? rowCount.toLocaleString() : "—"}</span>
                  </div>
                  <div className="pmetric">
                    <span className="pm-lbl">Cols</span>
                    <span className="pm-val">{colCount ?? "—"}</span>
                  </div>
                  <div className="pmetric">
                    <span className="pm-lbl">Target</span>
                    <span className="pm-val" style={{ color: hasTarget ? "var(--accent)" : "var(--text-3)" }}>
                      {p.targetColumn || "None"}
                    </span>
                  </div>
                  <div className="pmetric">
                    <span className="pm-lbl">Models</span>
                    <span className="pm-val" style={{ color: expCount ? "var(--green)" : "var(--text-3)" }}>
                      {expCount}
                    </span>
                  </div>
                </div>

                <div className="pcard-footer">
                  <span className="pcard-file">
                    <Database size={12} />
                    {p.dataset?.originalName || "No file uploaded"}
                  </span>
                  <span className="pcard-launch">
                    Launch Workbench <ArrowRight size={13} />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Feature Showcase Grid */}
      <div className="home-section-header" style={{ marginTop: 40 }}>
        <div>
          <h2>Platform Capabilities</h2>
          <p>Everything you need for end-to-end data science workflows</p>
        </div>
      </div>

      <div className="features-showcase-grid">
        {featureCards.map((feat, idx) => {
          const Icon = feat.icon;
          return (
            <div className="feature-card" key={idx}>
              <div className="feat-icon-badge" style={{ background: feat.bg, color: feat.color }}>
                <Icon size={20} />
              </div>
              <h3 className="feat-title">{feat.title}</h3>
              <p className="feat-desc">{feat.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
