import { FileText, RefreshCw, Printer, Download, CheckCircle2, Award, Lightbulb, Activity, Mail, Send } from "lucide-react";
import React, { useState } from "react";
import { api } from "../api";

export default function ReportView({ project, user }) {
  const [report, setReport]         = useState(null);
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState("");
  const [emailStatus, setEmailStatus] = useState("");
  const [emailSending, setEmailSending] = useState(false);

  const defaultEmail = user?.email || (() => {
    try { return JSON.parse(localStorage.getItem("insightlab_user") || "{}").email || "insighlab@gmail.com"; } catch { return "insighlab@gmail.com"; }
  })();

  const [recipientEmail, setRecipientEmail] = useState(defaultEmail);

  async function generate() {
    setLoading(true);
    setError("");
    setEmailStatus("");
    try {
      const data = await api.generateReport(project);
      setReport(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function sendEmail(targetAddr, reportData = report) {
    if (!reportData) return;
    const addr = targetAddr || recipientEmail;
    if (!addr) {
      setEmailStatus("Please enter an email address.");
      return;
    }
    setEmailSending(true);
    setEmailStatus("");
    try {
      const res = await api.sendReportEmail(addr, reportData, project.projectName);
      if (res && res.sent !== false) {
        setEmailStatus(`Report successfully sent to ${addr}`);
      } else {
        setEmailStatus(`Report generated, but email server skipped delivery.`);
      }
    } catch (e) {
      setEmailStatus(`Failed to send email to ${addr}: ${e.message}`);
    } finally {
      setEmailSending(false);
    }
  }

  function handlePrint() {
    window.print();
  }

  return (
    <div className="analysis-section fade-in">
      <div className="toolbar" style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        <button className="btn-primary" onClick={generate} disabled={loading}>
          {loading ? <span className="spinner" style={{ width: 15, height: 15 }} /> : <FileText size={16} />}
          {loading ? "Generating Report…" : report ? "Regenerate Report" : "Generate Executive Report"}
        </button>

        {report && (
          <>
            <button className="btn btn-secondary" onClick={handlePrint} title="Print or Save as PDF">
              <Printer size={15} /> Print / Save PDF
            </button>

            <div style={{ display: "flex", alignItems: "center", gap: 6, background: "var(--bg-3)", padding: "4px 8px", borderRadius: "var(--radius)", border: "1px solid var(--border)" }}>
              <Mail size={14} style={{ color: "var(--accent)" }} />
              <input
                type="email"
                placeholder="recipient@email.com"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                style={{ background: "transparent", border: "none", color: "var(--text)", fontSize: "0.82rem", outline: "none", width: 210 }}
              />
              <button
                className="btn btn-secondary"
                onClick={() => sendEmail(recipientEmail)}
                disabled={emailSending || !recipientEmail}
                style={{ fontSize: "0.78rem", minHeight: 28, padding: "4px 10px" }}
              >
                {emailSending ? <span className="spinner dark" style={{ width: 12, height: 12 }} /> : <Send size={13} />}
                {emailSending ? "Sending…" : "Send Email"}
              </button>
            </div>
          </>
        )}

        {error && <p className="error-msg" style={{ margin: 0 }}>{error}</p>}
      </div>

      {emailStatus && (
        <div style={{ marginTop: 12, padding: "8px 12px", background: "var(--green-bg)", border: "1px solid rgba(63,185,80,0.3)", borderRadius: "var(--radius)", fontSize: "0.82rem", color: "var(--green)", display: "flex", alignItems: "center", gap: 6 }}>
          <CheckCircle2 size={15} /> {emailStatus}
        </div>
      )}

      {loading && (
        <div className="loading-panel" style={{ marginTop: 16 }}>
          <span className="spinner dark" />
          Compiling dataset diagnostics, EDA insights, and dispatching report email…
        </div>
      )}

      {report && (
        <div className="report-card fade-in" style={{ marginTop: 16, padding: 24, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)" }}>
          <div className="report-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", paddingBottom: 16, borderBottom: "1px solid var(--border-light)" }}>
            <div>
              <h2 className="report-title" style={{ fontSize: "1.3rem", fontWeight: 800, color: "var(--text)" }}>{report.title}</h2>
              <div className="report-date" style={{ fontSize: "0.8rem", color: "var(--text-3)", marginTop: 4 }}>
                Generated {report.generated_at ? new Date(report.generated_at).toLocaleString() : report.date || "Just now"}
                {recipientEmail && <span style={{ marginLeft: 8, color: "var(--accent)" }}>• Sent to {recipientEmail}</span>}
              </div>
            </div>
            <span className="tag tag-green" style={{ fontSize: "0.78rem", padding: "4px 10px" }}>
              <CheckCircle2 size={13} style={{ display: "inline-block", marginRight: 4, verticalAlign: "middle" }} />
              {report.status || "Completed"}
            </span>
          </div>

          {/* Executive Summary Metrics */}
          {report.summary && (
            <div style={{ marginTop: 20 }}>
              <h3 style={{ fontSize: "0.95rem", fontWeight: 800, color: "var(--text-2)", marginBottom: 12, display: "flex", alignItems: "center", gap: 6 }}>
                <Activity size={16} style={{ color: "var(--accent)" }} /> Executive Summary Metrics
              </h3>
              <div className="metrics-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 }}>
                <div className="metric-card" style={{ padding: 12, background: "var(--bg-3)", borderRadius: "var(--radius)", border: "1px solid var(--border)" }}>
                  <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Total Rows</div>
                  <div className="metric-value" style={{ fontSize: "1.1rem", fontWeight: 800, color: "var(--text)" }}>{report.summary.rows?.toLocaleString() ?? "—"}</div>
                </div>

                <div className="metric-card" style={{ padding: 12, background: "var(--bg-3)", borderRadius: "var(--radius)", border: "1px solid var(--border)" }}>
                  <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Columns</div>
                  <div className="metric-value" style={{ fontSize: "1.1rem", fontWeight: 800, color: "var(--text)" }}>{report.summary.columns ?? "—"}</div>
                </div>

                <div className="metric-card" style={{ padding: 12, background: "var(--bg-3)", borderRadius: "var(--radius)", border: "1px solid var(--border)" }}>
                  <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Missing Cells</div>
                  <div className="metric-value" style={{ fontSize: "1.1rem", fontWeight: 800, color: report.summary.missingCells ? "var(--yellow)" : "var(--green)" }}>
                    {report.summary.missingCells ?? 0}
                  </div>
                </div>

                <div className="metric-card" style={{ padding: 12, background: "var(--bg-3)", borderRadius: "var(--radius)", border: "1px solid var(--border)" }}>
                  <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Target Column</div>
                  <div className="metric-value" style={{ fontSize: "0.95rem", fontWeight: 800, color: "var(--accent)", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {report.summary.targetColumn || project.targetColumn || "None"}
                  </div>
                </div>

                <div className="metric-card" style={{ padding: 12, background: "var(--bg-3)", borderRadius: "var(--radius)", border: "1px solid var(--border)" }}>
                  <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Best Model</div>
                  <div className="metric-value" style={{ fontSize: "0.92rem", fontWeight: 800, color: "var(--green)", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {report.summary.bestModel || "Not trained"}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Structured Report Sections */}
          {report.sections?.length > 0 && (
            <div style={{ marginTop: 24 }}>
              <h3 style={{ fontSize: "0.95rem", fontWeight: 800, color: "var(--text-2)", marginBottom: 12 }}>
                📖 Report Breakdown
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {report.sections.map((sec, i) => {
                  const title = typeof sec === "object" ? sec.title : `Section ${i + 1}`;
                  const content = typeof sec === "object" ? sec.content : String(sec);
                  return (
                    <div key={i} style={{ padding: 14, background: "var(--bg-3)", border: "1px solid var(--border)", borderRadius: "var(--radius)" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                        <span className="tag tag-blue" style={{ fontSize: "0.7rem", padding: "1px 6px" }}>Section {i + 1}</span>
                        <strong style={{ fontSize: "0.9rem", color: "var(--text)" }}>{title}</strong>
                      </div>
                      <p style={{ fontSize: "0.84rem", color: "var(--text-2)", lineHeight: 1.5, margin: 0 }}>
                        {content}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* EDA Insights */}
          {report.eda?.insights?.length > 0 && (
            <div style={{ marginTop: 20 }}>
              <h3 style={{ fontSize: "0.95rem", fontWeight: 800, color: "var(--text-2)", marginBottom: 10 }}>
                🔍 Automated Data Insights
              </h3>
              <div className="insights-list" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {report.eda.insights.map((ins, i) => (
                  <div className="insight-item" key={i} style={{ padding: "8px 12px", background: "var(--bg-3)", borderLeft: "3px solid var(--accent)", borderRadius: "0 6px 6px 0", fontSize: "0.84rem", color: "var(--text)" }}>
                    {ins}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recommendations */}
          {report.recommendations?.length > 0 && (
            <div style={{ marginTop: 20 }}>
              <h3 style={{ fontSize: "0.95rem", fontWeight: 800, color: "var(--text-2)", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                <Lightbulb size={16} style={{ color: "var(--yellow)" }} /> Actionable Recommendations
              </h3>
              <div className="insights-list" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {report.recommendations.map((rec, i) => (
                  <div className="insight-item" key={i} style={{ padding: "8px 12px", background: "var(--yellow-bg)", borderLeft: "3px solid var(--yellow)", borderRadius: "0 6px 6px 0", fontSize: "0.84rem", color: "var(--text)" }}>
                    💡 {rec}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {!report && !loading && (
        <div className="empty-state" style={{ marginTop: 24, textAlign: "center", padding: 48, background: "var(--bg-2)", border: "1px dashed var(--border)", borderRadius: "var(--radius-lg)" }}>
          <div className="icon" style={{ width: 48, height: 48, margin: "0 auto 12px", borderRadius: "50%", background: "var(--accent-glow)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <FileText size={24} />
          </div>
          <strong style={{ fontSize: "1.1rem", color: "var(--text)" }}>No Report Generated Yet</strong>
          <p style={{ fontSize: "0.85rem", color: "var(--text-2)", maxWidth: 460, margin: "6px auto 16px" }}>
            Click the button below to compile dataset diagnostics, exploratory analysis findings, model benchmark scores, and automatically dispatch a copy to your signup email.
          </p>
          <button className="btn-primary" onClick={generate}>
            <FileText size={16} /> Generate Executive Report
          </button>
        </div>
      )}
    </div>
  );
}
