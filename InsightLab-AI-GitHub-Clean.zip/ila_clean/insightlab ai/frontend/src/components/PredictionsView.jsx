import { Bot, Sparkles, Download, Layers, CheckCircle2, History, AlertCircle } from "lucide-react";
import React, { useState, useEffect } from "react";
import { api } from "../api";

export default function PredictionsView({ project }) {
  const [inputValues, setInputValues]   = useState({});
  const [singleResult, setSingleResult] = useState(null);
  const [batchResults, setBatchResults] = useState(null);
  const [history, setHistory]           = useState([]);
  const [loadingSingle, setLoadingSingle] = useState(false);
  const [loadingBatch, setLoadingBatch]   = useState(false);
  const [error, setError]               = useState("");
  const [page, setPage]                 = useState(0);

  const meta         = project?.dataset?.metadata;
  const columnTypes  = meta?.columnTypes || {};
  const previewRows  = meta?.preview || [];
  const targetCol    = project?.targetColumn || "";
  const inputCols    = Object.keys(columnTypes).filter((c) => c !== targetCol);
  const PAGE_SIZE    = 12;
  const totalPages   = Math.ceil(inputCols.length / PAGE_SIZE);
  const visibleCols  = inputCols.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  // Realistic Smart Dummy Data Map for Real-Estate & General Datasets
  const SMART_DEFAULTS = {
    Area_SqFt: 1250,
    Bathrooms: 2,
    Bedrooms: 3,
    Floor: 4,
    Parking_Spots: 1,
    Nearby_Schools: 3,
    City: "Mumbai",
    Year_Built: 2018,
    Furnishing: "Semi-Furnished",
    Property_Type: "Apartment",
    Age_Years: 6,
    Amenities: "Gym, Security, Pool",
  };

  // Populate sample values on initial load or Auto-Fill trigger
  function handleAutoFillSample() {
    if (previewRows.length > 0) {
      const sampleRow = { ...previewRows[0] };
      delete sampleRow[targetCol];
      setInputValues(sampleRow);
    } else {
      const sample = {};
      inputCols.forEach((col) => {
        if (SMART_DEFAULTS[col] !== undefined) {
          sample[col] = SMART_DEFAULTS[col];
        } else {
          const type = columnTypes[col] || "";
          if (type.includes("int") || type.includes("float")) {
            sample[col] = 10;
          } else {
            sample[col] = "Standard";
          }
        }
      });
      setInputValues(sample);
    }
  }

  // Pre-fill default sample values when workspace opens
  useEffect(() => {
    if (inputCols.length > 0 && Object.keys(inputValues).length === 0) {
      handleAutoFillSample();
    }
  }, [project]);

  // Single Row Inference
  async function predictSingle(e) {
    e.preventDefault();
    setLoadingSingle(true);
    setError("");
    try {
      const rows = [inputValues];
      const data = await api.runPrediction(project, rows);
      setSingleResult(data);

      // Save to prediction history log
      const newHistoryItem = {
        id: Date.now(),
        timestamp: new Date().toLocaleTimeString(),
        input: { ...inputValues },
        prediction: data.predictions?.[0]?.prediction ?? "—",
      };
      setHistory((prev) => [newHistoryItem, ...prev.slice(0, 9)]);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingSingle(false);
    }
  }

  // Batch Prediction Generation across Preview / Dataset Rows
  async function runBatchPrediction() {
    setLoadingBatch(true);
    setError("");
    try {
      let rowsToPredict = [];
      if (previewRows.length > 0) {
        rowsToPredict = previewRows.map((r) => {
          const rowCopy = { ...r };
          delete rowCopy[targetCol];
          return rowCopy;
        });
      } else {
        // Fallback row
        rowsToPredict = [inputValues];
      }

      const data = await api.runPrediction(project, rowsToPredict);
      setBatchResults({
        predictions: data.predictions,
        originalRows: previewRows.length > 0 ? previewRows : [inputValues],
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingBatch(false);
    }
  }

  // Download Batch Predictions as CSV
  function downloadBatchCSV() {
    if (!batchResults?.predictions) return;

    const headers = [...inputCols, `Predicted_${targetCol || "Target"}`];
    const csvRows = [headers.join(",")];

    batchResults.predictions.forEach((pItem, idx) => {
      const orig = batchResults.originalRows[idx] || {};
      const rowValues = inputCols.map((c) => `"${orig[c] ?? ""}"`);
      rowValues.push(`"${pItem.prediction}"`);
      csvRows.push(rowValues.join(","));
    });

    const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `batch_predictions_${project?.projectName || "dataset"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function setVal(col, val) {
    setInputValues((v) => ({ ...v, [col]: val }));
  }

  if (!project?.dataset) {
    return (
      <div className="empty-state">
        <div className="icon"><Bot size={22} /></div>
        <strong>No dataset available</strong>
        <p>Upload a dataset and train models to make predictions.</p>
      </div>
    );
  }

  return (
    <div className="analysis-section fade-in">
      {/* Single Row Prediction Form */}
      <div className="card">
        <div className="card-header" style={{ flexWrap: "wrap", gap: 10 }}>
          <div>
            <span className="card-title">🤖 Single Row Prediction Engine</span>
            <p style={{ fontSize: "0.78rem", color: "var(--text-2)", marginTop: 2 }}>
              Query saved Joblib model pipeline for real-time target prediction
            </p>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ fontSize: "0.78rem", minHeight: 32, padding: "4px 12px" }}
              onClick={handleAutoFillSample}
            >
              <Sparkles size={14} style={{ color: "var(--yellow)" }} /> Auto-Fill Dummy Data
            </button>
            <span className="tag tag-blue">Target: {targetCol || "not set"}</span>
          </div>
        </div>

        <form onSubmit={predictSingle} className="pred-form">
          <div className="pred-inputs-grid">
            {visibleCols.map((col) => {
              const type = columnTypes[col] || "object";
              const isNum = type.includes("int") || type.includes("float");
              return (
                <label key={col}>
                  {col}
                  <input
                    type={isNum ? "number" : "text"}
                    placeholder={SMART_DEFAULTS[col] !== undefined ? String(SMART_DEFAULTS[col]) : (isNum ? "0" : "value")}
                    value={inputValues[col] ?? ""}
                    onChange={(e) => setVal(col, e.target.value)}
                    step={type.includes("float") ? "0.01" : "1"}
                  />
                </label>
              );
            })}
          </div>

          {/* Pagination for wide datasets */}
          {totalPages > 1 && (
            <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 8 }}>
              <button
                type="button"
                className="btn btn-secondary"
                style={{ minHeight: 32, padding: "4px 12px", fontSize: "0.78rem" }}
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
              >
                ← Prev
              </button>
              <span style={{ fontSize: "0.78rem", color: "var(--text-2)" }}>
                Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, inputCols.length)} of {inputCols.length} features
              </span>
              <button
                type="button"
                className="btn btn-secondary"
                style={{ minHeight: 32, padding: "4px 12px", fontSize: "0.78rem" }}
                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={page === totalPages - 1}
              >
                Next →
              </button>
            </div>
          )}

          {error && (
            <div className="error-msg" style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8 }}>
              <AlertCircle size={15} />
              {error}
            </div>
          )}

          <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 12 }}>
            <button className="btn-primary" type="submit" disabled={loadingSingle}>
              {loadingSingle ? <span className="spinner" style={{ width: 15, height: 15 }} /> : <Bot size={16} />}
              {loadingSingle ? "Running Inference…" : "Run Prediction"}
            </button>
          </div>
        </form>
      </div>

      {/* Single Prediction Output Result */}
      {singleResult && (
        <div className="pred-result fade-in" style={{ marginTop: 14 }}>
          <div className="pred-result-label">Predicted Target Value ({targetCol || "Target"})</div>
          <div className="pred-result-value">
            {typeof singleResult.predictions?.[0]?.prediction === "number"
              ? singleResult.predictions[0].prediction.toLocaleString(undefined, { maximumFractionDigits: 2 })
              : singleResult.predictions?.[0]?.prediction ?? "—"}
          </div>
          <div style={{ marginTop: 8, fontSize: "0.78rem", color: "var(--text-2)", display: "flex", justifyContent: "center", gap: 12 }}>
            <span>✓ Inferred via Persisted Joblib Pipeline</span>
            <span>·</span>
            <span>Rows Evaluated: 1</span>
          </div>
        </div>
      )}

      {/* Prediction History Table Log */}
      {history.length > 0 && (
        <div className="card" style={{ marginTop: 14 }}>
          <div className="card-header">
            <span className="card-title">📜 Prediction Log History</span>
            <span className="tag tag-green">{history.length} Recent Runs</span>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Feature Inputs Sample</th>
                  <th>Predicted Result ({targetCol})</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {history.map((h) => {
                  const sampleInputStr = Object.entries(h.input)
                    .slice(0, 3)
                    .map(([k, v]) => `${k}=${v}`)
                    .join(", ");

                  return (
                    <tr key={h.id}>
                      <td style={{ fontSize: "0.78rem", color: "var(--text-3)" }}>{h.timestamp}</td>
                      <td style={{ fontSize: "0.82rem", color: "var(--text-2)" }}>{sampleInputStr}…</td>
                      <td style={{ fontWeight: 800, color: "var(--accent)", fontSize: "0.92rem" }}>
                        {typeof h.prediction === "number" ? h.prediction.toFixed(2) : h.prediction}
                      </td>
                      <td>
                        <span className="tag tag-green">Success</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Batch Predictions Section & Table */}
      <div className="card" style={{ marginTop: 14 }}>
        <div className="card-header" style={{ flexWrap: "wrap", gap: 10 }}>
          <div>
            <span className="card-title">📊 Batch Predictions Generator</span>
            <p style={{ fontSize: "0.78rem", color: "var(--text-2)", marginTop: 2 }}>
              Generate predictions across multiple dataset rows at once and download CSV results
            </p>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn-primary" onClick={runBatchPrediction} disabled={loadingBatch}>
              {loadingBatch ? <span className="spinner" style={{ width: 14, height: 14 }} /> : <Layers size={15} />}
              {loadingBatch ? "Processing Batch…" : "Run Batch Predictions"}
            </button>
            {batchResults && (
              <button className="btn btn-secondary" onClick={downloadBatchCSV}>
                <Download size={14} style={{ color: "var(--green)" }} /> Download CSV
              </button>
            )}
          </div>
        </div>

        {batchResults && (
          <div className="table-wrap fade-in" style={{ marginTop: 12, maxHeight: 350 }}>
            <table>
              <thead>
                <tr>
                  <th># Row</th>
                  {inputCols.slice(0, 5).map((col) => (
                    <th key={col}>{col}</th>
                  ))}
                  <th style={{ color: "var(--accent)" }}>Predicted {targetCol}</th>
                </tr>
              </thead>
              <tbody>
                {batchResults.predictions.map((p, idx) => {
                  const origRow = batchResults.originalRows[idx] || {};
                  return (
                    <tr key={idx}>
                      <td style={{ fontWeight: 700, color: "var(--text-3)" }}>#{p.row}</td>
                      {inputCols.slice(0, 5).map((col) => (
                        <td key={col} style={{ fontSize: "0.82rem", color: "var(--text-2)" }}>
                          {origRow[col] !== undefined ? String(origRow[col]) : "—"}
                        </td>
                      ))}
                      <td style={{ fontWeight: 800, color: "var(--green)", fontSize: "0.9rem" }}>
                        {typeof p.prediction === "number"
                          ? p.prediction.toLocaleString(undefined, { maximumFractionDigits: 2 })
                          : p.prediction}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {!batchResults && !loadingBatch && (
          <p style={{ fontSize: "0.85rem", color: "var(--text-2)", lineHeight: 1.6, marginTop: 8 }}>
            Click <strong>"Run Batch Predictions"</strong> to process all available dataset preview records through the model pipeline and view/download the predicted data table.
          </p>
        )}
      </div>
    </div>
  );
}
