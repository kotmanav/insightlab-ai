import { BarChart3, Info, LineChart, RefreshCw, Layers, Database, AlertTriangle, CheckCircle2 } from "lucide-react";
import React, { useMemo, useState } from "react";
import {
  Bar, BarChart, CartesianGrid, Cell,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { api } from "../api";

export default function EdaView({ project }) {
  const [eda, setEda]         = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");

  const missingData = useMemo(() => {
    const mv = eda?.profile?.missingValues || eda?.missingValues || {};
    return Object.entries(mv)
      .map(([name, value]) => ({ name, value }))
      .filter((d) => d.value > 0)
      .sort((a, b) => b.value - a.value)
      .slice(0, 15);
  }, [eda]);

  async function run() {
    setLoading(true);
    setError("");
    try {
      const data = await api.runEda(project);
      setEda(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (!project?.dataset) {
    return (
      <div className="empty-state">
        <div className="icon"><BarChart3 size={22} /></div>
        <strong>No dataset available</strong>
        <p>Upload a dataset first to run exploratory data analysis.</p>
      </div>
    );
  }

  // Derive columns list for statistics table (supports both statistics and numericStats)
  const numStats = eda?.numericStats || {};
  const statCols = eda?.statistics?.count 
    ? Object.keys(eda.statistics.count) 
    : Object.keys(numStats);

  return (
    <div className="analysis-section fade-in">
      <div className="toolbar" style={{ display: "flex", gap: 10, alignItems: "center" }}>
        <button className="btn-primary" onClick={run} disabled={loading}>
          {loading ? <span className="spinner" style={{ width: 15, height: 15 }} /> : <LineChart size={16} />}
          {loading ? "Running EDA Analysis…" : eda ? "Refresh EDA Analysis" : "Run EDA Analysis"}
        </button>

        {eda && (
          <button className="btn btn-secondary" onClick={run}>
            <RefreshCw size={14} /> Re-analyze
          </button>
        )}

        {error && <p className="error-msg" style={{ margin: 0 }}>{error}</p>}
      </div>

      {loading && (
        <div className="loading-panel" style={{ marginTop: 16 }}>
          <span className="spinner dark" />
          Calculating descriptive statistics, feature correlations, and missingness metrics…
        </div>
      )}

      {eda && (
        <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Executive Overview Metric Cards */}
          <div className="metrics-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: 12 }}>
            <div className="metric-card" style={{ padding: 12, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius)" }}>
              <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Total Rows</div>
              <div className="metric-value" style={{ fontSize: "1.1rem", fontWeight: 800, color: "var(--text)" }}>{eda.rows?.toLocaleString() ?? "—"}</div>
            </div>

            <div className="metric-card" style={{ padding: 12, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius)" }}>
              <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Columns</div>
              <div className="metric-value" style={{ fontSize: "1.1rem", fontWeight: 800, color: "var(--text)" }}>{eda.columns ?? "—"}</div>
            </div>

            <div className="metric-card" style={{ padding: 12, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius)" }}>
              <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Numeric Features</div>
              <div className="metric-value" style={{ fontSize: "1.1rem", fontWeight: 800, color: "var(--accent)" }}>{Object.keys(numStats).length}</div>
            </div>

            <div className="metric-card" style={{ padding: 12, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius)" }}>
              <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Categorical Features</div>
              <div className="metric-value" style={{ fontSize: "1.1rem", fontWeight: 800, color: "var(--purple)" }}>{Object.keys(eda.categoricalStats || {}).length}</div>
            </div>

            <div className="metric-card" style={{ padding: 12, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius)" }}>
              <div className="metric-label" style={{ fontSize: "0.72rem", color: "var(--text-3)", textTransform: "uppercase" }}>Missing Values</div>
              <div className="metric-value" style={{ fontSize: "1.1rem", fontWeight: 800, color: missingData.length > 0 ? "var(--yellow)" : "var(--green)" }}>
                {missingData.reduce((acc, curr) => acc + curr.value, 0)}
              </div>
            </div>
          </div>

          {/* Auto Insights */}
          {eda.insights?.length > 0 && (
            <div className="card" style={{ padding: 16, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)" }}>
              <div className="card-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <span className="card-title" style={{ fontSize: "0.95rem", fontWeight: 800, color: "var(--text)" }}>💡 Automated Data Insights</span>
                <span className="tag tag-green">{eda.insights.length} insights</span>
              </div>
              <div className="insights-list" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {eda.insights.map((insight, i) => (
                  <div className="insight-item" key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", background: "var(--bg-3)", borderLeft: "3px solid var(--accent)", borderRadius: "0 6px 6px 0", fontSize: "0.84rem", color: "var(--text)" }}>
                    <Info size={15} style={{ color: "var(--accent)", flexShrink: 0 }} />
                    {insight}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Missing Values Chart */}
          {missingData.length > 0 && (
            <div className="card" style={{ padding: 16, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)" }}>
              <div style={{ fontSize: "0.95rem", fontWeight: 800, color: "var(--text)", marginBottom: 12 }}>⚠️ Missing Values by Feature</div>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={missingData} margin={{ top: 4, right: 8, bottom: 45, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border-light)" />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: "var(--text-2)" }} angle={-35} textAnchor="end" interval={0} />
                  <YAxis tick={{ fontSize: 11, fill: "var(--text-2)" }} />
                  <Tooltip contentStyle={{ background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: 8, color: "var(--text)" }} />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {missingData.map((_, i) => (
                      <Cell key={i} fill={i % 2 === 0 ? "var(--accent)" : "var(--purple)"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Descriptive Statistics Table */}
          {statCols.length > 0 && (
            <div className="card" style={{ padding: 16, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)" }}>
              <div style={{ fontSize: "0.95rem", fontWeight: 800, color: "var(--text)", marginBottom: 12 }}>📊 Numerical Feature Descriptive Statistics</div>
              <div className="table-wrap" style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.82rem" }}>
                  <thead>
                    <tr style={{ background: "var(--bg-3)", textAlign: "left" }}>
                      <th style={{ padding: "8px 12px" }}>Feature Column</th>
                      <th style={{ padding: "8px 12px" }}>Count</th>
                      <th style={{ padding: "8px 12px" }}>Mean</th>
                      <th style={{ padding: "8px 12px" }}>Std Dev</th>
                      <th style={{ padding: "8px 12px" }}>Min</th>
                      <th style={{ padding: "8px 12px" }}>25%</th>
                      <th style={{ padding: "8px 12px" }}>Median (50%)</th>
                      <th style={{ padding: "8px 12px" }}>75%</th>
                      <th style={{ padding: "8px 12px" }}>Max</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statCols.map((col) => {
                      const item = numStats[col] || {};
                      const count = item.count ?? eda?.statistics?.count?.[col];
                      const mean  = item.mean  ?? eda?.statistics?.mean?.[col];
                      const std   = item.std   ?? eda?.statistics?.std?.[col];
                      const min   = item.min   ?? eda?.statistics?.min?.[col];
                      const p25   = item["25%"];
                      const p50   = item["50%"]  ?? eda?.statistics?.["50%"]?.[col];
                      const p75   = item["75%"];
                      const max   = item.max   ?? eda?.statistics?.max?.[col];

                      return (
                        <tr key={col} style={{ borderBottom: "1px solid var(--border-light)" }}>
                          <td style={{ padding: "8px 12px", fontWeight: 700, color: "var(--accent)" }}>{col}</td>
                          <td style={{ padding: "8px 12px" }}>{count ? Number(count).toLocaleString() : "—"}</td>
                          <td style={{ padding: "8px 12px" }}>{mean !== undefined ? Number(mean).toFixed(2) : "—"}</td>
                          <td style={{ padding: "8px 12px" }}>{std !== undefined ? Number(std).toFixed(2) : "—"}</td>
                          <td style={{ padding: "8px 12px" }}>{min !== undefined ? Number(min).toFixed(2) : "—"}</td>
                          <td style={{ padding: "8px 12px" }}>{p25 !== undefined ? Number(p25).toFixed(2) : "—"}</td>
                          <td style={{ padding: "8px 12px", fontWeight: 600, color: "var(--green)" }}>{p50 !== undefined ? Number(p50).toFixed(2) : "—"}</td>
                          <td style={{ padding: "8px 12px" }}>{p75 !== undefined ? Number(p75).toFixed(2) : "—"}</td>
                          <td style={{ padding: "8px 12px" }}>{max !== undefined ? Number(max).toFixed(2) : "—"}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {!eda && !loading && (
        <div className="empty-state" style={{ marginTop: 24, textAlign: "center", padding: 48, background: "var(--bg-2)", border: "1px dashed var(--border)", borderRadius: "var(--radius-lg)" }}>
          <div className="icon" style={{ width: 48, height: 48, margin: "0 auto 12px", borderRadius: "50%", background: "var(--accent-glow)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <BarChart3 size={24} />
          </div>
          <strong style={{ fontSize: "1.1rem", color: "var(--text)" }}>EDA Not Yet Run</strong>
          <p style={{ fontSize: "0.85rem", color: "var(--text-2)", maxWidth: 460, margin: "6px auto 16px" }}>
            Click "Run EDA Analysis" to compute statistical metrics, missing value distributions, numerical correlations, and dataset insights.
          </p>
          <button className="btn-primary" onClick={run}>
            <LineChart size={16} /> Run EDA Analysis
          </button>
        </div>
      )}
    </div>
  );
}
