import { LogOut, FolderKanban, ChevronRight, Plus, Upload, Home, Sun, Moon } from "lucide-react";
import React, { useState } from "react";
import { api } from "../api";

export default function Sidebar({ user, projects, selectedId, onSelect, onCreate, onLogout, theme, onToggleTheme }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function submit(e) {
    e.preventDefault();
    const formEl = e.currentTarget;
    setBusy(true);
    setErr("");
    const fd = new FormData(formEl);
    try {
      const project = await api.createProject(fd);
      if (formEl) formEl.reset();
      onCreate(project);
    } catch (error) {
      setErr(error.message);
    } finally {
      setBusy(false);
    }
  }

  const initials = user?.name
    ? user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase()
    : "U";

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="brand" onClick={() => onSelect("")} style={{ cursor: "pointer" }}>
          <div className="brand-icon">
            <FolderKanban size={17} />
          </div>
          <div>
            <strong>InsightLab AI</strong>
            <span>Workbench</span>
          </div>
        </div>
      </div>

      <div className="sidebar-section">
        {/* Home / Dashboard link */}
        <button
          className={`project-item ${selectedId === "" ? "active" : ""}`}
          onClick={() => onSelect("")}
          style={{ marginBottom: 12, fontWeight: 700 }}
        >
          <Home size={16} style={{ color: "var(--accent)" }} />
          <div className="project-info">
            <div className="project-name">Dashboard Home</div>
          </div>
        </button>

        <div className="divider" style={{ margin: "4px 0 12px" }} />

        <p className="sidebar-label">New Project</p>
        <form className="project-form" onSubmit={submit}>
          <label>
            Project Name
            <input name="projectName" placeholder="House Price Prediction" required />
          </label>
          <label>
            Description
            <textarea name="description" placeholder="Predict house prices…" rows={2} />
          </label>
          <label>
            Target Column
            <input name="targetColumn" placeholder="Price" />
          </label>
          <label className="file-drop">
            <Upload size={15} />
            Upload Dataset (CSV / Excel)
            <input name="dataset" type="file" accept=".csv,.xlsx,.xls" />
          </label>
          {err && <p className="error-msg" style={{ fontSize: "0.78rem" }}>{err}</p>}
          <button className="btn-primary" type="submit" disabled={busy} style={{ fontSize: "0.82rem", minHeight: 36 }}>
            {busy ? <span className="spinner" style={{ width: 14, height: 14 }} /> : <Plus size={15} />}
            {busy ? "Creating…" : "Create Project"}
          </button>
        </form>

        <p className="sidebar-label" style={{ marginTop: 16 }}>My Projects ({projects.length})</p>
        <div className="project-list">
          {projects.length === 0 && (
            <p style={{ fontSize: "0.78rem", color: "var(--text-3)", textAlign: "center", padding: "12px 0" }}>
              No projects yet
            </p>
          )}
          {projects.map((p) => (
            <button
              key={p._id}
              className={`project-item ${p._id === selectedId ? "active" : ""}`}
              onClick={() => onSelect(p._id)}
            >
              <span className="project-dot" />
              <div className="project-info">
                <div className="project-name">{p.projectName}</div>
                <div className="project-status">{p.status}</div>
              </div>
              <ChevronRight size={13} style={{ color: "var(--text-3)", flexShrink: 0 }} />
            </button>
          ))}
        </div>
      </div>

      <div className="sidebar-footer">
        <div className="user-info">
          <div className="user-avatar">{initials}</div>
          <span className="user-name" style={{ maxWidth: 120, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {user?.name || user?.email}
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <button
            className="logout-btn"
            onClick={onToggleTheme}
            title={theme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
          </button>
          <button className="logout-btn" onClick={onLogout} title="Logout">
            <LogOut size={15} />
          </button>
        </div>
      </div>
    </aside>
  );
}
