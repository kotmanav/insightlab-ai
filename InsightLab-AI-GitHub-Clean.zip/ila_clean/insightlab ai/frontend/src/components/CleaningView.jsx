import { Wand2, Filter, Trash2, CheckCircle2, Sparkles } from "lucide-react";
import React, { useState } from "react";
import { api } from "../api";

export default function CleaningView({ project, onDatasetUpdated }) {
  const [results, setResults]       = useState({});
  const [loading, setLoading]       = useState({});
  const [errors, setErrors]         = useState({});

  // Column-specific cleaning state
  const [selectedCol, setSelectedCol] = useState("");
  const [colOp, setColOp]             = useState("fill_column_median");
  const [customVal, setCustomVal]     = useState("");
  const [colLoading, setColLoading]   = useState(false);
  const [colResult, setColResult]     = useState("");
  const [colError, setColError]       = useState("");

  const meta = project?.dataset?.metadata;
  const columnNames = meta?.columnNames || [];
  const missingValues = meta?.missingValues || {};

  if (!project?.dataset) {
    return (
      <div className="empty-state">
        <div className="icon"><Wand2 size={22} /></div>
        <strong>No dataset available</strong>
        <p>Upload a dataset first to access data cleaning operations.</p>
      </div>
    );
  }

  const totalMissing = Object.values(missingValues).reduce((a, b) => a + b, 0);
  const columnCount  = meta?.columns || 0;
  const rowCount     = meta?.rows || 0;

  const operations = [
    {
      id: "drop_nulls",
      title: "Drop rows with missing values",
      desc: `${totalMissing} missing values detected across all columns`,
    },
    {
      id: "fill_median",
      title: "Fill numeric NaN with median",
      desc: "Replace missing numeric values with column median",
    },
    {
      id: "fill_mode",
      title: "Fill categorical NaN with mode",
      desc: "Replace missing text values with most frequent value",
    },
    {
      id: "drop_duplicates",
      title: "Remove duplicate rows",
      desc: `Scan ${rowCount.toLocaleString()} rows for exact duplicates`,
    },
    {
      id: "drop_constants",
      title: "Remove constant columns",
      desc: "Drop columns with zero variance (same value in all rows)",
    },
    {
      id: "normalize",
      title: "Normalize numeric columns",
      desc: "Scale all numeric features to [0, 1] range (Min-Max)",
    },
  ];

  async function runOp(op) {
    setLoading((l) => ({ ...l, [op.id]: true }));
    setErrors((e) => ({ ...e, [op.id]: "" }));
    try {
      const data = await api.cleanDataset(project, op.id);
      setResults((r) => ({ ...r, [op.id]: data.message }));
      const updatedProfile = data.new_profile || data.profile;
      if (updatedProfile && onDatasetUpdated) {
        onDatasetUpdated(updatedProfile);
      }
    } catch (err) {
      setErrors((e) => ({ ...e, [op.id]: err.message }));
    } finally {
      setLoading((l) => ({ ...l, [op.id]: false }));
    }
  }

  async function runColumnOp(e) {
    e.preventDefault();
    if (!selectedCol) {
      setColError("Please select a target column first.");
      return;
    }
    setColLoading(true);
    setColError("");
    setColResult("");
    try {
      const data = await api.cleanDataset(project, colOp, selectedCol, colOp === "fill_column_custom" ? customVal : null);
      setColResult(data.applied?.join(" ") || "Column cleaning operation completed.");
      const updatedProfile = data.new_profile || data.profile;
      if (updatedProfile && onDatasetUpdated) {
        onDatasetUpdated(updatedProfile);
      }
    } catch (err) {
      setColError(err.message);
    } finally {
      setColLoading(false);
    }
  }

  return (
    <div className="analysis-section fade-in">
      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-label">Total Missing</div>
          <div className="metric-value" style={{ color: totalMissing > 0 ? "var(--yellow)" : "var(--green)" }}>
            {totalMissing}
          </div>
          <div className="metric-sub">values to handle</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Total Rows</div>
          <div className="metric-value">{rowCount.toLocaleString()}</div>
          <div className="metric-sub">records in dataset</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Columns</div>
          <div className="metric-value">{columnCount}</div>
          <div className="metric-sub">features available</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Operations Done</div>
          <div className="metric-value" style={{ color: "var(--green)" }}>
            {Object.keys(results).length}
          </div>
          <div className="metric-sub">of {operations.length} available</div>
        </div>
      </div>

      {/* 🎯 Column-Specific Data Cleaning Card */}
      <div className="card" style={{ padding: 20, background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", marginBottom: 20 }}>
        <div className="card-header" style={{ marginBottom: 14 }}>
          <span className="card-title" style={{ fontSize: "1rem", fontWeight: 800, color: "var(--accent)", display: "flex", alignItems: "center", gap: 8 }}>
            <Filter size={18} /> Particular Column Cleaning Operation
          </span>
          <span className="tag tag-blue">Single Feature Mode</span>
        </div>

        <form onSubmit={runColumnOp} style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14, alignItems: "flex-end" }}>
          <div>
            <label style={{ fontSize: "0.8rem", fontWeight: 700, color: "var(--text-2)", display: "block", marginBottom: 6 }}>
              Select Column:
            </label>
            <select
              value={selectedCol}
              onChange={(e) => setSelectedCol(e.target.value)}
              className="target-select-header"
              style={{ width: "100%", height: 38, fontSize: "0.85rem", background: "var(--bg-3)", border: "1px solid var(--border)", color: "var(--text)", borderRadius: "var(--radius)" }}
              required
            >
              <option value="">-- Choose Column --</option>
              {columnNames.map((col) => {
                const missingCnt = missingValues[col] || 0;
                return (
                  <option key={col} value={col}>
                    {col} {missingCnt > 0 ? `(${missingCnt} missing)` : "(Clean)"}
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label style={{ fontSize: "0.8rem", fontWeight: 700, color: "var(--text-2)", display: "block", marginBottom: 6 }}>
              Cleaning Action:
            </label>
            <select
              value={colOp}
              onChange={(e) => setColOp(e.target.value)}
              className="target-select-header"
              style={{ width: "100%", height: 38, fontSize: "0.85rem", background: "var(--bg-3)", border: "1px solid var(--border)", color: "var(--text)", borderRadius: "var(--radius)" }}
            >
              <option value="fill_column_median">Fill missing with Median (Numeric)</option>
              <option value="fill_column_mean">Fill missing with Mean (Numeric)</option>
              <option value="fill_column_mode">Fill missing with Mode (Categorical)</option>
              <option value="fill_column_custom">Fill missing with Custom Value</option>
              <option value="drop_column_nulls">Drop rows with missing values in this column</option>
              <option value="drop_column">Drop this Column completely from dataset</option>
            </select>
          </div>

          {colOp === "fill_column_custom" && (
            <div>
              <label style={{ fontSize: "0.8rem", fontWeight: 700, color: "var(--text-2)", display: "block", marginBottom: 6 }}>
                Custom Replacement Value:
              </label>
              <input
                type="text"
                placeholder="e.g. Unknown or 0"
                value={customVal}
                onChange={(e) => setCustomVal(e.target.value)}
                style={{ width: "100%", height: 38, fontSize: "0.85rem", background: "var(--bg-3)", border: "1px solid var(--border)", color: "var(--text)", borderRadius: "var(--radius)", padding: "0 10px" }}
                required
              />
            </div>
          )}

          <div>
            <button
              className="btn-primary"
              type="submit"
              disabled={colLoading || !selectedCol}
              style={{ height: 38, width: "100%", justifyContent: "center" }}
            >
              {colLoading ? <span className="spinner" style={{ width: 14, height: 14 }} /> : <Sparkles size={15} />}
              {colLoading ? "Applying…" : "Apply Column Operation"}
            </button>
          </div>
        </form>

        {colResult && (
          <div style={{ marginTop: 14, padding: "8px 12px", background: "var(--green-bg)", border: "1px solid rgba(63,185,80,0.3)", borderRadius: "var(--radius)", fontSize: "0.82rem", color: "var(--green)", display: "flex", alignItems: "center", gap: 6 }}>
            <CheckCircle2 size={15} /> {colResult}
          </div>
        )}

        {colError && (
          <div className="error-msg" style={{ marginTop: 14, fontSize: "0.82rem" }}>
            ⚠️ {colError}
          </div>
        )}
      </div>

      <div className="card">
        <div className="card-header">
          <span className="card-title">Global Dataset Cleaning Operations</span>
          <span className="tag tag-blue">{Object.keys(results).length}/{operations.length} applied</span>
        </div>
        <div className="cleaning-ops">
          {operations.map((op) => (
            <div className="op-card" key={op.id}>
              <div className="op-info">
                <div className="op-title">{op.title}</div>
                <div className="op-desc">{op.desc}</div>
                {results[op.id] && (
                  <div className="op-result" style={{ marginTop: 8 }}>✓ {results[op.id]}</div>
                )}
                {errors[op.id] && (
                  <div className="error-msg" style={{ marginTop: 8, fontSize: "0.78rem" }}>{errors[op.id]}</div>
                )}
              </div>
              <button
                className={results[op.id] ? "btn btn-success" : "btn btn-secondary"}
                style={{ flexShrink: 0 }}
                onClick={() => runOp(op)}
                disabled={loading[op.id]}
              >
                {loading[op.id]
                  ? <span className="spinner dark" style={{ width: 14, height: 14 }} />
                  : results[op.id] ? "✓ Done" : "Apply"}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
