import { Sparkles, ArrowRightLeft, Grid, Table } from "lucide-react";
import React, { useState } from "react";
import { api } from "../api";

export default function FeaturesView({ project }) {
  const [fiData, setFiData]   = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");
  const [filterThreshold, setFilterThreshold] = useState(0); // 0 = all

  const meta         = project?.dataset?.metadata;
  const columnTypes  = meta?.columnTypes || {};
  const numericCols  = Object.entries(columnTypes).filter(([, t]) => t.includes("int") || t.includes("float")).map(([c]) => c);
  const categoricalCols = Object.entries(columnTypes).filter(([, t]) => t.includes("object") || t.includes("bool")).map(([c]) => c);

  async function loadFeatures() {
    setLoading(true);
    setError("");
    try {
      const data = await api.getFeatureImportance(project);
      setFiData(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (!project?.dataset) {
    return (
      <div className="empty-state">
        <div className="icon"><Sparkles size={22} /></div>
        <strong>No dataset available</strong>
        <p>Upload a dataset to explore features and feature relationships.</p>
      </div>
    );
  }

  const featureImportance = fiData?.feature_importance || [];
  const maxScore = featureImportance[0]?.importance || 1;
  const topPairs = fiData?.top_pairs || [];
  const corrMatrix = fiData?.correlations || {};
  const allFeatures = fiData?.all_features || Object.keys(columnTypes);

  return (
    <div className="analysis-section fade-in">
      <div className="toolbar">
        <button className="btn-primary" onClick={loadFeatures} disabled={loading}>
          {loading ? <span className="spinner" style={{ width: 15, height: 15 }} /> : <Sparkles size={16} />}
          {loading ? "Calculating Complete Matrix…" : "Compute Feature Relationship Matrix"}
        </button>

        {fiData && (
          <span style={{ fontSize: "0.78rem", color: "var(--text-2)" }}>
            Target: <strong style={{ color: "var(--accent)" }}>{fiData.target_used}</strong> · Matrix Size:{" "}
            <strong style={{ color: "var(--green)" }}>{allFeatures.length} × {allFeatures.length}</strong>
          </span>
        )}
        {error && <p className="error-msg">{error}</p>}
      </div>

      {/* Summary Metrics */}
      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-label">Numeric Features</div>
          <div className="metric-value" style={{ color: "var(--accent)" }}>{numericCols.length}</div>
          <div className="metric-sub">int / float columns</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Categorical Features</div>
          <div className="metric-value" style={{ color: "var(--purple)" }}>{categoricalCols.length}</div>
          <div className="metric-sub">encoded for correlation</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Target Column</div>
          <div className="metric-value" style={{ fontSize: "0.9rem", color: "var(--accent)" }}>
            {project.targetColumn || fiData?.target_used || "Auto-detected"}
          </div>
          <div className="metric-sub">prediction target</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Highest Correlation</div>
          <div className="metric-value" style={{ fontSize: "0.9rem", color: "var(--green)" }}>
            {topPairs[0] ? `${topPairs[0].feature1} ↔ ${topPairs[0].feature2}` : "—"}
          </div>
          <div className="metric-sub">
            {topPairs[0] ? `corr = ${topPairs[0].correlation > 0 ? "+" : ""}${topPairs[0].correlation}` : "click compute"}
          </div>
        </div>
      </div>

      {loading && (
        <div className="loading-panel">
          <span className="spinner dark" />
          Calculating full {allFeatures.length}×{allFeatures.length} feature relationship matrix and tree feature importance…
        </div>
      )}

      {/* COMPLETE NxN FEATURE RELATIONSHIP MATRIX TABLE */}
      {fiData && allFeatures.length > 0 && (
        <div className="card" style={{ marginTop: 14 }}>
          <div className="card-header" style={{ flexWrap: "wrap", gap: 10 }}>
            <div>
              <span className="card-title">📐 Complete Feature Relationship Matrix (NxN Grid)</span>
              <p style={{ fontSize: "0.78rem", color: "var(--text-2)", marginTop: 2 }}>
                Each feature compared against all other features (Pearson correlation coefficient -1.0 to +1.0)
              </p>
            </div>
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span style={{ fontSize: "0.78rem", color: "var(--text-3)" }}>Filter:</span>
              <button
                className={`btn ${filterThreshold === 0 ? "btn-primary" : "btn-secondary"}`}
                style={{ fontSize: "0.74rem", minHeight: 28, padding: "4px 10px" }}
                onClick={() => setFilterThreshold(0)}
              >
                All
              </button>
              <button
                className={`btn ${filterThreshold === 0.3 ? "btn-primary" : "btn-secondary"}`}
                style={{ fontSize: "0.74rem", minHeight: 28, padding: "4px 10px" }}
                onClick={() => setFilterThreshold(0.3)}
              >
                |r| ≥ 0.3
              </button>
              <button
                className={`btn ${filterThreshold === 0.5 ? "btn-primary" : "btn-secondary"}`}
                style={{ fontSize: "0.74rem", minHeight: 28, padding: "4px 10px" }}
                onClick={() => setFilterThreshold(0.5)}
              >
                |r| ≥ 0.5
              </button>
            </div>
          </div>

          <div className="table-wrap" style={{ overflowX: "auto", maxHeight: 520 }}>
            <table style={{ borderCollapse: "collapse", width: "100%" }}>
              <thead>
                <tr>
                  <th style={{ position: "sticky", left: 0, top: 0, zIndex: 10, background: "var(--bg-3)", borderBottom: "2px solid var(--border)" }}>
                    Feature / Feature
                  </th>
                  {allFeatures.map((colHeader) => (
                    <th
                      key={colHeader}
                      style={{
                        position: "sticky",
                        top: 0,
                        zIndex: 5,
                        background: "var(--bg-3)",
                        borderBottom: "2px solid var(--border)",
                        fontSize: "0.78rem",
                        fontWeight: 700,
                        color: "var(--accent)",
                        padding: "10px 12px",
                        textAlign: "center",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {colHeader}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allFeatures.map((rowHeader) => (
                  <tr key={rowHeader}>
                    {/* Row Feature Header */}
                    <td
                      style={{
                        position: "sticky",
                        left: 0,
                        zIndex: 4,
                        background: "var(--bg-3)",
                        borderRight: "2px solid var(--border)",
                        fontWeight: 800,
                        fontSize: "0.82rem",
                        color: "var(--text)",
                        padding: "10px 14px",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {rowHeader}
                    </td>

                    {/* Cell Values */}
                    {allFeatures.map((colHeader) => {
                      const val = corrMatrix[rowHeader]?.[colHeader] ?? (rowHeader === colHeader ? 1.0 : 0);
                      const absVal = Math.abs(val);
                      const isSelf = rowHeader === colHeader;
                      const isFilteredOut = filterThreshold > 0 && !isSelf && absVal < filterThreshold;

                      let cellBg = "var(--bg-2)";
                      let textColor = "var(--text)";

                      if (isSelf) {
                        cellBg = "var(--accent-glow)";
                        textColor = "var(--accent)";
                      } else if (val > 0) {
                        cellBg = `rgba(63, 185, 80, ${Math.min(absVal * 0.45, 0.4)})`;
                        textColor = absVal > 0.4 ? "#3fb950" : "var(--text)";
                      } else if (val < 0) {
                        cellBg = `rgba(248, 81, 73, ${Math.min(absVal * 0.45, 0.4)})`;
                        textColor = absVal > 0.4 ? "#f85149" : "var(--text)";
                      }

                      return (
                        <td
                          key={colHeader}
                          style={{
                            background: isFilteredOut ? "var(--bg-3)" : cellBg,
                            opacity: isFilteredOut ? 0.25 : 1,
                            textAlign: "center",
                            fontSize: "0.85rem",
                            fontFamily: "monospace",
                            fontWeight: isSelf || absVal > 0.5 ? 800 : 500,
                            color: textColor,
                            padding: "10px 14px",
                            border: "1px solid var(--border-light)",
                            transition: "var(--transition)",
                          }}
                          title={`Correlation between [${rowHeader}] and [${colHeader}]: ${val}`}
                        >
                          {isSelf ? "1.00" : val > 0 ? `+${val.toFixed(2)}` : val.toFixed(2)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Top Correlated Feature Pairs Table */}
      {fiData && topPairs.length > 0 && (
        <div className="card" style={{ marginTop: 14 }}>
          <div className="card-header">
            <span className="card-title">🔗 Highest Feature Relationships (Ranked)</span>
            <span className="tag tag-blue">Top {topPairs.length} Strongest Pairs</span>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Feature 1</th>
                  <th>Relationship</th>
                  <th>Feature 2</th>
                  <th>Correlation Coefficient (r)</th>
                  <th>Strength & Direction</th>
                </tr>
              </thead>
              <tbody>
                {topPairs.map((pair, idx) => {
                  const corr = pair.correlation;
                  const absCorr = pair.abs_corr;
                  const isPositive = corr > 0;
                  const isStrong = absCorr >= 0.6;
                  const relType = isStrong
                    ? isPositive ? "Strong Positive Direct" : "Strong Inverse Direct"
                    : isPositive ? "Moderate Positive" : "Moderate Negative";
                  const badgeClass = isStrong ? "tag-green" : "tag-blue";

                  return (
                    <tr key={idx}>
                      <td style={{ fontWeight: 700, color: "var(--text)" }}>{pair.feature1}</td>
                      <td style={{ textAlign: "center", color: "var(--accent)" }}>
                        <ArrowRightLeft size={14} />
                      </td>
                      <td style={{ fontWeight: 700, color: "var(--text)" }}>{pair.feature2}</td>
                      <td style={{ fontFamily: "monospace", fontSize: "0.9rem" }}>
                        <strong style={{ color: corr > 0 ? "var(--green)" : "var(--yellow)" }}>
                          {corr > 0 ? `+${corr.toFixed(2)}` : corr.toFixed(2)}
                        </strong>
                      </td>
                      <td>
                        <span className={`tag ${badgeClass}`}>{relType}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Feature Importance Bar Chart */}
      {fiData && featureImportance.length > 0 && (
        <div className="card" style={{ marginTop: 14 }}>
          <div className="card-header">
            <span className="card-title">🎯 Model Feature Importance (Impact on Target)</span>
            <span className="tag tag-purple">Top {featureImportance.length} Features</span>
          </div>
          <div className="feature-importance">
            {featureImportance.map(({ feature, importance }) => (
              <div className="fi-row" key={feature}>
                <span className="fi-name" title={feature}>{feature}</span>
                <div className="fi-bar-wrap">
                  <div className="fi-bar" style={{ width: `${(importance / maxScore) * 100}%` }} />
                </div>
                <span className="fi-score">{(importance * 100).toFixed(2)}%</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {!fiData && !loading && (
        <div className="empty-state" style={{ marginTop: 14 }}>
          <div className="icon"><Grid size={22} /></div>
          <strong>NxN Feature Relationship Matrix not computed</strong>
          <p>Click "Compute Feature Relationship Matrix" to generate the full grid comparing all features.</p>
        </div>
      )}
    </div>
  );
}
