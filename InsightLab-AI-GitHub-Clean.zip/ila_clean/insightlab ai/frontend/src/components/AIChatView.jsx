import { Bot, Send, Sparkles, Key, ShieldCheck, Database, Trash2, X, Minus, MessageSquare } from "lucide-react";
import React, { useState } from "react";
import { api } from "../api";

export default function AIChatView({ project }) {
  const [isOpen, setIsOpen]     = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: "assistant",
      text: `Hello! I am **InsightLab AI Assistant** paired with your live dataset **${project?.projectName || "Workbench"}**.\n\nI am synchronized with your dataset records, missing values, feature types, and trained benchmark models.\n\nHow can I help you analyze **${project?.projectName}** today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [input, setInput]       = useState("");
  const [apiKey, setApiKey]     = useState(() => localStorage.getItem("insightlab_openai_key") || "");
  const [showKeyInput, setShowKeyInput] = useState(false);
  const [loading, setLoading]   = useState(false);

  const meta = project?.dataset?.metadata;
  const cols = meta?.columnNames || [];
  const projectId = project?._id || project?.id;

  function saveKey(val) {
    setApiKey(val);
    localStorage.setItem("insightlab_openai_key", val);
  }

  async function sendMessage(textToSend) {
    const text = textToSend || input;
    if (!text.trim() || loading || !project || !projectId) return;

    const userMsg = {
      id: Date.now(),
      sender: "user",
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput("");
    setLoading(true);

    try {
      const res = await api.chatWithAi(projectId, text, messages, apiKey);
      const assistantMsg = {
        id: Date.now() + 1,
        sender: "assistant",
        text: res.reply || res.message || "I have analyzed your project context.",
        source: res.source,
        model: res.model,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error("[AIChat Error]", err);
      const errorMsg = {
        id: Date.now() + 1,
        sender: "assistant",
        text: `⚠️ **AI Engine Response:** ${err.message || "Failed to communicate with AI Chat engine."}`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  }

  const QUICK_PROMPTS = [
    "📊 Dataset summary",
    "🎯 Important features",
    "🤖 Best model",
    "🧹 Cleaning steps",
  ];

  if (!project?.dataset) return null;

  return (
    <>
      {/* Floating Bottom-Right Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          style={{
            position: "fixed",
            bottom: 24,
            right: 24,
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            gap: 10,
            padding: "12px 20px",
            borderRadius: 99,
            background: "linear-gradient(135deg, var(--accent), var(--purple))",
            color: "#ffffff",
            fontWeight: 800,
            fontSize: "0.9rem",
            boxShadow: "0 8px 32px rgba(47, 129, 247, 0.45)",
            border: "none",
            cursor: "pointer",
            transition: "all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
          }}
          title="Open AI Data Science Assistant"
        >
          <div style={{ position: "relative", display: "flex" }}>
            <Bot size={20} />
            <span
              style={{
                position: "absolute",
                top: -2,
                right: -2,
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: "#3fb950",
                border: "2px solid #ffffff",
              }}
            />
          </div>
          <span>AI Assistant</span>
          <Sparkles size={14} style={{ color: "#ffe600" }} />
        </button>
      )}

      {/* Floating Right-Bottom AI Chat Popover Drawer */}
      {isOpen && (
        <div
          style={{
            position: "fixed",
            bottom: 24,
            right: 24,
            width: "min(440px, calc(100vw - 32px))",
            height: "min(620px, calc(100vh - 100px))",
            zIndex: 9999,
            background: "var(--bg-2)",
            border: "1px solid var(--border)",
            borderRadius: 16,
            boxShadow: "0 16px 48px rgba(0,0,0,0.45)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            animation: "fadeInUp 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
          }}
        >
          {/* Header */}
          <div
            style={{
              padding: "14px 16px",
              background: "var(--bg-3)",
              borderBottom: "1px solid var(--border-light)",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div className="brand-icon" style={{ width: 34, height: 34, borderRadius: 10 }}>
                <Bot size={18} />
              </div>
              <div>
                <div style={{ fontSize: "0.9rem", fontWeight: 800, color: "var(--text)", display: "flex", alignItems: "center", gap: 6 }}>
                  AI Data Science Assistant
                  <span className="tag tag-green" style={{ fontSize: "0.68rem", padding: "1px 6px" }}>
                    Live
                  </span>
                </div>
                <div style={{ fontSize: "0.74rem", color: "var(--text-2)", marginTop: 1 }}>
                  {project.projectName} · {meta?.rows?.toLocaleString() || "—"} rows
                </div>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <button
                className="logout-btn"
                style={{ width: 28, height: 28 }}
                onClick={() => setShowKeyInput(!showKeyInput)}
                title="Configure OpenAI API Key"
              >
                <Key size={14} style={{ color: "var(--yellow)" }} />
              </button>
              <button
                className="logout-btn"
                style={{ width: 28, height: 28 }}
                onClick={() => setMessages([messages[0]])}
                title="Clear Chat"
              >
                <Trash2 size={14} />
              </button>
              <button
                className="logout-btn"
                style={{ width: 28, height: 28 }}
                onClick={() => setIsOpen(false)}
                title="Minimize Chat"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* API Key Configuration Bar */}
          {showKeyInput && (
            <div style={{ padding: 10, background: "var(--bg)", borderBottom: "1px solid var(--border-light)" }}>
              <label style={{ fontSize: "0.75rem", fontWeight: 700, color: "var(--text)" }}>
                OpenAI API Key:
                <div style={{ display: "flex", gap: 6, marginTop: 4 }}>
                  <input
                    type="password"
                    value={apiKey}
                    onChange={(e) => saveKey(e.target.value)}
                    placeholder="sk-proj-..."
                    style={{ fontSize: "0.78rem", fontFamily: "monospace", padding: "6px 10px" }}
                  />
                  <span className="tag tag-blue" style={{ flexShrink: 0, fontSize: "0.7rem", padding: "2px 8px" }}>
                    <ShieldCheck size={11} /> Saved
                  </span>
                </div>
              </label>
            </div>
          )}

          {/* Quick Prompt Pills */}
          <div style={{ padding: "8px 12px", background: "var(--bg-2)", borderBottom: "1px solid var(--border-light)", display: "flex", gap: 6, overflowX: "auto" }}>
            {QUICK_PROMPTS.map((p) => (
              <button
                key={p}
                className="btn btn-secondary"
                style={{ fontSize: "0.72rem", minHeight: 24, padding: "2px 10px", borderRadius: 99, whiteSpace: "nowrap", flexShrink: 0 }}
                onClick={() => sendMessage(p)}
                disabled={loading}
              >
                {p}
              </button>
            ))}
          </div>

          {/* Messages Body */}
          <div
            style={{
              flex: 1,
              overflowY: "auto",
              padding: 14,
              display: "flex",
              flexDirection: "column",
              gap: 10,
              background: "var(--bg)",
            }}
          >
            {messages.map((m) => (
              <div
                key={m.id}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: m.sender === "user" ? "flex-end" : "flex-start",
                }}
              >
                <div
                  style={{
                    maxWidth: "88%",
                    padding: "10px 14px",
                    borderRadius: m.sender === "user" ? "14px 14px 2px 14px" : "14px 14px 14px 2px",
                    background: m.sender === "user" ? "var(--accent)" : "var(--bg-3)",
                    color: m.sender === "user" ? "#ffffff" : "var(--text)",
                    fontSize: "0.85rem",
                    lineHeight: 1.55,
                    boxShadow: "var(--shadow-sm)",
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-word",
                  }}
                >
                  {m.text}
                </div>
                <div style={{ fontSize: "0.68rem", color: "var(--text-3)", marginTop: 3, display: "flex", gap: 4 }}>
                  <span>{m.timestamp}</span>
                  {m.model && <span style={{ color: "var(--accent)" }}>· {m.model}</span>}
                </div>
              </div>
            ))}

            {loading && (
              <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--text-2)", fontSize: "0.78rem", padding: "6px 10px" }}>
                <span className="spinner dark" style={{ width: 13, height: 13 }} />
                Analyzing live dataset...
              </div>
            )}
          </div>

          {/* Bottom Chat Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage();
            }}
            style={{ padding: 10, background: "var(--bg-2)", borderTop: "1px solid var(--border-light)", display: "flex", gap: 8 }}
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask AI about ${project.projectName}...`}
              style={{ flex: 1, fontSize: "0.84rem", padding: "8px 12px" }}
              disabled={loading}
            />
            <button className="btn-primary" type="submit" disabled={loading || !input.trim()} style={{ minHeight: 36, padding: "0 14px" }}>
              <Send size={14} />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
