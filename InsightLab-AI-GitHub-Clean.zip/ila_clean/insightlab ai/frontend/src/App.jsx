import {
  BarChart3, Bot, Brain, FileText, FolderKanban,
  Image, Settings, Sparkles, Table2, Wand2, Target, Check
} from "lucide-react";
import React, { useEffect, useState } from "react";
import { api } from "./api";

// ── Components ────────────────────────────────────────────────────────────────
import AIChatView        from "./components/AIChatView";
import CleaningView     from "./components/CleaningView";
import DatasetView      from "./components/DatasetView";
import EdaView          from "./components/EdaView";
import FeaturesView     from "./components/FeaturesView";
import HomeView          from "./components/HomeView";
import LandingPage      from "./components/LandingPage";
import ModelView        from "./components/ModelView";
import PredictionsView  from "./components/PredictionsView";
import ReportView       from "./components/ReportView";
import SettingsView     from "./components/SettingsView";
import Sidebar          from "./components/Sidebar";
import VisualizationView from "./components/VisualizationView";

import "./styles.css";

// ── Step definitions ──────────────────────────────────────────────────────────
const STEPS = [
  { id: "dataset",       label: "Dataset",       icon: Table2   },
  { id: "cleaning",      label: "Cleaning",      icon: Wand2    },
  { id: "eda",           label: "EDA",           icon: BarChart3 },
  { id: "features",      label: "Features",      icon: Sparkles },
  { id: "models",        label: "Models",        icon: Brain    },
  { id: "predictions",   label: "Predictions",   icon: Bot      },
  { id: "visualization", label: "Visualization", icon: Image    },
  { id: "reports",       label: "Reports",       icon: FileText },
  { id: "settings",      label: "Settings",      icon: Settings },
];

const TAB_CONFIGS = {
  dataset:       { color: "blue",   label: "Dataset Overview"       },
  cleaning:      { color: "orange", label: "Data Cleaning"          },
  eda:           { color: "blue",   label: "Exploratory Analysis"   },
  features:      { color: "purple", label: "Feature Engineering"    },
  models:        { color: "purple", label: "Model Training"         },
  predictions:   { color: "green",  label: "Predictions"            },
  visualization: { color: "purple", label: "Data Visualization"     },
  reports:       { color: "yellow", label: "Reports"                },
  settings:      { color: "orange", label: "Settings"               },
};

// ── Workspace ─────────────────────────────────────────────────────────────────
function Workspace({ project, projects, onSelectProject, onProjectUpdated, onProjectDeleted, user }) {
  const [tab, setTab] = useState("dataset");
  const [updatingTarget, setUpdatingTarget] = useState(false);
  const [targetSavedAlert, setTargetSavedAlert] = useState(false);

  // Sync tab with URL hash change
  useEffect(() => {
    if (project) {
      const hash = window.location.hash;
      if (hash.includes("tab=")) {
        const urlTab = hash.split("tab=")[1];
        if (TAB_CONFIGS[urlTab]) setTab(urlTab);
      }
    }
  }, [project]);

  function changeTab(newTab) {
    setTab(newTab);
    if (project) {
      window.history.pushState(null, "", `#project=${project._id}&tab=${newTab}`);
    }
  }

  if (!project) {
    return (
      <div className="workspace">
        <HomeView
          projects={projects}
          onSelectProject={(id) => {
            onSelectProject(id);
            window.history.pushState(null, "", `#project=${id}&tab=dataset`);
          }}
          onNewProjectClick={() => {
            const input = document.querySelector(".project-form input[name='projectName']");
            if (input) input.focus();
          }}
          user={user}
        />
      </div>
    );
  }

  const current = TAB_CONFIGS[tab];
  const columnNames = project.dataset?.metadata?.columnNames || [];

  // Instant Target Column Switch Handler
  async function handleTargetColumnChange(e) {
    const newTarget = e.target.value;
    setUpdatingTarget(true);
    try {
      const updated = await api.updateProject(project._id, { targetColumn: newTarget });
      onProjectUpdated(updated);
      setTargetSavedAlert(true);
      setTimeout(() => setTargetSavedAlert(false), 2000);
    } catch (err) {
      alert("Failed to update target column: " + err.message);
    } finally {
      setUpdatingTarget(false);
    }
  }

  // Callback when cleaning operation updates dataset metadata
  async function handleDatasetUpdated(newProfile) {
    const updatedDataset = {
      ...project.dataset,
      metadata: newProfile,
    };

    // Optimistic UI update
    onProjectUpdated({
      ...project,
      dataset: updatedDataset,
    });

    try {
      const updated = await api.updateProject(project._id, {
        dataset: updatedDataset,
      });
      onProjectUpdated(updated);
    } catch (err) {
      console.error("Failed to save cleaned dataset metadata to MongoDB:", err);
    }
  }

  return (
    <div className="workspace">
      <div className="workspace-header">
        <div className="ws-top">
          <div className="ws-title-group">
            <div className="ws-eyebrow">Project Workspace</div>
            <div className="ws-title">{project.projectName}</div>
            {project.description && <div className="ws-desc">{project.description}</div>}
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            {/* Instant Changeable Target Column Dropdown Selector */}
            <div className="header-target-selector">
              <span className="target-lbl">
                <Target size={13} style={{ color: "var(--accent)" }} />
                Target Column:
              </span>
              {columnNames.length > 0 ? (
                <select
                  value={project.targetColumn || ""}
                  onChange={handleTargetColumnChange}
                  disabled={updatingTarget}
                  className="target-select-header"
                >
                  <option value="">-- Change Target Column --</option>
                  {columnNames.map((col) => (
                    <option key={col} value={col}>
                      {col}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  defaultValue={project.targetColumn || ""}
                  onBlur={(e) => handleTargetColumnChange({ target: { value: e.target.value } })}
                  placeholder="Target column..."
                  className="target-select-header"
                />
              )}
              {targetSavedAlert && (
                <span className="target-saved-badge">
                  <Check size={12} /> Updated
                </span>
              )}
            </div>

            <span className="status-badge">{project.status}</span>
          </div>
        </div>

        <nav className="step-tabs">
          {STEPS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={`step-tab ${tab === id ? "active" : ""}`}
              onClick={() => changeTab(id)}
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
        </nav>
      </div>

      <div className="tab-content">
        <div className="tab-header">
          <div className="tab-title-row">
            <div className={`tab-icon ${current.color}`}>
              {React.createElement(STEPS.find(s => s.id === tab)?.icon || FolderKanban, { size: 16 })}
            </div>
            <div>
              <div className="tab-heading">{current.label}</div>
              <div className="tab-sub">{project.projectName}</div>
            </div>
          </div>
        </div>

        {tab === "dataset"       && <DatasetView project={project} />}
        {tab === "cleaning"      && <CleaningView project={project} onDatasetUpdated={handleDatasetUpdated} />}
        {tab === "eda"           && <EdaView project={project} />}
        {tab === "features"      && <FeaturesView project={project} />}
        {tab === "models"        && <ModelView project={project} onExperimentsSaved={() => {}} />}
        {tab === "predictions"   && <PredictionsView project={project} />}
        {tab === "visualization" && <VisualizationView project={project} />}
        {tab === "reports"       && <ReportView project={project} user={user} />}
        {tab === "settings"      && (
          <SettingsView
            project={project}
            onUpdate={onProjectUpdated}
            onDelete={onProjectDeleted}
          />
        )}
      </div>

      {/* Floating Bottom-Right AI Assistant Widget */}
      <AIChatView project={project} />
    </div>
  );
}

// ── Root App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("insightlab_user")); } catch { return null; }
  });
  const [theme, setTheme] = useState(() => localStorage.getItem("insightlab_theme") || "dark");
  const [projects, setProjects]   = useState([]);
  const [selectedId, setSelectedId] = useState("");
  const [loadingProjects, setLoadingProjects] = useState(false);
  const [loadError, setLoadError] = useState("");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("insightlab_theme", theme);
  }, [theme]);

  function toggleTheme() {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  }

  useEffect(() => {
    if (!user) return;
    setLoadingProjects(true);
    setLoadError("");
    api.listProjects()
      .then((items) => {
        setProjects(items);
        if (items.length) {
          // Check if URL specifies a project
          const hash = window.location.hash;
          if (hash.includes("project=")) {
            const pId = hash.split("project=")[1].split("&")[0];
            if (items.some(p => p._id === pId)) {
              setSelectedId(pId);
              return;
            }
          }
          setSelectedId(items[0]._id);
        }
      })
      .catch((err) => {
        setLoadError(err.message || "Failed to load projects. Is the server running?");
      })
      .finally(() => setLoadingProjects(false));
  }, [user]);

  function logout() {
    localStorage.removeItem("insightlab_token");
    localStorage.removeItem("insightlab_user");
    setUser(null);
    setProjects([]);
    setSelectedId("");
    window.history.pushState(null, "", "#");
  }

  function handleSelectProject(id) {
    setSelectedId(id);
    if (id) {
      window.history.pushState(null, "", `#project=${id}&tab=dataset`);
    } else {
      window.history.pushState(null, "", `#dashboard`);
    }
  }

  // Show Landing Page with Get Started CTA & Auth Modal when unauthenticated
  if (!user) return <LandingPage onAuthed={setUser} theme={theme} onToggleTheme={toggleTheme} />;

  const selectedProject = projects.find((p) => p._id === selectedId) || null;

  function handleProjectUpdated(updated) {
    setProjects((prev) => prev.map((p) => (p._id === updated._id ? updated : p)));
  }

  function handleProjectDeleted(deletedId) {
    const remaining = projects.filter((p) => p._id !== deletedId);
    setProjects(remaining);
    setSelectedId("");
    window.history.pushState(null, "", `#dashboard`);
  }

  return (
    <div className="app-shell">
      <Sidebar
        user={user}
        projects={projects}
        selectedId={selectedId}
        onSelect={handleSelectProject}
        onCreate={async (project) => {
          try {
            const freshProjects = await api.listProjects();
            setProjects(freshProjects);
          } catch {
            setProjects((prev) => [project, ...prev.filter((p) => p._id !== project._id)]);
          }
          handleSelectProject(project._id);
        }}
        onLogout={logout}
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      {loadingProjects ? (
        <div className="workspace">
          <div className="workspace-empty">
            <div className="empty-hero">
              <span className="spinner dark" style={{ width: 36, height: 36 }} />
              <p style={{ marginTop: 16, color: "var(--text-2)" }}>Loading your projects…</p>
            </div>
          </div>
        </div>
      ) : loadError ? (
        <div className="workspace">
          <div className="workspace-empty">
            <div className="empty-hero">
              <p className="error-msg">{loadError}</p>
            </div>
          </div>
        </div>
      ) : (
        <Workspace
          project={selectedProject}
          projects={projects}
          onSelectProject={handleSelectProject}
          onProjectUpdated={handleProjectUpdated}
          onProjectDeleted={handleProjectDeleted}
          user={user}
        />
      )}
    </div>
  );
}
