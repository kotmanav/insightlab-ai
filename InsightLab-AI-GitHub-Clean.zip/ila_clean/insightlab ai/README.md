<div align="center">

# 🚀 InsightLab AI — Intelligent Data Science Workbench

### *Automate Data Profiling, Cleaning, EDA, Multi-Model ML Benchmarking & Real-Time Inference*

[![React](https://img.shields.io/badge/Frontend-React%2018%20%7C%20Vite-61DAFB?style=for-the-badge&logo=react&logoColor=white)](https://reactjs.org/)
[![Node.js](https://img.shields.io/badge/Backend-Node.js%20%7C%20Express-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)](https://nodejs.org/)
[![MongoDB](https://img.shields.io/badge/Database-MongoDB%20Mongoose-47A248?style=for-the-badge&logo=mongodb&logoColor=white)](https://www.mongodb.com/)
[![Django](https://img.shields.io/badge/ML%20Engine-Django%20REST-092E20?style=for-the-badge&logo=django&logoColor=white)](https://www.djangoproject.com/)
[![Scikit-Learn](https://img.shields.io/badge/Machine%20Learning-Scikit--Learn-F7931E?style=for-the-badge&logo=scikitlearn&logoColor=white)](https://scikit-learn.org/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg?style=for-the-badge)](LICENSE)

---

</div>

## 📌 Overview

**InsightLab AI** is an intelligent, full-stack, project-based **Data Science & Machine Learning Workbench**. Designed for data scientists, analysts, researchers, and students, InsightLab AI streamlines the entire ML lifecycle into a 9-step automated pipeline — from raw CSV/Excel upload to publication-grade visualizations, real-time `.joblib` model inference, and executive report generation.

---

## 🌟 Key Features

- 🔐 **Secure Authentication & Gmail OTP Verification**:
  - Sign in / Sign up protected by signed JWT authentication tokens.
  - 2-Step verification using **6-digit OTP codes delivered via Gmail SMTP**.
- 📊 **Automated Dataset Health Profiling**:
  - Instant calculations of total rows, columns, data types, missing value percentages, duplicate counts, and memory footprint with a live 8-row interactive data preview table.
- 🧹 **Interactive One-Click Data Cleaning**:
  - Drop null rows, perform median/mode imputations, remove duplicate records, and apply Min-Max or Standard Scaling.
- 📈 **Exploratory Data Analysis (EDA)**:
  - Descriptive statistics (Mean, Std, Min, 25%, 50%, 75%, Max, Skewness), missingness matrices, and automated text insights.
- 🤖 **Multi-Model Machine Learning Benchmarking**:
  - **Automatic Task Detection**: Classifies targets into **Regression** or **Classification**.
  - **Regression Models**: Linear Regression, Polynomial Regression (Degree 2), K-Nearest Neighbors (KNN), Decision Tree, Random Forest, Support Vector Machine (SVR).
  - **Classification Models**: Logistic Regression, K-Nearest Neighbors (KNN), Decision Tree, Random Forest, Support Vector Machine (SVM), Gradient Boosting.
  - Benchmarks $R^2$, RMSE, MAE, Accuracy, F1-Score, Precision, and Recall.
- 🎯 **Real-Time Joblib Inference Engine**:
  - Automatically serializes trained model pipelines as `.joblib` artifacts on disk for instant single-row and batch prediction requests.
- 🗺️ **3-Column Geographical & Spatial Heatmap**:
  - Custom spatial visualizer mapping **Longitude (X)**, **Latitude (Y)**, **Target Metric (Colorbar Intensity)**, and **Population (Point Size)**.
- 💬 **Floating AI Data Science Assistant**:
  - Fixed bottom-right drawer assistant (`bottom: 24px, right: 24px`) synchronized with live dataset context (rows, columns, feature types, missing values, benchmark model scores). Powered by OpenAI GPT-4 with an offline fallback engine.
- ☀️ **Modern Dark & Light Mode Support**:
  - Fully responsive theme toggle with HSL-tailored color palettes and smooth glassmorphic styling.

---

## 🏗️ System Architecture

```
                                  ┌───────────────────────────┐
                                  │   React 18 (Vite) App     │
                                  │  (Workbench SPA Frontend) │
                                  └─────────────┬─────────────┘
                                                │ HTTP / JSON API
                                                ▼
                                  ┌───────────────────────────┐
                                  │  Node.js + Express Gateway│
                                  │  (JWT Auth & Mailer OTP)  │
                                  └──────┬──────────────┬─────┘
                                         │              │
                    MongoDB Persistence  │              │ HTTP Proxy
                                         ▼              ▼
                                  ┌────────────┐  ┌───────────────────────────┐
                                  │  MongoDB   │  │ Python Django REST Engine │
                                  │  Database  │  │ (Scikit-Learn, Pandas ML) │
                                  └────────────┘  └───────────────────────────┘
```

---

## 📂 Repository Structure

```
InsightLab-AI/
├── frontend/                     # React 18 SPA (Vite)
│   ├── src/
│   │   ├── components/          # Dashboard, Auth, Sidebar, AI Assistant
│   │   │   └── workbench/       # 9 Interactive Pipeline Step Components
│   │   ├── api.js               # Central API Client
│   │   └── styles.css           # Full CSS Token System (Dark & Light Theme)
│   └── package.json
├── server/                       # Node.js + Express API Gateway
│   ├── src/
│   │   ├── models/              # Mongoose User & Project Schemas
│   │   ├── routes/              # Auth & Project Endpoints
│   │   └── utils/               # Nodemailer Gmail OTP Mailer
│   ├── uploads/                 # Storage for Uploaded Datasets
│   └── package.json
└── ml_service/                   # Python Django REST ML Service
    ├── ml_service/              # Django Settings & Routing
    ├── workbench/               # Core Profiling, EDA, Training & Plotting
    ├── saved_models/            # Serialized .joblib Model Artifacts
    └── requirements.txt
```

---

## ⚙️ Installation & Local Setup Guide

### Prerequisites
Before running the application, ensure you have the following installed on your machine:
- **Node.js**: v18.0.0 or higher ([Download](https://nodejs.org/))
- **Python**: v3.10.0 or higher ([Download](https://www.python.org/))
- **MongoDB**: Community Edition running on `mongodb://127.0.0.1:27017` ([Download](https://www.mongodb.com/try/download/community))
- **Git**: ([Download](https://git-scm.com/))

---

### Step 1: Clone the Repository

```bash
git clone https://github.com/manpatel20/InsightLab-AI-Intelligent-Data_Science-Workbench_Sem_4.git
cd InsightLab-AI-Intelligent-Data_Science-Workbench_Sem_4
```

---

### Step 2: Configure & Start Node.js Backend API

1. Navigate to the `server` directory:
   ```bash
   cd server
   ```
2. Install Node dependencies:
   ```bash
   npm install
   ```
3. Create the `.env` environment file:
   - **Windows (PowerShell/CMD)**:
     ```powershell
   copy .env.example .env
     ```
   - **macOS / Linux**:
     ```bash
     cp .env.example .env
     ```
4. Open `server/.env` and update your environment variables:
   ```env
   PORT=5000
   MONGO_URI=mongodb://127.0.0.1:27017/insightlab_ai
   JWT_SECRET=your_super_secret_jwt_key
   DJANGO_API_URL=http://localhost:8000/api
   OPENAI_API_KEY=your_openai_api_key

   # Gmail SMTP Configuration for Real Email OTP Delivery
   EMAIL_HOST=smtp.gmail.com
   EMAIL_PORT=587
   EMAIL_USER=your_email@gmail.com
   EMAIL_PASS=your_16_digit_google_app_password
   ```
5. Start the backend API server in development mode:
   ```bash
   npm run dev
   ```
   *Node API will run on `http://localhost:5000`*

---

### Step 3: Configure & Start Python Django ML Service

1. Open a **new terminal window** and navigate to `ml_service`:
   ```bash
   cd ml_service
   ```
2. Create and activate a Python virtual environment:
   - **Windows**:
     ```powershell
     python -m venv .venv
     .venv\Scripts\activate
     ```
3. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Apply database migrations:
   ```bash
   python manage.py migrate
   ```
5. Start the Django ML server on port `8000`:
   ```bash
   python manage.py runserver 8000
   ```
   *Django ML Service will run on `http://localhost:8000`*

---

### Step 4: Configure & Start React Frontend

1. Open a **third terminal window** and navigate to `frontend`:
   ```bash
   cd frontend
   ```
2. Install frontend dependencies:
   ```bash
   npm install
   ```
3. Start the Vite development server:
   ```bash
   npm run dev
   ```
4. Open your browser and navigate to **`http://localhost:5173`**.

---

## 📧 How to Configure Gmail for OTP Delivery

To enable real 6-digit OTP verification codes delivered to user email inboxes:

1. Enable **2-Step Verification** on your Google Account: [https://myaccount.google.com/security](https://myaccount.google.com/security)
2. Generate a 16-character **App Password**: [https://myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
3. Set your credentials in [`server/.env`](file:///c:/Users/jay%20patel/Projects/insightlab%20ai%20%282%29/insightlab%20ai/server/.env):
   ```env
   EMAIL_HOST=smtp.gmail.com
   EMAIL_PORT=587
   EMAIL_USER=your_gmail@gmail.com
   EMAIL_PASS=abcd efgh ijkl mnop
   ```
4. Restart the Node server (`npm run dev`).

---

## 🗺️ Workbench 9-Step Pipeline Overview

| Step | Component | Description |
|:---:|---|---|
| 1️⃣ | **Dataset** | Inspect column names, data types, missing value counts, and live row previews |
| 2️⃣ | **Cleaning** | Apply single-click null removal, median/mode imputations, duplicate filtering, scaling |
| 3️⃣ | **EDA** | View descriptive statistics, distribution skewness, missingness matrices, and text findings |
| 4️⃣ | **Features** | Inspect feature importance rankings, pairwise correlation heatmaps, encoding advice |
| 5️⃣ | **Models** | Auto-detect task type (Regression/Classification) and benchmark multi-model scores |
| 6️⃣ | **Predictions** | Execute single-row or batch feature inference requests using persisted `.joblib` pipelines |
| 7️⃣ | **Visualization** | Generate 20+ Matplotlib chart types including 3-column spatial heatmaps |
| 8️⃣ | **Reports** | Synthesize complete dataset health and model benchmarks into printable reports |
| 9️⃣ | **Settings** | Configure target column, update project details, or safely delete projects |

---

## 📡 API Reference Summary

### Node API Gateway (`http://localhost:5000/api`)
- `POST /api/auth/signup` — Register user & dispatch 6-digit email OTP.
- `POST /api/auth/verify-otp` — Validate OTP code & issue signed JWT token.
- `POST /api/auth/resend-otp` — Resend fresh 6-digit OTP code to email.
- `POST /api/auth/login` — Authenticate user and issue JWT token.
- `GET /api/projects` — Fetch all projects for authenticated user.
- `POST /api/projects` — Create project + upload dataset (Multipart Form).
- `GET /api/projects/:id` — Fetch workbench details for a specific project.
- `DELETE /api/projects/:id` — Delete project and associated trained models.
- `POST /api/projects/:id/chat` — Communicate with AI Data Science Assistant.

### Django ML Engine (`http://localhost:8000/api`)
- `GET /api/health/` — Health check endpoint.
- `POST /api/datasets/profile/` — Statistical and schema profiling.
- `POST /api/datasets/clean/` — Interactive data cleaning pipeline execution.
- `POST /api/eda/summary/` — Automated EDA summary calculations.
- `POST /api/visualize/` — Matplotlib/Seaborn plot generator (returns Base64 image).
- `POST /api/models/train/` — Scikit-Learn multi-model training & benchmarking.
- `POST /api/predictions/run/` — `.joblib` model inference execution.
- `POST /api/reports/generate/` — One-click executive report generator.

---

## ❓ Troubleshooting & FAQ

<details>
<summary><b>1. MongoDB connection failed error</b></summary>
Ensure MongoDB Community Server is installed and running locally on port <code>27017</code>. You can start MongoDB service in Windows Services or run:
<pre>net start MongoDB</pre>
</details>

<details>
<summary><b>2. OTP Emails are not arriving in inbox</b></summary>
Make sure you are using a 16-character <b>Google App Password</b> (not your regular Gmail password) and that <b>2-Step Verification</b> is turned ON in your Google Account settings. Also check your Spam/Junk folder.
</details>

<details>
<summary><b>3. Python module missing error</b></summary>
Ensure your virtual environment is activated (<code>.venv\Scripts\activate</code>) and re-run:
<pre>pip install -r requirements.txt</pre>
</details>

---

## 👨‍💻 Author

**Man Patel**
- **GitHub**: [@manpatel20](https://github.com/manpatel20)

---

## 📜 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for details.
