import mongoose from "mongoose";

const datasetSchema = new mongoose.Schema(
  {
    originalName: String,
    fileName: String,
    path: String,
    size: Number,
    mimeType: String,
    uploadedAt: Date,
    metadata: {
      rows: Number,
      columns: Number,
      columnNames: [String],
      columnTypes: Object,
      missingValues: Object,
      preview: [Object]          // FIX #16 — explicitly include preview rows
    }
  },
  { _id: false }
);

const experimentSchema = new mongoose.Schema(
  {
    modelName: String,
    taskType: String,
    metric: String,
    score: Number,
    rmse: Number,
    f1: Number,
    createdAt: { type: Date, default: Date.now }
  },
  { _id: false }
);

const projectSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    projectName: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    targetColumn: { type: String, default: "" },
    status: { type: String, default: "Dataset pending" },
    dataset: datasetSchema,
    experiments: [experimentSchema],
    reports: [
      {
        title: String,
        generatedAt: { type: Date, default: Date.now }
      }
    ]
  },
  { timestamps: true }
);

export const Project = mongoose.model("Project", projectSchema);
