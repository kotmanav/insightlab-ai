import nodemailer from "nodemailer";

async function getTransporter() {
  const emailUser = process.env.EMAIL_USER ? process.env.EMAIL_USER.trim() : "";
  const emailPass = process.env.EMAIL_PASS ? process.env.EMAIL_PASS.trim() : "";
  const smtpHost  = (process.env.EMAIL_HOST || process.env.SMTP_HOST || "").trim();
  const rawPort   = process.env.EMAIL_PORT || process.env.SMTP_PORT || "465";
  const smtpPort  = parseInt(rawPort.toString().trim(), 10) || 465;
  const isSecure  = process.env.SMTP_SECURE ? process.env.SMTP_SECURE.trim() === "true" : smtpPort === 465;

  if (smtpHost) {
    return nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: isSecure,
      auth: {
        user: emailUser,
        pass: emailPass.replace(/\s+/g, ""),
      },
      connectionTimeout: 12000,
      greetingTimeout: 12000,
      socketTimeout: 12000,
    });
  }

  return nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: emailUser,
      pass: emailPass.replace(/\s+/g, ""), // Strip spaces from 16-char Gmail App Password
    },
    connectionTimeout: 12000,
    greetingTimeout: 12000,
    socketTimeout: 12000,
  });
}

export async function sendOtpEmail(email, otp, name = "User") {
  console.log(`\n==================================================`);
  console.log(`🔑 [EMAIL OTP VERIFICATION] Sent to: ${email}`);
  console.log(`👉 VERIFICATION OTP CODE: ${otp}`);
  console.log(`==================================================\n`);

  const emailUser = process.env.EMAIL_USER ? process.env.EMAIL_USER.trim() : "";
  const emailPass = process.env.EMAIL_PASS ? process.env.EMAIL_PASS.trim() : "";

  const isConfigured =
    emailUser &&
    emailPass &&
    emailUser !== "your-email@gmail.com" &&
    emailUser !== "your_email@gmail.com" &&
    emailPass !== "your-16-character-app-password" &&
    emailPass !== "your_16_digit_google_app_password";

  if (!isConfigured) {
    console.log(`ℹ️ [sendOtpEmail] EMAIL_USER not configured in .env. Using Instant Fallback OTP: ${otp}`);
    return false; // Triggers instant UI fallback display with OTP code
  }

  try {
    const mail = await getTransporter();
    const sender = emailUser;

    const info = await mail.sendMail({
      from: `"InsightLab AI" <${sender}>`,
      to: email,
      subject: `[InsightLab AI] Your Account Verification Code is ${otp}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 520px; margin: 0 auto; padding: 24px; background: #0d1117; color: #e6edf3; border-radius: 12px; border: 1px solid #30363d;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px;">
            <h2 style="color: #2f81f7; margin: 0;">InsightLab AI</h2>
          </div>
          <h3 style="color: #ffffff; margin-top: 0;">Verify Your Email Address</h3>
          <p style="color: #8b949e; font-size: 14px; line-height: 1.6;">
            Hello ${name},<br/>
            Thank you for registering on InsightLab AI. Use the 6-digit OTP code below to complete your email verification:
          </p>
          <div style="text-align: center; margin: 28px 0;">
            <span style="font-size: 32px; font-weight: 800; letter-spacing: 8px; color: #3fb950; background: #161b22; padding: 12px 28px; border-radius: 8px; border: 1px solid #30363d; display: inline-block;">
              ${otp}
            </span>
          </div>
          <p style="color: #8b949e; font-size: 13px;">
            This OTP code is valid for <strong>10 minutes</strong>. If you did not request this account creation, please ignore this message.
          </p>
          <hr style="border: none; border-top: 1px solid #21262d; margin: 20px 0;" />
          <p style="color: #6e7681; font-size: 12px; text-align: center;">
            © InsightLab AI — Intelligent Data Science Workbench
          </p>
        </div>
      `,
    });

    console.log(`✅ [sendOtpEmail Success] Mail delivered to ${email} (MessageID: ${info.messageId})`);
    return true;
  } catch (err) {
    console.error(`❌ [sendOtpEmail Error] Failed sending OTP email to ${email}:`, err.message || err);
    return false;
  }
}

export async function sendReportEmail(email, report, projectName, name = "Researcher") {
  console.log(`\n==================================================`);
  console.log(`📩 [EXECUTIVE REPORT EMAIL] Sending to: ${email}`);
  console.log(`📊 Project: ${projectName}`);
  console.log(`==================================================\n`);

  try {
    const mail = await getTransporter();
    
    const sectionsHtml = (report.sections || [])
      .map((sec, i) => {
        const title = typeof sec === "object" ? sec.title : `Section ${i + 1}`;
        const content = typeof sec === "object" ? sec.content : String(sec);
        return `
          <div style="background: #161b22; padding: 14px; border-radius: 8px; border: 1px solid #30363d; margin-bottom: 12px;">
            <div style="font-size: 13px; font-weight: 700; color: #58a6ff; margin-bottom: 6px;">${title}</div>
            <div style="font-size: 13px; color: #8b949e; line-height: 1.5;">${content}</div>
          </div>
        `;
      })
      .join("");

    const insightsHtml = (report.eda?.insights || [])
      .map(ins => `<li style="margin-bottom:6px; color:#e6edf3;">${ins}</li>`)
      .join("");

    const recommendationsHtml = (report.recommendations || [])
      .map(rec => `<li style="margin-bottom:6px; color:#3fb950;">${rec}</li>`)
      .join("");

    const targetCol = report.summary?.targetColumn || report.summary?.target_column || "N/A";
    const bestMdl  = report.summary?.bestModel || report.summary?.best_model || "N/A";

    const info = await mail.sendMail({
      from: `"InsightLab AI" <${process.env.EMAIL_USER || "insighlab@gmail.com"}>`,
      to: email,
      subject: `📊 Executive Data Analysis Report — ${projectName} [InsightLab AI]`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto; padding: 24px; background: #0d1117; color: #e6edf3; border-radius: 12px; border: 1px solid #30363d;">
          <div style="border-bottom: 1px solid #21262d; padding-bottom: 16px; margin-bottom: 20px;">
            <h2 style="color: #2f81f7; margin: 0;">InsightLab AI Workbench</h2>
            <span style="background: #238636; color: #ffffff; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; display: inline-block; margin-top: 8px;">Executive Report Generated</span>
          </div>

          <h3 style="color: #ffffff; margin-top: 0;">${report.title || `Analysis Report: ${projectName}`}</h3>
          <p style="color: #8b949e; font-size: 14px; line-height: 1.6;">
            Hello ${name},<br/>
            Your requested executive data science report for <strong>${projectName}</strong> has been generated successfully. Below is your summary:
          </p>

          <!-- Key Metrics -->
          <div style="display: flex; gap: 12px; margin: 20px 0;">
            <div style="flex: 1; background: #161b22; padding: 12px; border-radius: 8px; border: 1px solid #30363d; text-align: center;">
              <div style="font-size: 11px; color: #8b949e; text-transform: uppercase;">Total Rows</div>
              <div style="font-size: 18px; font-weight: 800; color: #58a6ff; margin-top: 4px;">${report.summary?.rows?.toLocaleString() || "—"}</div>
            </div>
            <div style="flex: 1; background: #161b22; padding: 12px; border-radius: 8px; border: 1px solid #30363d; text-align: center;">
              <div style="font-size: 11px; color: #8b949e; text-transform: uppercase;">Columns</div>
              <div style="font-size: 18px; font-weight: 800; color: #a371f7; margin-top: 4px;">${report.summary?.columns || "—"}</div>
            </div>
            <div style="flex: 1; background: #161b22; padding: 12px; border-radius: 8px; border: 1px solid #30363d; text-align: center;">
              <div style="font-size: 11px; color: #8b949e; text-transform: uppercase;">Target Column</div>
              <div style="font-size: 15px; font-weight: 700; color: #3fb950; margin-top: 6px;">${targetCol}</div>
            </div>
            <div style="flex: 1; background: #161b22; padding: 12px; border-radius: 8px; border: 1px solid #30363d; text-align: center;">
              <div style="font-size: 11px; color: #8b949e; text-transform: uppercase;">Best Model</div>
              <div style="font-size: 13px; font-weight: 700; color: #e3b341; margin-top: 6px;">${bestMdl}</div>
            </div>
          </div>

          <!-- Structured Report Sections -->
          ${sectionsHtml ? `
          <div style="margin-bottom: 20px;">
            <h4 style="color: #58a6ff; margin-top: 0; margin-bottom: 12px;">📖 Report Breakdown</h4>
            ${sectionsHtml}
          </div>
          ` : ''}

          <!-- EDA Insights -->
          ${insightsHtml ? `
          <div style="background: #161b22; padding: 16px; border-radius: 8px; border: 1px solid #30363d; margin-bottom: 16px;">
            <h4 style="color: #58a6ff; margin-top: 0; margin-bottom: 10px;">💡 Key EDA Insights</h4>
            <ul style="padding-left: 20px; margin: 0; font-size: 13px; line-height: 1.6;">
              ${insightsHtml}
            </ul>
          </div>
          ` : ''}

          <!-- Actionable Recommendations -->
          ${recommendationsHtml ? `
          <div style="background: #161b22; padding: 16px; border-radius: 8px; border: 1px solid #30363d; margin-bottom: 20px;">
            <h4 style="color: #3fb950; margin-top: 0; margin-bottom: 10px;">🎯 Actionable Recommendations</h4>
            <ul style="padding-left: 20px; margin: 0; font-size: 13px; line-height: 1.6;">
              ${recommendationsHtml}
            </ul>
          </div>
          ` : ''}

          <p style="color: #8b949e; font-size: 13px;">
            You can view the full interactive report in your InsightLab AI workspace at any time.
          </p>

          <hr style="border: none; border-top: 1px solid #21262d; margin: 20px 0;" />
          <p style="color: #6e7681; font-size: 12px; text-align: center;">
            © InsightLab AI — Intelligent Data Science Workbench
          </p>
        </div>
      `,
    });

    if (nodemailer.getTestMessageUrl(info)) {
      console.log(`📩 [Ethereal Report Preview URL]: ${nodemailer.getTestMessageUrl(info)}`);
    }

    return true;
  } catch (err) {
    console.error("[sendReportEmail Error]", err);
    return false;
  }
}
