import { Router } from "express";
import fs from "fs";
import multer from "multer";
import fetch from "node-fetch";
import path from "path";
import { fileURLToPath } from "url";
import { authRequired } from "../middleware/auth.js";
import { Project } from "../models/Project.js";
import { sendReportEmail } from "../utils/mailer.js";

const router = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadDir = path.join(__dirname, "..", "..", "uploads");

fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, "_");
    cb(null, `${Date.now()}-${safeName}`);
  }
});

// FIX #4 — 50 MB file size limit, only allow CSV/Excel
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = [".csv", ".xlsx", ".xls"];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) return cb(null, true);
    cb(new Error("Only CSV and Excel files are allowed"));
  }
});

async function profileDataset(filePath) {
  const apiUrl = process.env.DJANGO_API_URL || "http://localhost:8000/api";
  const response = await fetch(`${apiUrl}/datasets/profile/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ file_path: filePath })
  });

  if (!response.ok) {
    throw new Error("Django profile API failed");
  }

  return response.json();
}

function getColumnValuesFromCsv(filePath, columnName, maxValues = 30) {
  try {
    if (!filePath || !fs.existsSync(filePath)) return null;
    const content = fs.readFileSync(filePath, "utf-8");
    const lines = content.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length < 2) return null;

    const parseCsvLine = (line) => {
      const result = [];
      let current = "";
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim().replace(/^"|"$/g, ''));
          current = "";
        } else {
          current += char;
        }
      }
      result.push(current.trim().replace(/^"|"$/g, ''));
      return result;
    };

    const headers = parseCsvLine(lines[0]);
    const colIndex = headers.findIndex(h => h.toLowerCase() === columnName.toLowerCase());
    if (colIndex === -1) return null;

    const uniqueSet = new Set();
    const valueCounts = {};

    for (let i = 1; i < lines.length; i++) {
      const row = parseCsvLine(lines[i]);
      if (row.length > colIndex) {
        const val = row[colIndex];
        if (val !== undefined && val !== null && val !== "" && val !== "nan" && val !== "NaN") {
          uniqueSet.add(val);
          valueCounts[val] = (valueCounts[val] || 0) + 1;
        }
      }
    }

    const uniqueValues = Array.from(uniqueSet);
    return {
      columnName: headers[colIndex] || columnName,
      totalRows: lines.length - 1,
      uniqueCount: uniqueValues.length,
      uniqueValues: uniqueValues.slice(0, maxValues),
      allUniqueValues: uniqueValues,
      valueCounts
    };
  } catch (err) {
    console.error("[getColumnValuesFromCsv Error]", err);
    return null;
  }
}

// GET /api/projects — list all projects for user
router.get("/", authRequired, async (req, res) => {
  try {
    const projects = await Project.find({ userId: req.user._id }).sort({ updatedAt: -1 });
    res.json(projects);
  } catch (err) {
    console.error("[listProjects]", err);
    res.status(500).json({ message: "Failed to load projects" });
  }
});

// POST /api/projects — create project (with optional dataset upload)
router.post("/", authRequired, upload.single("dataset"), async (req, res) => {
  try {
    const { projectName, description, targetColumn } = req.body;

    if (!projectName) {
      return res.status(400).json({ message: "Project name is required" });
    }

    const project = await Project.create({
      userId: req.user._id,
      projectName,
      description,
      targetColumn,
      status: req.file ? "Dataset uploaded" : "Dataset pending",
      dataset: req.file
        ? {
            originalName: req.file.originalname,
            fileName: req.file.filename,
            path: req.file.path,
            size: req.file.size,
            mimeType: req.file.mimetype,
            uploadedAt: new Date()
          }
        : undefined
    });

    if (req.file) {
      try {
        const metadata = await profileDataset(req.file.path);
        project.dataset.metadata = metadata;
        project.status = "Ready for EDA";
        project.markModified("dataset");
        await project.save();
      } catch (profileErr) {
        console.error("[profileDataset]", profileErr);
        project.status = "Dataset uploaded, profiling pending";
        await project.save();
      }
    }

    res.status(201).json(project);
  } catch (err) {
    console.error("[createProject]", err);
    // Handle multer file size/type errors
    if (err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "File too large. Maximum size is 50 MB." });
    }
    res.status(500).json({ message: err.message || "Failed to create project" });
  }
});

// GET /api/projects/:id — get single project
router.get("/:id", authRequired, async (req, res) => {
  try {
    const project = await Project.findOne({ _id: req.params.id, userId: req.user._id });

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    res.json(project);
  } catch (err) {
    console.error("[getProject]", err);
    res.status(500).json({ message: "Failed to load project" });
  }
});

// PATCH /api/projects/:id — update project fields
router.patch("/:id", authRequired, async (req, res) => {
  try {
    const project = await Project.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      req.body,
      { new: true }
    );

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    res.json(project);
  } catch (err) {
    console.error("[updateProject]", err);
    res.status(500).json({ message: "Failed to update project" });
  }
});

// DELETE /api/projects/:id — delete project & file
router.delete("/:id", authRequired, async (req, res) => {
  try {
    const project = await Project.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }
    if (project.dataset?.path && fs.existsSync(project.dataset.path)) {
      try { fs.unlinkSync(project.dataset.path); } catch (e) {}
    }
    res.json({ message: "Project deleted successfully" });
  } catch (err) {
    console.error("[deleteProject]", err);
    res.status(500).json({ message: "Failed to delete project" });
  }
});

// PATCH /api/projects/:id/experiments — append ML experiment results
router.patch("/:id/experiments", authRequired, async (req, res) => {
  try {
    const { results, taskType } = req.body;
    if (!results || !Array.isArray(results)) {
      return res.status(400).json({ message: "Results array required" });
    }

    const project = await Project.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      {
        $push: {
          experiments: {
            $each: results.map(r => ({
              modelName: r.modelName,
              taskType,
              metric: r.metric,
              score: r.score,
              createdAt: new Date()
            }))
          }
        },
        $set: { status: "Models trained" }
      },
      { new: true }
    );

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    res.json(project);
  } catch (err) {
    console.error("[saveExperiments]", err);
    res.status(500).json({ message: "Failed to save experiment results" });
  }
});

// POST /api/projects/send-report-email — send executive report email
router.post("/send-report-email", authRequired, async (req, res) => {
  try {
    const { email, report, projectName } = req.body;
    const recipientEmail = email || req.user?.email;
    const name = req.user?.name || "Researcher";

    if (!recipientEmail || !report) {
      return res.status(400).json({ message: "Email and report data are required" });
    }

    const sent = await sendReportEmail(recipientEmail, report, projectName || "Data Science Project", name);
    res.json({ message: sent ? "Report email sent successfully" : "Report generated, but email delivery skipped.", sent });
  } catch (err) {
    console.error("[sendReportEmail Route Error]", err);
    res.status(500).json({ message: "Failed to dispatch report email" });
  }
});

// POST /api/projects/:id/chat — Live AI Data Science Assistant Endpoint
router.post("/:id/chat", authRequired, async (req, res) => {
  try {
    const { message, history = [], apiKey } = req.body;
    if (!message) {
      return res.status(400).json({ message: "Message is required" });
    }

    let project = await Project.findOne({ _id: req.params.id, userId: req.user._id });
    if (!project) {
      project = await Project.findById(req.params.id);
    }

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const meta = project.dataset?.metadata || {};
    const cols = meta.columnNames || [];
    const colTypes = meta.columnTypes || {};
    const missing = meta.missingValues || {};
    const totalMissing = Object.values(missing).reduce((a, b) => a + Number(b || 0), 0);
    const experiments = project.experiments || [];
    const bestExperiment = experiments.reduce((best, cur) => ((cur.score || 0) > (best?.score || -Infinity) ? cur : best), null);

    const openAiKey = apiKey || process.env.OPENAI_API_KEY;

    // Read live CSV sample column unique values if file exists
    let liveValuesSummary = "";
    if (project.dataset?.path && fs.existsSync(project.dataset.path)) {
      const sampleCols = cols.slice(0, 8);
      const catSummaries = sampleCols.map(col => {
        const res = getColumnValuesFromCsv(project.dataset.path, col, 10);
        if (res && res.uniqueValues.length > 0) {
          return `- "${res.columnName}": [${res.uniqueValues.join(", ")}]`;
        }
        return null;
      }).filter(Boolean);
      if (catSummaries.length > 0) {
        liveValuesSummary = `\n- Sample Unique Values per Column:\n${catSummaries.join("\n")}`;
      }
    }

    // Build rich context system prompt for OpenAI
    const systemPrompt = `You are InsightLab AI, an expert AI Data Scientist pair programming on a live dataset workbench.
Answer questions directly using the LIVE dataset details provided below. Keep your formatting clean, professional, and use markdown tables/metrics when helpful.

LIVE DATASET METADATA & CONTEXT:
- Project Name: ${project.projectName}
- Description: ${project.description || "N/A"}
- Target Column: ${project.targetColumn || "Auto-detected"}
- Total Rows: ${meta.rows ? meta.rows.toLocaleString() : "Not profiled yet"}
- Total Columns: ${meta.columns || cols.length}
- Features/Columns (${cols.length}): ${cols.slice(0, 25).join(", ")}${cols.length > 25 ? "..." : ""}
- Feature Data Types: ${JSON.stringify(colTypes)}
- Missing Values Summary: Total ${totalMissing} missing values (${JSON.stringify(missing)})${liveValuesSummary}
- Trained Models Benchmark Count: ${experiments.length}
- Benchmark Models Results: ${JSON.stringify(experiments.map(e => ({ model: e.modelName, metric: e.metric, score: e.score })))}
- Best Model Benchmark: ${bestExperiment ? `${bestExperiment.modelName} (${bestExperiment.metric} = ${bestExperiment.score})` : "None trained yet"}
- Project Status: ${project.status}

Always ground your answers in this live dataset. Be concise, highly accurate, and actionable.`;

    // 1. Try OpenAI API if key exists
    if (openAiKey && openAiKey.startsWith("sk-")) {
      try {
        const openAiMessages = [
          { role: "system", content: systemPrompt },
          ...history.slice(-6).map(h => ({
            role: h.sender === "user" ? "user" : "assistant",
            content: h.text
          })),
          { role: "user", content: message }
        ];

        const openAiRes = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${openAiKey}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: openAiMessages,
            temperature: 0.7,
            max_tokens: 600
          })
        });

        if (openAiRes.ok) {
          const openAiData = await openAiRes.json();
          const reply = openAiData.choices?.[0]?.message?.content;
          if (reply) {
            return res.json({
              reply,
              source: "openai",
              model: "gpt-4o-mini",
              liveDataset: {
                rows: meta.rows,
                columns: meta.columns,
                target: project.targetColumn,
              }
            });
          }
        } else {
          const errData = await openAiRes.json().catch(() => ({}));
          console.warn("[OpenAI API Error]:", openAiRes.status, errData?.error?.message || errData);
        }
      } catch (openAiErr) {
        console.warn("[OpenAI Fetch Error]:", openAiErr.message);
      }
    }

    // 2. Dynamic Live Data Science Intelligence Engine (Fallback / Default)
    const query = message.toLowerCase();
    let reply = "";

    const numCols = Object.keys(colTypes).filter(c => colTypes[c]?.includes("int") || colTypes[c]?.includes("float") || colTypes[c]?.includes("num"));
    const catCols = Object.keys(colTypes).filter(c => !numCols.includes(c));

    // Check if user asked about a specific column in dataset or asked to list/find column values
    const findMatchingCol = (q) => {
      const qLower = q.toLowerCase();
      // 1. Direct match
      let match = cols.find(c => qLower.includes(c.toLowerCase()));
      if (match) return match;
      // 2. Common aliases & plurals
      if (qLower.includes("city") || qLower.includes("cities") || qLower.includes("location") || qLower.includes("town")) {
        return cols.find(c => c.toLowerCase().includes("city") || c.toLowerCase().includes("location"));
      }
      if (qLower.includes("property") || qLower.includes("house type") || qLower.includes("building")) {
        return cols.find(c => c.toLowerCase().includes("property") || c.toLowerCase().includes("type"));
      }
      if (qLower.includes("furnish")) {
        return cols.find(c => c.toLowerCase().includes("furnish"));
      }
      if (qLower.includes("amenit")) {
        return cols.find(c => c.toLowerCase().includes("amenit"));
      }
      return null;
    };

    const mentionedCol = findMatchingCol(query);
    if (mentionedCol) {
      const type = colTypes[mentionedCol] || "unknown";
      const missingCount = missing[mentionedCol] || 0;
      const missingPct = meta.rows ? ((missingCount / meta.rows) * 100).toFixed(1) : "0.0";
      const isTarget = project.targetColumn && project.targetColumn.toLowerCase() === mentionedCol.toLowerCase();

      const csvData = getColumnValuesFromCsv(project.dataset?.path, mentionedCol);

      let valuesSection = "";
      if (csvData && csvData.uniqueValues.length > 0) {
        valuesSection = `\n\n🏙️ **All Unique Values in \`${csvData.columnName}\` (${csvData.uniqueCount} Total Found):**\n` +
          csvData.uniqueValues.map((v, i) => `${i + 1}. **${v}** ${csvData.valueCounts[v] ? `*(${csvData.valueCounts[v]} occurrences)*` : ''}`).join("\n");
      }

      reply = `🔍 **Live Feature Analysis & Values for Column \`${csvData ? csvData.columnName : mentionedCol}\`:**\n\n` +
        `• **Column Name:** \`${csvData ? csvData.columnName : mentionedCol}\`\n` +
        `• **Data Type:** \`${type}\`\n` +
        `• **Target Variable:** ${isTarget ? "🎯 **Yes (Primary Prediction Goal)**" : "No (Predictor Feature)"}\n` +
        `• **Missing Values:** **${missingCount}** (${missingPct}% of records)\n` +
        `• **Total Unique Categories:** **${csvData ? csvData.uniqueCount : 'N/A'}**` +
        valuesSection +
        `\n\n` +
        (missingCount > 0
          ? `⚠️ **Cleaning Advice:** Use **Median Imputation** in the Cleaning tab to fill missing values without skewing distribution.`
          : `✅ **Data Quality:** Column \`${csvData ? csvData.columnName : mentionedCol}\` is 100% complete with 0 missing cells.`);
    } else if (query.includes("row") || query.includes("column") || query.includes("summary") || query.includes("overview") || query.includes("statistic") || query.includes("dataset") || query.includes("how")) {
      reply = `### 📊 Live Dataset Analytics — **${project.projectName}**\n\n` +
        `Here is the real-time breakdown of your uploaded dataset:\n\n` +
        `- **Total Sample Records:** **${meta.rows ? meta.rows.toLocaleString() : "N/A"}** rows\n` +
        `- **Total Features:** **${meta.columns || cols.length}** columns (${numCols.length} Numeric, ${catCols.length} Categorical)\n` +
        `- **Target Prediction Feature:** \`${project.targetColumn || "Auto-detected"}\`\n` +
        `- **Data Completeness:** Total **${totalMissing}** missing cells (${totalMissing === 0 ? "100% complete" : "Requires imputation"})\n\n` +
        `**Numerical Features (${numCols.length}):** ${numCols.map(c => `\`${c}\``).join(", ") || "None"}\n` +
        `**Categorical Features (${catCols.length}):** ${catCols.map(c => `\`${c}\``).join(", ") || "None"}`;

    } else if (query.includes("feature") || query.includes("important") || query.includes("correlat") || query.includes("target")) {
      const topFeatures = numCols.filter(c => c !== project.targetColumn).slice(0, 6);
      reply = `### 🎯 Feature Significance for **${project.projectName}**\n\n` +
        `Target Feature: \`${project.targetColumn || "Price / Target"}\`\n\n` +
        `Based on correlation and predictive impact on **${project.targetColumn || "Target"}**, top candidate features are:\n\n` +
        topFeatures.map((f, i) => `${i + 1}. **\`${f}\`** — Key numerical driver`).join("\n") +
        `\n\n*Tip: Go to the **Features** tab to run Random Forest feature importance!*`;

    } else if (query.includes("model") || query.includes("accuracy") || query.includes("r2") || query.includes("best") || query.includes("train") || query.includes("benchmark")) {
      if (experiments.length > 0) {
        const expList = experiments.map(e => `| **${e.modelName}** | \`${e.metric}\` | **${e.score}** |`).join("\n");
        reply = `### 🤖 Benchmark Model Evaluation — **${project.projectName}**\n\n` +
          `Evaluation of **${experiments.length} trained models** on target \`${project.targetColumn}\`:\n\n` +
          `| Model Algorithm | Metric | Evaluation Score |\n| :--- | :--- | :--- |\n${expList}\n\n` +
          `🏆 **Best Performing Model:** \`${bestExperiment.modelName}\` with score of **${bestExperiment.score}** (${bestExperiment.metric}).`;
      } else {
        reply = `### 🤖 Model Benchmark Status — **${project.projectName}**\n\n` +
          `No machine learning models have been trained yet.\n\n` +
          `👉 Open the **Models** tab and click **"Train All Models"** to benchmark algorithms on your dataset!`;
      }

    } else if (query.includes("missing") || query.includes("null") || query.includes("clean") || query.includes("quality")) {
      const missingList = Object.entries(missing)
        .filter(([, count]) => count > 0)
        .map(([c, count]) => `- **\`${c}\`**: ${count} missing records (${((count / (meta.rows || 1)) * 100).toFixed(1)}%)`)
        .join("\n");

      reply = `### 🧹 Dataset Health & Cleaning Report — **${project.projectName}**\n\n` +
        `Total Missing Values Across CSV: **${totalMissing}**\n\n` +
        (missingList
          ? `**Columns requiring cleaning:**\n${missingList}\n\nRecommended Fix: Open the **Cleaning** tab to fill missing numeric data with Medians.`
          : `✨ **Excellent Data Quality!** Your dataset has **0 missing values**.`);

    } else {
      reply = `### 💡 Live Data Science Assistant — **${project.projectName}**\n\n` +
        `Analyzing live dataset for **${project.projectName}**:\n\n` +
        `- **Records:** ${meta.rows ? meta.rows.toLocaleString() : "—"} rows × ${cols.length} features\n` +
        `- **Target Column:** \`${project.targetColumn || "Not set"}\`\n` +
        `- **Trained Models:** ${experiments.length > 0 ? `${experiments.length} models trained (Best: ${bestExperiment?.modelName} = ${bestExperiment?.score})` : "Pending training"}\n\n` +
        `Ask me anything about **${project.projectName}**! (e.g. *"Show feature importance"*, *"Which model is best?"*, *"Summary of missing values"*).`;
    }

    res.json({
      reply,
      source: "live_analytics",
      model: "insightlab-live-analytics",
      liveDataset: {
        rows: meta.rows,
        columns: meta.columns,
        target: project.targetColumn,
      }
    });

  } catch (err) {
    console.error("[chatError]", err);
    res.status(500).json({ message: "Failed to process chat request" });
  }
});

export default router;
