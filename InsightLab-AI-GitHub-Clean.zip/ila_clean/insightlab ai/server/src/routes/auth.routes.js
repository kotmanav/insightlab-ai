import bcrypt from "bcryptjs";
import { Router } from "express";
import jwt from "jsonwebtoken";
import { User } from "../models/User.js";
import { sendOtpEmail } from "../utils/mailer.js";

const router = Router();

// Fail loudly if JWT_SECRET is missing
function getJwtSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("JWT_SECRET environment variable is not set. Add it to .env before starting the server.");
  }
  return secret;
}

function signToken(user) {
  return jwt.sign({ userId: user._id }, getJwtSecret(), { expiresIn: "7d" });
}

function generateOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// ── POST /api/auth/signup — Create user & send OTP ─────────────────────────────
router.post("/signup", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: "Name, email, and password are required" });
    }

    if (password.length < 6) {
      return res.status(400).json({ message: "Password must be at least 6 characters" });
    }

    const cleanEmail = email.toLowerCase().trim();
    const existing = await User.findOne({ email: cleanEmail });

    if (existing && existing.isVerified) {
      return res.status(409).json({ message: "Email already registered. Please sign in." });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const otp = generateOtp();
    const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    let user;
    if (existing && !existing.isVerified) {
      // Re-use existing unverified user record
      existing.name = name;
      existing.passwordHash = passwordHash;
      existing.otp = otp;
      existing.otpExpiresAt = otpExpiresAt;
      user = await existing.save();
    } else {
      user = await User.create({
        name,
        email: cleanEmail,
        passwordHash,
        isVerified: false,
        otp,
        otpExpiresAt,
      });
    }

    // Send email with OTP
    const sent = await sendOtpEmail(cleanEmail, otp, name);

    res.status(200).json({
      requireOtp: true,
      email: cleanEmail,
      message: sent
        ? "Verification code (OTP) sent to your email address."
        : `Verification code (OTP): ${otp} (Email server fallback)`
    });
  } catch (err) {
    console.error("[signup]", err);
    res.status(500).json({ message: "Signup failed. Please try again." });
  }
});

// ── POST /api/auth/verify-otp — Verify OTP & activate user account ──────────
router.post("/verify-otp", async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ message: "Email and OTP code are required" });
    }

    const cleanEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: cleanEmail });

    if (!user) {
      return res.status(404).json({ message: "User account not found" });
    }

    if (user.isVerified) {
      return res.json({
        token: signToken(user),
        user: { id: user._id, name: user.name, email: user.email }
      });
    }

    if (!user.otp || user.otp !== otp.toString().trim()) {
      return res.status(400).json({ message: "Invalid verification OTP code. Please check and try again." });
    }

    if (!user.otpExpiresAt || user.otpExpiresAt < new Date()) {
      return res.status(400).json({ message: "OTP code has expired. Please click Resend OTP." });
    }

    // Mark user as verified
    user.isVerified = true;
    user.otp = undefined;
    user.otpExpiresAt = undefined;
    await user.save();

    res.json({
      message: "Email verified successfully!",
      token: signToken(user),
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch (err) {
    console.error("[verify-otp]", err);
    res.status(500).json({ message: "Verification failed. Please try again." });
  }
});

// ── POST /api/auth/resend-otp — Resend new OTP email ─────────────────────────
router.post("/resend-otp", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    const cleanEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: cleanEmail });

    if (!user) {
      return res.status(404).json({ message: "User account not found" });
    }

    if (user.isVerified) {
      return res.status(400).json({ message: "Account is already verified. Please sign in." });
    }

    const otp = generateOtp();
    user.otp = otp;
    user.otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);
    await user.save();

    const sent = await sendOtpEmail(cleanEmail, otp, user.name);

    res.json({
      message: sent
        ? "A new OTP verification code has been sent to your email."
        : `New Verification OTP Code: ${otp}`
    });
  } catch (err) {
    console.error("[resend-otp]", err);
    res.status(500).json({ message: "Failed to resend OTP. Please try again." });
  }
});

// ── POST /api/auth/login ──────────────────────────────────────────────────────
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const cleanEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: cleanEmail });

    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    if (!user.isVerified) {
      const otp = generateOtp();
      user.otp = otp;
      user.otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);
      await user.save();

      const sent = await sendOtpEmail(cleanEmail, otp, user.name);

      return res.status(403).json({
        message: sent
          ? "Account is not verified yet. A verification OTP code has been sent to your email."
          : `Account not verified. Verification code (OTP): ${otp} (Email server fallback)`,
        requireOtp: true,
        email: cleanEmail
      });
    }

    res.json({
      token: signToken(user),
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch (err) {
    console.error("[login]", err);
    res.status(500).json({ message: "Login failed. Please try again." });
  }
});

// ── POST /api/auth/forgot-password ──────────────────────────────────────────
router.post("/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ message: "Registered email address is required." });
    }

    const cleanEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: cleanEmail });

    if (!user) {
      return res.status(404).json({ message: "No account found with this email address." });
    }

    const otp = generateOtp();
    user.otp = otp;
    user.otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);
    await user.save();

    const sent = await sendOtpEmail(cleanEmail, otp, user.name);

    res.json({
      message: sent
        ? "A password reset OTP code has been sent to your email."
        : `Password Reset OTP Code: ${otp}`
    });
  } catch (err) {
    console.error("[forgot-password]", err);
    res.status(500).json({ message: "Failed to initiate password reset." });
  }
});

// ── POST /api/auth/reset-password ───────────────────────────────────────────
router.post("/reset-password", async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      return res.status(400).json({ message: "Email, OTP code, and new password are required." });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: "New password must be at least 6 characters long." });
    }

    const cleanEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: cleanEmail });

    if (!user) {
      return res.status(404).json({ message: "User account not found." });
    }

    if (!user.otp || user.otp !== otp.toString().trim()) {
      return res.status(400).json({ message: "Invalid OTP code. Please check and try again." });
    }

    if (!user.otpExpiresAt || user.otpExpiresAt < new Date()) {
      return res.status(400).json({ message: "OTP code has expired. Please request a new reset code." });
    }

    user.passwordHash = await bcrypt.hash(newPassword, 10);
    user.otp = undefined;
    user.otpExpiresAt = undefined;
    user.isVerified = true;
    await user.save();

    res.json({ message: "Password reset successfully! Please sign in with your new password." });
  } catch (err) {
    console.error("[reset-password]", err);
    res.status(500).json({ message: "Password reset failed. Please try again." });
  }
});

export default router;
